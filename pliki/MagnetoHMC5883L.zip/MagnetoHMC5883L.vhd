-- JS PWr Edu PL
-- --------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;

entity MagnetoHMC5883L is
  port (
    Clk_100MHz : in STD_LOGIC;
    Reset : in STD_LOGIC;
    OutputRate : in STD_LOGIC_VECTOR ( 2 downto 0 );
    I2C_NACK : out STD_LOGIC;
    DRX : out STD_LOGIC_VECTOR ( 11 downto 0 );
    DRY : out STD_LOGIC_VECTOR ( 11 downto 0 );
    DRZ : out STD_LOGIC_VECTOR ( 11 downto 0 );
    NewData : out STD_LOGIC;
    Magneto_SDA : inout STD_LOGIC;
    Magneto_SCL : inout STD_LOGIC;
    Magneto_DRDY : in STD_LOGIC
  );
end MagnetoHMC5883L;

architecture STRUCTURE of MagnetoHMC5883L is
  signal Address : STD_LOGIC_VECTOR ( 0 to 0 );
  signal DI : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal DO : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \DRX[11]_i_1_n_0\ : STD_LOGIC;
  signal DoPush : STD_LOGIC;
  signal FIFO_Empty : STD_LOGIC;
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[4]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[4]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[4]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[4]_i_5_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[4]_i_6_n_0\ : STD_LOGIC;
  signal \^i2c_nack\ : STD_LOGIC;
  signal L : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal NACK_i_1_n_0 : STD_LOGIC;
  signal NACK_i_2_n_0 : STD_LOGIC;
  signal NACK_i_3_n_0 : STD_LOGIC;
  signal NACK_i_4_n_0 : STD_LOGIC;
  signal NACK_i_5_n_0 : STD_LOGIC;
  signal NACK_i_6_n_0 : STD_LOGIC;
  signal NACK_i_7_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_10_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_11_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_12_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_13_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_14_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_15_n_0 : STD_LOGIC;
  signal RdNotWr_i_1_n_0 : STD_LOGIC;
  signal SCLout_i_1_n_0 : STD_LOGIC;
  signal SCLout_i_2_n_0 : STD_LOGIC;
  signal SCLout_i_3_n_0 : STD_LOGIC;
  signal SCLout_i_4_n_0 : STD_LOGIC;
  signal SCLout_i_5_n_0 : STD_LOGIC;
  signal SCLout_i_6_n_0 : STD_LOGIC;
  signal SCLout_i_7_n_0 : STD_LOGIC;
  signal SCLout_i_8_n_0 : STD_LOGIC;
  signal SCLout_i_9_n_0 : STD_LOGIC;
  signal SDAout_i_1_n_0 : STD_LOGIC;
  signal SDAout_i_2_n_0 : STD_LOGIC;
  signal SDAout_i_4_n_0 : STD_LOGIC;
  signal SDAout_i_5_n_0 : STD_LOGIC;
  signal SDAout_i_6_n_0 : STD_LOGIC;
  signal SDAout_i_7_n_0 : STD_LOGIC;
  signal SDAout_i_8_n_0 : STD_LOGIC;
  signal \addrRd[0]_i_3_n_0\ : STD_LOGIC;
  signal \addrWr[0]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[1]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[2]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[3]_i_1_n_0\ : STD_LOGIC;
  signal addrWr_reg : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \cntBits[0]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[1]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[2]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_2_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_3_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_4_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_5_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_6_n_0\ : STD_LOGIC;
  signal \cntBytes[0]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[1]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[2]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[3]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[3]_i_2_n_0\ : STD_LOGIC;
  signal \cntBytes[3]_i_3_n_0\ : STD_LOGIC;
  signal cntPush_i_1_n_0 : STD_LOGIC;
  signal \cntSCL[10]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[14]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[2]_i_1_n_0\ : STD_LOGIC;
  signal \cntSCL[3]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[5]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[7]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[7]_i_3_n_0\ : STD_LOGIC;
  signal \cntSCL[7]_i_4_n_0\ : STD_LOGIC;
  signal \cntSCL[7]_i_5_n_0\ : STD_LOGIC;
  signal current_OutputRate : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal iDRX : STD_LOGIC_VECTOR ( 11 downto 0 );
  signal \iDRX[11]_i_1_n_0\ : STD_LOGIC;
  signal \iDRX[7]_i_1_n_0\ : STD_LOGIC;
  signal iDRY : STD_LOGIC_VECTOR ( 11 downto 0 );
  signal \iDRY[11]_i_1_n_0\ : STD_LOGIC;
  signal \iDRY[7]_i_1_n_0\ : STD_LOGIC;
  signal iDRZ : STD_LOGIC_VECTOR ( 11 downto 0 );
  signal \iDRZ[7]_i_1_n_0\ : STD_LOGIC;
  signal iEmpty_i_1_n_0 : STD_LOGIC;
  signal iEmpty_i_2_n_0 : STD_LOGIC;
  signal iEmpty_i_3_n_0 : STD_LOGIC;
  signal iFull : STD_LOGIC;
  signal iFull_i_1_n_0 : STD_LOGIC;
  signal iFull_i_2_n_0 : STD_LOGIC;
  signal iFull_i_3_n_0 : STD_LOGIC;
  signal \i_Ctrl/cntPush\ : STD_LOGIC;
  signal \i_Ctrl/current_OutputRate0\ : STD_LOGIC;
  signal \i_Ctrl/iDRZ_reg0\ : STD_LOGIC;
  signal \i_Ctrl/next_state\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \i_Ctrl/p_0_in\ : STD_LOGIC;
  signal \i_Ctrl/regDRDY_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_Ctrl/state\ : STD_LOGIC_VECTOR ( 4 downto 0 );
  signal \i_I2C/FSM_onehot_state_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/FSM_onehot_state_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_I2C/RdNotWr\ : STD_LOGIC;
  signal \i_I2C/RdNotWr0\ : STD_LOGIC;
  signal \i_I2C/SCLin\ : STD_LOGIC;
  signal \i_I2C/SCLout_reg_n_0\ : STD_LOGIC;
  signal \i_I2C/SDAin\ : STD_LOGIC;
  signal \i_I2C/SDAout\ : STD_LOGIC;
  signal \i_I2C/T\ : STD_LOGIC;
  signal \i_I2C/cntBits\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_I2C/cntBytes\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/cntSCL\ : STD_LOGIC;
  signal \i_I2C/cntSCL__0\ : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \i_I2C/i_FIFO/addrRd_reg\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/i_FIFO/p_1_in\ : STD_LOGIC;
  signal \i_I2C/i_FIFO/plusOp0_in\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/p_0_in\ : STD_LOGIC;
  signal \i_I2C/p_1_in\ : STD_LOGIC;
  signal \i_I2C/rSDAin\ : STD_LOGIC;
  signal \i_I2C/sclEnd\ : STD_LOGIC;
  signal \i_I2C/sregOut[7]_i_5_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[6]\ : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal rSCLin : STD_LOGIC;
  signal sregIn : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \sregIn[7]_i_1_n_0\ : STD_LOGIC;
  signal sregOut : STD_LOGIC_VECTOR ( 7 to 7 );
  signal \sregOut[7]_i_1_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_3_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_4_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_6_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_7_n_0\ : STD_LOGIC;
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOE_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOF_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOG_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOH_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_state[0]_i_2\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \FSM_sequential_state[1]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of NACK_i_2 : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of NACK_i_4 : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of NACK_i_5 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of NACK_i_6 : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_10 : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_11 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_12 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_13 : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_2 : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_6 : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_7 : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_8 : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_9 : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of SCLout_i_5 : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of SCLout_i_6 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of SCLout_i_7 : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of SCLout_i_8 : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of SCLout_i_9 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of SDAout_i_8 : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \addrRd[0]_i_2\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \addrRd[1]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \addrRd[2]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \addrRd[3]_i_1\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \addrWr[0]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \addrWr[1]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \addrWr[2]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \addrWr[3]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \cntBits[0]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \cntBits[1]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \cntBits[2]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \cntBits[3]_i_2\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \cntBits[3]_i_4\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \cntBits[3]_i_6\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cntBytes[0]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \cntBytes[1]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \cntBytes[2]_i_1\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \cntBytes[3]_i_2\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of \cntSCL[0]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \cntSCL[12]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \cntSCL[13]_i_1\ : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \cntSCL[14]_i_2\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \cntSCL[1]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \cntSCL[2]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \cntSCL[3]_i_2\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \cntSCL[5]_i_2\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \cntSCL[7]_i_3\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cntSCL[7]_i_4\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \cntSCL[7]_i_5\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \cntSCL[8]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \cntSCL[9]_i_1\ : label is "soft_lutpair7";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[0]\ : label is "spop3:00000,spop2:00010,spop1:00011,soutrdy:00100,sregbpush:00110,spop6:01000,sregawait:01001,spop5:01010,sregapush:01011,srdwait:01100,sreset:01101,srdgo:01110,saddrgo:00101,smodewait:10000,sidle:10001,saddrwait:01111,smodepush:10010,sregbwait:00111,spop4:00001";
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[1]\ : label is "spop3:00000,spop2:00010,spop1:00011,soutrdy:00100,sregbpush:00110,spop6:01000,sregawait:01001,spop5:01010,sregapush:01011,srdwait:01100,sreset:01101,srdgo:01110,saddrgo:00101,smodewait:10000,sidle:10001,saddrwait:01111,smodepush:10010,sregbwait:00111,spop4:00001";
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[2]\ : label is "spop3:00000,spop2:00010,spop1:00011,soutrdy:00100,sregbpush:00110,spop6:01000,sregawait:01001,spop5:01010,sregapush:01011,srdwait:01100,sreset:01101,srdgo:01110,saddrgo:00101,smodewait:10000,sidle:10001,saddrwait:01111,smodepush:10010,sregbwait:00111,spop4:00001";
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[3]\ : label is "spop3:00000,spop2:00010,spop1:00011,soutrdy:00100,sregbpush:00110,spop6:01000,sregawait:01001,spop5:01010,sregapush:01011,srdwait:01100,sreset:01101,srdgo:01110,saddrgo:00101,smodewait:10000,sidle:10001,saddrwait:01111,smodepush:10010,sregbwait:00111,spop4:00001";
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[4]\ : label is "spop3:00000,spop2:00010,spop1:00011,soutrdy:00100,sregbpush:00110,spop6:01000,sregawait:01001,spop5:01010,sregapush:01011,srdwait:01100,sreset:01101,srdgo:01110,saddrgo:00101,smodewait:10000,sidle:10001,saddrwait:01111,smodepush:10010,sregbwait:00111,spop4:00001";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[0]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[1]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[2]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[3]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[4]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[5]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute box_type : string;
  attribute box_type of \i_I2C/IOBUF_SCL\ : label is "PRIMITIVE";
  attribute box_type of \i_I2C/IOBUF_SDA\ : label is "PRIMITIVE";
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 128;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "MagnetoHMC5883L/i_I2C/i_FIFO/RAM_reg";
  attribute RTL_RAM_STYLE : string;
  attribute RTL_RAM_STYLE of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "auto";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 15;
  attribute ram_offset : integer;
  attribute ram_offset of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 7;
  attribute IOB : string;
  attribute IOB of \i_I2C/rSCLin_reg\ : label is "TRUE";
  attribute IOB of \i_I2C/rSDAin_reg\ : label is "TRUE";
  attribute SOFT_HLUTNM of \i_I2C/sregOut[2]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \i_I2C/sregOut[7]_i_5\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \sregOut[0]_i_2\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \sregOut[7]_i_3\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \sregOut[7]_i_6\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \sregOut[7]_i_7\ : label is "soft_lutpair13";
begin
  I2C_NACK <= \^i2c_nack\;
\DRX[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000004"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(4),
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(0),
      O => \DRX[11]_i_1_n_0\
    );
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FEAABAAA"
    )
        port map (
      I0 => \i_I2C/p_1_in\,
      I1 => \i_I2C/RdNotWr\,
      I2 => FIFO_Empty,
      I3 => \i_I2C/p_0_in\,
      I4 => \FSM_onehot_state[0]_i_2_n_0\,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state[0]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \i_I2C/cntBytes\(2),
      I1 => \i_I2C/cntBytes\(0),
      I2 => \i_I2C/cntBytes\(1),
      I3 => \i_I2C/cntBytes\(3),
      O => \FSM_onehot_state[0]_i_2_n_0\
    );
\FSM_onehot_state[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      O => \FSM_onehot_state[1]_i_1_n_0\
    );
\FSM_onehot_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888888888880"
    )
        port map (
      I0 => \i_I2C/p_0_in\,
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntBytes\(2),
      I3 => \i_I2C/cntBytes\(0),
      I4 => \i_I2C/cntBytes\(1),
      I5 => \i_I2C/cntBytes\(3),
      O => \FSM_onehot_state[2]_i_1_n_0\
    );
\FSM_onehot_state[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AAAE"
    )
        port map (
      I0 => \i_I2C/cntBits\,
      I1 => \i_I2C/p_0_in\,
      I2 => FIFO_Empty,
      I3 => \i_I2C/RdNotWr\,
      O => \FSM_onehot_state[3]_i_1_n_0\
    );
\FSM_onehot_state[5]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFAE"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sclEnd\,
      I2 => \FSM_onehot_state[5]_i_3_n_0\,
      I3 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      O => \FSM_onehot_state[5]_i_1_n_0\
    );
\FSM_onehot_state[5]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \i_I2C/cntSCL\,
      I1 => \FSM_onehot_state[5]_i_4_n_0\,
      O => \i_I2C/RdNotWr0\
    );
\FSM_onehot_state[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0001111101011111"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I1 => \i_I2C/cntBits\,
      I2 => \i_I2C/p_0_in\,
      I3 => \i_I2C/p_1_in\,
      I4 => \sregOut[7]_i_3_n_0\,
      I5 => \FSM_onehot_state[0]_i_2_n_0\,
      O => \FSM_onehot_state[5]_i_3_n_0\
    );
\FSM_onehot_state[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFD9FD7FFFDBFFFF"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(4),
      I4 => \i_Ctrl/state\(2),
      I5 => \i_Ctrl/cntPush\,
      O => \FSM_onehot_state[5]_i_4_n_0\
    );
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"07070707CF3FC003"
    )
        port map (
      I0 => \FSM_sequential_state[2]_i_2_n_0\,
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(2),
      I5 => \i_Ctrl/state\(4),
      O => \i_Ctrl/next_state\(0)
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1F141F00"
    )
        port map (
      I0 => \i_Ctrl/state\(4),
      I1 => \i_Ctrl/state\(3),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(0),
      I4 => \i_Ctrl/state\(2),
      O => \i_Ctrl/next_state\(1)
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"083C0B3F0B0F080C"
    )
        port map (
      I0 => \FSM_sequential_state[2]_i_2_n_0\,
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(0),
      I4 => \i_Ctrl/state\(3),
      I5 => \i_Ctrl/state\(2),
      O => \i_Ctrl/next_state\(2)
    );
\FSM_sequential_state[2]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \i_Ctrl/regDRDY_reg_n_0_[0]\,
      I1 => \i_Ctrl/p_0_in\,
      O => \FSM_sequential_state[2]_i_2_n_0\
    );
\FSM_sequential_state[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0222F0D0"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(1),
      O => \i_Ctrl/next_state\(3)
    );
\FSM_sequential_state[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF01"
    )
        port map (
      I0 => \FSM_sequential_state[4]_i_3_n_0\,
      I1 => \i_Ctrl/state\(3),
      I2 => \i_Ctrl/state\(2),
      I3 => \FSM_sequential_state[4]_i_4_n_0\,
      O => \FSM_sequential_state[4]_i_1_n_0\
    );
\FSM_sequential_state[4]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EC00"
    )
        port map (
      I0 => \i_Ctrl/state\(2),
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(1),
      O => \i_Ctrl/next_state\(4)
    );
\FSM_sequential_state[4]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F0FF1010F0FF1F1F"
    )
        port map (
      I0 => \FSM_sequential_state[2]_i_2_n_0\,
      I1 => \FSM_sequential_state[4]_i_5_n_0\,
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/cntPush\,
      I4 => \i_Ctrl/state\(1),
      I5 => \i_I2C/cntSCL\,
      O => \FSM_sequential_state[4]_i_3_n_0\
    );
\FSM_sequential_state[4]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAABABABAEABAFAB"
    )
        port map (
      I0 => \FSM_sequential_state[4]_i_6_n_0\,
      I1 => \i_Ctrl/state\(3),
      I2 => \i_Ctrl/state\(4),
      I3 => \i_Ctrl/state\(1),
      I4 => \i_Ctrl/state\(2),
      I5 => \i_Ctrl/state\(0),
      O => \FSM_sequential_state[4]_i_4_n_0\
    );
\FSM_sequential_state[4]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6FF6FFFFFFFF6FF6"
    )
        port map (
      I0 => current_OutputRate(1),
      I1 => OutputRate(1),
      I2 => current_OutputRate(2),
      I3 => OutputRate(2),
      I4 => OutputRate(0),
      I5 => current_OutputRate(0),
      O => \FSM_sequential_state[4]_i_5_n_0\
    );
\FSM_sequential_state[4]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4555400554455445"
    )
        port map (
      I0 => \i_Ctrl/state\(4),
      I1 => \i_I2C/cntSCL\,
      I2 => \i_Ctrl/state\(2),
      I3 => \i_Ctrl/state\(0),
      I4 => \i_Ctrl/cntPush\,
      I5 => \i_Ctrl/state\(1),
      O => \FSM_sequential_state[4]_i_6_n_0\
    );
NACK_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000055551000"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      I1 => NACK_i_2_n_0,
      I2 => \i_I2C/rSDAin\,
      I3 => NACK_i_3_n_0,
      I4 => \^i2c_nack\,
      I5 => Reset,
      O => NACK_i_1_n_0
    );
NACK_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFDF"
    )
        port map (
      I0 => \i_I2C/p_0_in\,
      I1 => \i_I2C/cntBits_reg_n_0_[2]\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      O => NACK_i_2_n_0
    );
NACK_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000100"
    )
        port map (
      I0 => NACK_i_4_n_0,
      I1 => NACK_i_5_n_0,
      I2 => L(6),
      I3 => L(5),
      I4 => NACK_i_6_n_0,
      I5 => NACK_i_7_n_0,
      O => NACK_i_3_n_0
    );
NACK_i_4: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEFF"
    )
        port map (
      I0 => L(11),
      I1 => L(10),
      I2 => L(8),
      I3 => L(7),
      O => NACK_i_4_n_0
    );
NACK_i_5: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BF"
    )
        port map (
      I0 => L(2),
      I1 => L(0),
      I2 => L(1),
      O => NACK_i_5_n_0
    );
NACK_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => L(4),
      I1 => L(3),
      O => NACK_i_6_n_0
    );
NACK_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => L(9),
      I1 => L(14),
      I2 => L(13),
      I3 => L(12),
      O => NACK_i_7_n_0
    );
RAM_reg_0_15_0_7_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000002222FF0F"
    )
        port map (
      I0 => \i_I2C/sclEnd\,
      I1 => RAM_reg_0_15_0_7_i_10_n_0,
      I2 => RAM_reg_0_15_0_7_i_11_n_0,
      I3 => RAM_reg_0_15_0_7_i_12_n_0,
      I4 => RAM_reg_0_15_0_7_i_13_n_0,
      I5 => iFull,
      O => DoPush
    );
RAM_reg_0_15_0_7_i_10: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FF7FFFFF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[0]\,
      I3 => \i_I2C/cntBits_reg_n_0_[3]\,
      I4 => \i_I2C/p_1_in\,
      O => RAM_reg_0_15_0_7_i_10_n_0
    );
RAM_reg_0_15_0_7_i_11: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FEBDFFFF"
    )
        port map (
      I0 => \i_Ctrl/state\(4),
      I1 => \i_Ctrl/state\(3),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(1),
      O => RAM_reg_0_15_0_7_i_11_n_0
    );
RAM_reg_0_15_0_7_i_12: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000040"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(4),
      I4 => \i_Ctrl/state\(3),
      O => RAM_reg_0_15_0_7_i_12_n_0
    );
RAM_reg_0_15_0_7_i_13: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \i_I2C/RdNotWr\,
      I1 => \i_I2C/cntSCL\,
      O => RAM_reg_0_15_0_7_i_13_n_0
    );
RAM_reg_0_15_0_7_i_14: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFFFF9FFEFFFFDFF"
    )
        port map (
      I0 => \i_Ctrl/state\(2),
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(1),
      I4 => \i_Ctrl/state\(0),
      I5 => \i_Ctrl/cntPush\,
      O => RAM_reg_0_15_0_7_i_14_n_0
    );
RAM_reg_0_15_0_7_i_15: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000400"
    )
        port map (
      I0 => \i_Ctrl/cntPush\,
      I1 => \i_Ctrl/state\(1),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(4),
      I5 => \i_Ctrl/state\(3),
      O => RAM_reg_0_15_0_7_i_15_n_0
    );
RAM_reg_0_15_0_7_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => sregIn(1),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => RAM_reg_0_15_0_7_i_14_n_0,
      O => DI(1)
    );
RAM_reg_0_15_0_7_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FBFBFB08"
    )
        port map (
      I0 => sregIn(0),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => RAM_reg_0_15_0_7_i_15_n_0,
      I4 => RAM_reg_0_15_0_7_i_11_n_0,
      O => DI(0)
    );
RAM_reg_0_15_0_7_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FB080808"
    )
        port map (
      I0 => sregIn(3),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => OutputRate(1),
      I4 => \i_Ctrl/current_OutputRate0\,
      O => DI(3)
    );
RAM_reg_0_15_0_7_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FB080808"
    )
        port map (
      I0 => sregIn(2),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => OutputRate(0),
      I4 => \i_Ctrl/current_OutputRate0\,
      O => DI(2)
    );
RAM_reg_0_15_0_7_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => sregIn(5),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => \i_Ctrl/current_OutputRate0\,
      O => DI(5)
    );
RAM_reg_0_15_0_7_i_7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FB080808"
    )
        port map (
      I0 => sregIn(4),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => OutputRate(2),
      I4 => \i_Ctrl/current_OutputRate0\,
      O => DI(4)
    );
RAM_reg_0_15_0_7_i_8: unisim.vcomponents.LUT3
    generic map(
      INIT => X"20"
    )
        port map (
      I0 => sregIn(7),
      I1 => \i_I2C/cntSCL\,
      I2 => \i_I2C/RdNotWr\,
      O => DI(7)
    );
RAM_reg_0_15_0_7_i_9: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FB08"
    )
        port map (
      I0 => sregIn(6),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => \i_Ctrl/current_OutputRate0\,
      O => DI(6)
    );
RdNotWr_i_1: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => Address(0),
      I1 => \i_I2C/RdNotWr0\,
      I2 => \i_I2C/RdNotWr\,
      O => RdNotWr_i_1_n_0
    );
SCLout_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFDFCCCF0C0ECC0F"
    )
        port map (
      I0 => SCLout_i_2_n_0,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I2 => SCLout_i_3_n_0,
      I3 => \i_I2C/cntBits\,
      I4 => SCLout_i_4_n_0,
      I5 => \i_I2C/SCLout_reg_n_0\,
      O => SCLout_i_1_n_0
    );
SCLout_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000008"
    )
        port map (
      I0 => \cntSCL[7]_i_3_n_0\,
      I1 => L(5),
      I2 => L(6),
      I3 => SCLout_i_5_n_0,
      I4 => \cntSCL[7]_i_5_n_0\,
      O => SCLout_i_2_n_0
    );
SCLout_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFBFFFF"
    )
        port map (
      I0 => \cntBits[3]_i_5_n_0\,
      I1 => L(5),
      I2 => L(11),
      I3 => L(10),
      I4 => L(4),
      I5 => SCLout_i_6_n_0,
      O => SCLout_i_3_n_0
    );
SCLout_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFBFFFFFFFFFFFFF"
    )
        port map (
      I0 => SCLout_i_7_n_0,
      I1 => SCLout_i_8_n_0,
      I2 => SCLout_i_9_n_0,
      I3 => L(2),
      I4 => L(0),
      I5 => L(1),
      O => SCLout_i_4_n_0
    );
SCLout_i_5: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FD"
    )
        port map (
      I0 => L(3),
      I1 => L(7),
      I2 => L(8),
      O => SCLout_i_5_n_0
    );
SCLout_i_6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFFFF"
    )
        port map (
      I0 => \cntSCL[7]_i_5_n_0\,
      I1 => L(6),
      I2 => L(8),
      I3 => L(7),
      I4 => L(3),
      O => SCLout_i_6_n_0
    );
SCLout_i_7: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFB"
    )
        port map (
      I0 => \cntBits[3]_i_6_n_0\,
      I1 => L(7),
      I2 => L(8),
      I3 => \cntBits[3]_i_5_n_0\,
      O => SCLout_i_7_n_0
    );
SCLout_i_8: unisim.vcomponents.LUT3
    generic map(
      INIT => X"D5"
    )
        port map (
      I0 => L(5),
      I1 => L(3),
      I2 => L(4),
      O => SCLout_i_8_n_0
    );
SCLout_i_9: unisim.vcomponents.LUT3
    generic map(
      INIT => X"07"
    )
        port map (
      I0 => L(7),
      I1 => L(6),
      I2 => L(8),
      O => SCLout_i_9_n_0
    );
SDAout_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D000D0D0D0000000"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I1 => \sregOut[7]_i_4_n_0\,
      I2 => SDAout_i_2_n_0,
      I3 => \i_I2C/SDAout\,
      I4 => SDAout_i_4_n_0,
      I5 => \i_I2C/T\,
      O => SDAout_i_1_n_0
    );
SDAout_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFFFFFF"
    )
        port map (
      I0 => SDAout_i_5_n_0,
      I1 => \cntBits[3]_i_5_n_0\,
      I2 => L(8),
      I3 => L(10),
      I4 => L(11),
      I5 => SDAout_i_6_n_0,
      O => SDAout_i_2_n_0
    );
SDAout_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FBFFFBFBFBEEFBFB"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I1 => \sregOut[7]_i_3_n_0\,
      I2 => \FSM_onehot_state[0]_i_2_n_0\,
      I3 => \sregOut[7]_i_4_n_0\,
      I4 => \i_I2C/p_0_in\,
      I5 => sregOut(7),
      O => \i_I2C/SDAout\
    );
SDAout_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF01010100"
    )
        port map (
      I0 => \sregOut[7]_i_4_n_0\,
      I1 => \i_I2C/cntBits\,
      I2 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I3 => \i_I2C/p_1_in\,
      I4 => \i_I2C/p_0_in\,
      I5 => SDAout_i_7_n_0,
      O => SDAout_i_4_n_0
    );
SDAout_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFF4FFF"
    )
        port map (
      I0 => L(1),
      I1 => L(0),
      I2 => L(2),
      I3 => \i_I2C/cntBits\,
      I4 => L(3),
      I5 => L(7),
      O => SDAout_i_5_n_0
    );
SDAout_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000DC0000"
    )
        port map (
      I0 => L(7),
      I1 => L(8),
      I2 => L(6),
      I3 => L(1),
      I4 => L(5),
      I5 => L(4),
      O => SDAout_i_6_n_0
    );
SDAout_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000400000"
    )
        port map (
      I0 => \cntSCL[7]_i_5_n_0\,
      I1 => SCLout_i_9_n_0,
      I2 => SDAout_i_8_n_0,
      I3 => \sregOut[7]_i_7_n_0\,
      I4 => L(7),
      I5 => \cntBits[3]_i_5_n_0\,
      O => SDAout_i_7_n_0
    );
SDAout_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => L(3),
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I2 => L(5),
      I3 => L(4),
      O => SDAout_i_8_n_0
    );
\addrRd[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000EEFE"
    )
        port map (
      I0 => \i_I2C/RdNotWr\,
      I1 => \i_I2C/cntSCL\,
      I2 => \i_I2C/sclEnd\,
      I3 => NACK_i_2_n_0,
      I4 => \addrRd[0]_i_3_n_0\,
      I5 => FIFO_Empty,
      O => \i_I2C/i_FIFO/p_1_in\
    );
\addrRd[0]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => \i_I2C/i_FIFO/plusOp0_in\(0)
    );
\addrRd[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EEEEEEEEEEE0E0E0"
    )
        port map (
      I0 => \i_I2C/RdNotWr\,
      I1 => \i_I2C/cntSCL\,
      I2 => \i_Ctrl/state\(4),
      I3 => \i_Ctrl/state\(0),
      I4 => \i_Ctrl/state\(3),
      I5 => \i_Ctrl/state\(2),
      O => \addrRd[0]_i_3_n_0\
    );
\addrRd[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      O => \i_I2C/i_FIFO/plusOp0_in\(1)
    );
\addrRd[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => \i_I2C/i_FIFO/plusOp0_in\(2)
    );
\addrRd[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(3),
      O => \i_I2C/i_FIFO/plusOp0_in\(3)
    );
\addrWr[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => addrWr_reg(0),
      O => \addrWr[0]_i_1_n_0\
    );
\addrWr[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => addrWr_reg(0),
      I1 => addrWr_reg(1),
      O => \addrWr[1]_i_1_n_0\
    );
\addrWr[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => addrWr_reg(2),
      I1 => addrWr_reg(1),
      I2 => addrWr_reg(0),
      O => \addrWr[2]_i_1_n_0\
    );
\addrWr[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => addrWr_reg(2),
      I1 => addrWr_reg(1),
      I2 => addrWr_reg(0),
      I3 => addrWr_reg(3),
      O => \addrWr[3]_i_1_n_0\
    );
\cntBits[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0F0B"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[0]\,
      I3 => \i_I2C/cntBits_reg_n_0_[1]\,
      O => \cntBits[0]_i_1_n_0\
    );
\cntBits[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[0]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      O => \cntBits[1]_i_1_n_0\
    );
\cntBits[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[0]\,
      O => \cntBits[2]_i_1_n_0\
    );
\cntBits[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000040000"
    )
        port map (
      I0 => \cntBits[3]_i_3_n_0\,
      I1 => \cntBits[3]_i_4_n_0\,
      I2 => \cntBits[3]_i_5_n_0\,
      I3 => L(8),
      I4 => L(7),
      I5 => \cntBits[3]_i_6_n_0\,
      O => \i_I2C/sclEnd\
    );
\cntBits[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7E80"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[0]\,
      I3 => \i_I2C/cntBits_reg_n_0_[3]\,
      O => \cntBits[3]_i_2_n_0\
    );
\cntBits[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"15151515FFFF15FF"
    )
        port map (
      I0 => L(8),
      I1 => L(6),
      I2 => L(7),
      I3 => L(0),
      I4 => L(1),
      I5 => L(2),
      O => \cntBits[3]_i_3_n_0\
    );
\cntBits[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000008F"
    )
        port map (
      I0 => L(4),
      I1 => L(3),
      I2 => L(5),
      I3 => L(2),
      I4 => L(1),
      O => \cntBits[3]_i_4_n_0\
    );
\cntBits[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFF2"
    )
        port map (
      I0 => L(9),
      I1 => L(10),
      I2 => L(11),
      I3 => L(14),
      I4 => L(13),
      I5 => L(12),
      O => \cntBits[3]_i_5_n_0\
    );
\cntBits[3]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FDFF"
    )
        port map (
      I0 => L(5),
      I1 => L(11),
      I2 => L(10),
      I3 => L(4),
      O => \cntBits[3]_i_6_n_0\
    );
\cntBytes[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_I2C/cntBytes\(0),
      I1 => \i_I2C/RdNotWr0\,
      O => \cntBytes[0]_i_1_n_0\
    );
\cntBytes[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EB"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/cntBytes\(1),
      I2 => \i_I2C/cntBytes\(0),
      O => \cntBytes[1]_i_1_n_0\
    );
\cntBytes[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEAB"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/cntBytes\(0),
      I2 => \i_I2C/cntBytes\(1),
      I3 => \i_I2C/cntBytes\(2),
      O => \cntBytes[2]_i_1_n_0\
    );
\cntBytes[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \cntBytes[3]_i_3_n_0\,
      I1 => \i_I2C/RdNotWr0\,
      O => \cntBytes[3]_i_1_n_0\
    );
\cntBytes[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0000FE01"
    )
        port map (
      I0 => \i_I2C/cntBytes\(1),
      I1 => \i_I2C/cntBytes\(0),
      I2 => \i_I2C/cntBytes\(2),
      I3 => \i_I2C/cntBytes\(3),
      I4 => \i_I2C/RdNotWr0\,
      O => \cntBytes[3]_i_2_n_0\
    );
\cntBytes[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0800000000000000"
    )
        port map (
      I0 => \i_I2C/sclEnd\,
      I1 => \i_I2C/p_1_in\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => \i_I2C/cntBits_reg_n_0_[2]\,
      O => \cntBytes[3]_i_3_n_0\
    );
cntPush_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000404000040"
    )
        port map (
      I0 => \i_Ctrl/cntPush\,
      I1 => \i_Ctrl/state\(1),
      I2 => \i_Ctrl/state\(2),
      I3 => \i_Ctrl/state\(0),
      I4 => \i_Ctrl/state\(3),
      I5 => \i_Ctrl/state\(4),
      O => cntPush_i_1_n_0
    );
\cntSCL[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"AA03"
    )
        port map (
      I0 => rSCLin,
      I1 => L(0),
      I2 => \i_I2C/sclEnd\,
      I3 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(0)
    );
\cntSCL[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A6AAAAAAAAAAAAAA"
    )
        port map (
      I0 => L(10),
      I1 => L(7),
      I2 => \cntSCL[10]_i_2_n_0\,
      I3 => L(6),
      I4 => L(8),
      I5 => L(9),
      O => \i_I2C/cntSCL__0\(10)
    );
\cntSCL[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => L(0),
      I1 => L(1),
      I2 => L(2),
      I3 => L(4),
      I4 => L(3),
      I5 => L(5),
      O => \cntSCL[10]_i_2_n_0\
    );
\cntSCL[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => L(11),
      I1 => \cntSCL[14]_i_2_n_0\,
      I2 => L(10),
      O => \i_I2C/cntSCL__0\(11)
    );
\cntSCL[12]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => L(12),
      I1 => L(10),
      I2 => \cntSCL[14]_i_2_n_0\,
      I3 => L(11),
      O => \i_I2C/cntSCL__0\(12)
    );
\cntSCL[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => L(13),
      I1 => L(11),
      I2 => \cntSCL[14]_i_2_n_0\,
      I3 => L(10),
      I4 => L(12),
      O => \i_I2C/cntSCL__0\(13)
    );
\cntSCL[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => L(14),
      I1 => L(12),
      I2 => L(10),
      I3 => \cntSCL[14]_i_2_n_0\,
      I4 => L(11),
      I5 => L(13),
      O => \i_I2C/cntSCL__0\(14)
    );
\cntSCL[14]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00800000"
    )
        port map (
      I0 => L(9),
      I1 => L(8),
      I2 => L(6),
      I3 => \cntSCL[10]_i_2_n_0\,
      I4 => L(7),
      O => \cntSCL[14]_i_2_n_0\
    );
\cntSCL[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"06"
    )
        port map (
      I0 => L(0),
      I1 => L(1),
      I2 => \i_I2C/sclEnd\,
      O => \i_I2C/cntSCL__0\(1)
    );
\cntSCL[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => L(2),
      I1 => L(0),
      I2 => L(1),
      O => \cntSCL[2]_i_1_n_0\
    );
\cntSCL[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"555500C3"
    )
        port map (
      I0 => rSCLin,
      I1 => L(3),
      I2 => \cntSCL[3]_i_2_n_0\,
      I3 => \i_I2C/sclEnd\,
      I4 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(3)
    );
\cntSCL[3]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => L(0),
      I1 => L(1),
      I2 => L(2),
      O => \cntSCL[3]_i_2_n_0\
    );
\cntSCL[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000007FFF8000"
    )
        port map (
      I0 => L(3),
      I1 => L(2),
      I2 => L(1),
      I3 => L(0),
      I4 => L(4),
      I5 => \i_I2C/sclEnd\,
      O => \i_I2C/cntSCL__0\(4)
    );
\cntSCL[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"555500C3"
    )
        port map (
      I0 => rSCLin,
      I1 => L(5),
      I2 => \cntSCL[5]_i_2_n_0\,
      I3 => \i_I2C/sclEnd\,
      I4 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(5)
    );
\cntSCL[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFFFFFF"
    )
        port map (
      I0 => L(3),
      I1 => L(4),
      I2 => L(2),
      I3 => L(1),
      I4 => L(0),
      O => \cntSCL[5]_i_2_n_0\
    );
\cntSCL[6]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00FF0909"
    )
        port map (
      I0 => L(6),
      I1 => \cntSCL[10]_i_2_n_0\,
      I2 => \i_I2C/sclEnd\,
      I3 => rSCLin,
      I4 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(6)
    );
\cntSCL[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF00A6000000A6"
    )
        port map (
      I0 => L(7),
      I1 => L(6),
      I2 => \cntSCL[10]_i_2_n_0\,
      I3 => \i_I2C/sclEnd\,
      I4 => \cntSCL[7]_i_2_n_0\,
      I5 => rSCLin,
      O => \i_I2C/cntSCL__0\(7)
    );
\cntSCL[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000800"
    )
        port map (
      I0 => \cntSCL[7]_i_3_n_0\,
      I1 => \cntSCL[7]_i_4_n_0\,
      I2 => L(3),
      I3 => L(7),
      I4 => L(5),
      I5 => \cntSCL[7]_i_5_n_0\,
      O => \cntSCL[7]_i_2_n_0\
    );
\cntSCL[7]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => L(11),
      I1 => L(10),
      I2 => L(4),
      I3 => NACK_i_7_n_0,
      O => \cntSCL[7]_i_3_n_0\
    );
\cntSCL[7]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => L(8),
      I1 => L(6),
      O => \cntSCL[7]_i_4_n_0\
    );
\cntSCL[7]_i_5\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"DF"
    )
        port map (
      I0 => L(1),
      I1 => L(0),
      I2 => L(2),
      O => \cntSCL[7]_i_5_n_0\
    );
\cntSCL[8]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"A6AA"
    )
        port map (
      I0 => L(8),
      I1 => L(6),
      I2 => \cntSCL[10]_i_2_n_0\,
      I3 => L(7),
      O => \i_I2C/cntSCL__0\(8)
    );
\cntSCL[9]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"DFFF2000"
    )
        port map (
      I0 => L(7),
      I1 => \cntSCL[10]_i_2_n_0\,
      I2 => L(6),
      I3 => L(8),
      I4 => L(9),
      O => \i_I2C/cntSCL__0\(9)
    );
\current_OutputRate[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000008000"
    )
        port map (
      I0 => \i_Ctrl/cntPush\,
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(4),
      I5 => \i_Ctrl/state\(2),
      O => \i_Ctrl/current_OutputRate0\
    );
\iDRX[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00100000"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(1),
      O => \iDRX[11]_i_1_n_0\
    );
\iDRX[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00010000"
    )
        port map (
      I0 => \i_Ctrl/state\(4),
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(1),
      O => \iDRX[7]_i_1_n_0\
    );
\iDRY[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00100000"
    )
        port map (
      I0 => \i_Ctrl/state\(2),
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(0),
      I4 => \i_Ctrl/state\(1),
      O => \iDRY[11]_i_1_n_0\
    );
\iDRY[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000002"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(1),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(4),
      I4 => \i_Ctrl/state\(2),
      O => \iDRY[7]_i_1_n_0\
    );
\iDRZ[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \i_Ctrl/state\(4),
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(1),
      O => \i_Ctrl/iDRZ_reg0\
    );
\iDRZ[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000010"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(1),
      O => \iDRZ[7]_i_1_n_0\
    );
iEmpty_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00005510"
    )
        port map (
      I0 => DoPush,
      I1 => iEmpty_i_2_n_0,
      I2 => \i_I2C/i_FIFO/p_1_in\,
      I3 => FIFO_Empty,
      I4 => Reset,
      O => iEmpty_i_1_n_0
    );
iEmpty_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EBBBBBBBBEEEEEEE"
    )
        port map (
      I0 => iEmpty_i_3_n_0,
      I1 => \i_I2C/i_FIFO/addrRd_reg\(3),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I4 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I5 => addrWr_reg(3),
      O => iEmpty_i_2_n_0
    );
iEmpty_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7BFFDEFEFF7BFFD"
    )
        port map (
      I0 => addrWr_reg(0),
      I1 => addrWr_reg(2),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I4 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I5 => addrWr_reg(1),
      O => iEmpty_i_3_n_0
    );
iFull_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00005510"
    )
        port map (
      I0 => \i_I2C/i_FIFO/p_1_in\,
      I1 => iFull_i_2_n_0,
      I2 => DoPush,
      I3 => iFull,
      I4 => Reset,
      O => iFull_i_1_n_0
    );
iFull_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EBBBBBBBBEEEEEEE"
    )
        port map (
      I0 => iFull_i_3_n_0,
      I1 => addrWr_reg(3),
      I2 => addrWr_reg(0),
      I3 => addrWr_reg(1),
      I4 => addrWr_reg(2),
      I5 => \i_I2C/i_FIFO/addrRd_reg\(3),
      O => iFull_i_2_n_0
    );
iFull_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF6FF6F96FFFFF"
    )
        port map (
      I0 => addrWr_reg(2),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I3 => addrWr_reg(1),
      I4 => addrWr_reg(0),
      I5 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => iFull_i_3_n_0
    );
\i_Ctrl/DRX_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(0),
      Q => DRX(0),
      R => '0'
    );
\i_Ctrl/DRX_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(10),
      Q => DRX(10),
      R => '0'
    );
\i_Ctrl/DRX_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(11),
      Q => DRX(11),
      R => '0'
    );
\i_Ctrl/DRX_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(1),
      Q => DRX(1),
      R => '0'
    );
\i_Ctrl/DRX_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(2),
      Q => DRX(2),
      R => '0'
    );
\i_Ctrl/DRX_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(3),
      Q => DRX(3),
      R => '0'
    );
\i_Ctrl/DRX_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(4),
      Q => DRX(4),
      R => '0'
    );
\i_Ctrl/DRX_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(5),
      Q => DRX(5),
      R => '0'
    );
\i_Ctrl/DRX_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(6),
      Q => DRX(6),
      R => '0'
    );
\i_Ctrl/DRX_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(7),
      Q => DRX(7),
      R => '0'
    );
\i_Ctrl/DRX_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(8),
      Q => DRX(8),
      R => '0'
    );
\i_Ctrl/DRX_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRX(9),
      Q => DRX(9),
      R => '0'
    );
\i_Ctrl/DRY_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(0),
      Q => DRY(0),
      R => '0'
    );
\i_Ctrl/DRY_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(10),
      Q => DRY(10),
      R => '0'
    );
\i_Ctrl/DRY_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(11),
      Q => DRY(11),
      R => '0'
    );
\i_Ctrl/DRY_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(1),
      Q => DRY(1),
      R => '0'
    );
\i_Ctrl/DRY_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(2),
      Q => DRY(2),
      R => '0'
    );
\i_Ctrl/DRY_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(3),
      Q => DRY(3),
      R => '0'
    );
\i_Ctrl/DRY_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(4),
      Q => DRY(4),
      R => '0'
    );
\i_Ctrl/DRY_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(5),
      Q => DRY(5),
      R => '0'
    );
\i_Ctrl/DRY_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(6),
      Q => DRY(6),
      R => '0'
    );
\i_Ctrl/DRY_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(7),
      Q => DRY(7),
      R => '0'
    );
\i_Ctrl/DRY_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(8),
      Q => DRY(8),
      R => '0'
    );
\i_Ctrl/DRY_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRY(9),
      Q => DRY(9),
      R => '0'
    );
\i_Ctrl/DRZ_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(0),
      Q => DRZ(0),
      R => '0'
    );
\i_Ctrl/DRZ_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(10),
      Q => DRZ(10),
      R => '0'
    );
\i_Ctrl/DRZ_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(11),
      Q => DRZ(11),
      R => '0'
    );
\i_Ctrl/DRZ_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(1),
      Q => DRZ(1),
      R => '0'
    );
\i_Ctrl/DRZ_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(2),
      Q => DRZ(2),
      R => '0'
    );
\i_Ctrl/DRZ_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(3),
      Q => DRZ(3),
      R => '0'
    );
\i_Ctrl/DRZ_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(4),
      Q => DRZ(4),
      R => '0'
    );
\i_Ctrl/DRZ_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(5),
      Q => DRZ(5),
      R => '0'
    );
\i_Ctrl/DRZ_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(6),
      Q => DRZ(6),
      R => '0'
    );
\i_Ctrl/DRZ_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(7),
      Q => DRZ(7),
      R => '0'
    );
\i_Ctrl/DRZ_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(8),
      Q => DRZ(8),
      R => '0'
    );
\i_Ctrl/DRZ_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \DRX[11]_i_1_n_0\,
      D => iDRZ(9),
      Q => DRZ(9),
      R => '0'
    );
\i_Ctrl/FSM_sequential_state_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[4]_i_1_n_0\,
      D => \i_Ctrl/next_state\(0),
      Q => \i_Ctrl/state\(0),
      S => Reset
    );
\i_Ctrl/FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[4]_i_1_n_0\,
      D => \i_Ctrl/next_state\(1),
      Q => \i_Ctrl/state\(1),
      R => Reset
    );
\i_Ctrl/FSM_sequential_state_reg[2]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[4]_i_1_n_0\,
      D => \i_Ctrl/next_state\(2),
      Q => \i_Ctrl/state\(2),
      S => Reset
    );
\i_Ctrl/FSM_sequential_state_reg[3]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[4]_i_1_n_0\,
      D => \i_Ctrl/next_state\(3),
      Q => \i_Ctrl/state\(3),
      S => Reset
    );
\i_Ctrl/FSM_sequential_state_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[4]_i_1_n_0\,
      D => \i_Ctrl/next_state\(4),
      Q => \i_Ctrl/state\(4),
      R => Reset
    );
\i_Ctrl/NewData_reg\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => \DRX[11]_i_1_n_0\,
      Q => NewData,
      R => '0'
    );
\i_Ctrl/cntPush_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => cntPush_i_1_n_0,
      Q => \i_Ctrl/cntPush\,
      R => '0'
    );
\i_Ctrl/current_OutputRate_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/current_OutputRate0\,
      D => OutputRate(0),
      Q => current_OutputRate(0),
      R => '0'
    );
\i_Ctrl/current_OutputRate_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/current_OutputRate0\,
      D => OutputRate(1),
      Q => current_OutputRate(1),
      R => '0'
    );
\i_Ctrl/current_OutputRate_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/current_OutputRate0\,
      D => OutputRate(2),
      Q => current_OutputRate(2),
      R => '0'
    );
\i_Ctrl/iDRX_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(0),
      Q => iDRX(0),
      R => '0'
    );
\i_Ctrl/iDRX_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[11]_i_1_n_0\,
      D => DO(2),
      Q => iDRX(10),
      R => '0'
    );
\i_Ctrl/iDRX_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[11]_i_1_n_0\,
      D => DO(3),
      Q => iDRX(11),
      R => '0'
    );
\i_Ctrl/iDRX_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(1),
      Q => iDRX(1),
      R => '0'
    );
\i_Ctrl/iDRX_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(2),
      Q => iDRX(2),
      R => '0'
    );
\i_Ctrl/iDRX_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(3),
      Q => iDRX(3),
      R => '0'
    );
\i_Ctrl/iDRX_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(4),
      Q => iDRX(4),
      R => '0'
    );
\i_Ctrl/iDRX_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(5),
      Q => iDRX(5),
      R => '0'
    );
\i_Ctrl/iDRX_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(6),
      Q => iDRX(6),
      R => '0'
    );
\i_Ctrl/iDRX_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[7]_i_1_n_0\,
      D => DO(7),
      Q => iDRX(7),
      R => '0'
    );
\i_Ctrl/iDRX_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[11]_i_1_n_0\,
      D => DO(0),
      Q => iDRX(8),
      R => '0'
    );
\i_Ctrl/iDRX_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRX[11]_i_1_n_0\,
      D => DO(1),
      Q => iDRX(9),
      R => '0'
    );
\i_Ctrl/iDRY_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(0),
      Q => iDRY(0),
      R => '0'
    );
\i_Ctrl/iDRY_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[11]_i_1_n_0\,
      D => DO(2),
      Q => iDRY(10),
      R => '0'
    );
\i_Ctrl/iDRY_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[11]_i_1_n_0\,
      D => DO(3),
      Q => iDRY(11),
      R => '0'
    );
\i_Ctrl/iDRY_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(1),
      Q => iDRY(1),
      R => '0'
    );
\i_Ctrl/iDRY_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(2),
      Q => iDRY(2),
      R => '0'
    );
\i_Ctrl/iDRY_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(3),
      Q => iDRY(3),
      R => '0'
    );
\i_Ctrl/iDRY_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(4),
      Q => iDRY(4),
      R => '0'
    );
\i_Ctrl/iDRY_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(5),
      Q => iDRY(5),
      R => '0'
    );
\i_Ctrl/iDRY_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(6),
      Q => iDRY(6),
      R => '0'
    );
\i_Ctrl/iDRY_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[7]_i_1_n_0\,
      D => DO(7),
      Q => iDRY(7),
      R => '0'
    );
\i_Ctrl/iDRY_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[11]_i_1_n_0\,
      D => DO(0),
      Q => iDRY(8),
      R => '0'
    );
\i_Ctrl/iDRY_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRY[11]_i_1_n_0\,
      D => DO(1),
      Q => iDRY(9),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(0),
      Q => iDRZ(0),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/iDRZ_reg0\,
      D => DO(2),
      Q => iDRZ(10),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/iDRZ_reg0\,
      D => DO(3),
      Q => iDRZ(11),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(1),
      Q => iDRZ(1),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(2),
      Q => iDRZ(2),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(3),
      Q => iDRZ(3),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(4),
      Q => iDRZ(4),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(5),
      Q => iDRZ(5),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(6),
      Q => iDRZ(6),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \iDRZ[7]_i_1_n_0\,
      D => DO(7),
      Q => iDRZ(7),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/iDRZ_reg0\,
      D => DO(0),
      Q => iDRZ(8),
      R => '0'
    );
\i_Ctrl/iDRZ_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/iDRZ_reg0\,
      D => DO(1),
      Q => iDRZ(9),
      R => '0'
    );
\i_Ctrl/regDRDY_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_Ctrl/p_0_in\,
      Q => \i_Ctrl/regDRDY_reg_n_0_[0]\,
      R => '0'
    );
\i_Ctrl/regDRDY_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => Magneto_DRDY,
      Q => \i_Ctrl/p_0_in\,
      R => '0'
    );
\i_I2C/FSM_onehot_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[1]_i_1_n_0\,
      Q => \i_I2C/cntSCL\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[2]_i_1_n_0\,
      Q => \i_I2C/p_1_in\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[3]_i_1_n_0\,
      Q => \i_I2C/p_0_in\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \i_I2C/cntSCL\,
      Q => \i_I2C/cntBits\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[5]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => '0',
      Q => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      S => Reset
    );
\i_I2C/IOBUF_SCL\: unisim.vcomponents.IOBUF
    generic map(
      IOSTANDARD => "DEFAULT"
    )
        port map (
      I => '0',
      IO => Magneto_SCL,
      O => \i_I2C/SCLin\,
      T => \i_I2C/SCLout_reg_n_0\
    );
\i_I2C/IOBUF_SDA\: unisim.vcomponents.IOBUF
    generic map(
      IOSTANDARD => "DEFAULT"
    )
        port map (
      I => '0',
      IO => Magneto_SDA,
      O => \i_I2C/SDAin\,
      T => \i_I2C/T\
    );
\i_I2C/NACK_reg\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => NACK_i_1_n_0,
      Q => \^i2c_nack\,
      R => '0'
    );
\i_I2C/RdNotWr_reg\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => RdNotWr_i_1_n_0,
      Q => \i_I2C/RdNotWr\,
      R => '0'
    );
\i_I2C/SCLout_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => SCLout_i_1_n_0,
      Q => \i_I2C/SCLout_reg_n_0\,
      R => '0'
    );
\i_I2C/SDAout_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => SDAout_i_1_n_0,
      Q => \i_I2C/T\,
      R => '0'
    );
\i_I2C/cntBits_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[0]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[0]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[1]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[1]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[2]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[2]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[3]_i_2_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[3]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBytes_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[0]_i_1_n_0\,
      Q => \i_I2C/cntBytes\(0),
      R => '0'
    );
\i_I2C/cntBytes_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[1]_i_1_n_0\,
      Q => \i_I2C/cntBytes\(1),
      R => '0'
    );
\i_I2C/cntBytes_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[2]_i_1_n_0\,
      Q => \i_I2C/cntBytes\(2),
      R => '0'
    );
\i_I2C/cntBytes_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[3]_i_2_n_0\,
      Q => \i_I2C/cntBytes\(3),
      R => '0'
    );
\i_I2C/cntSCL_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(0),
      Q => L(0),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(10),
      Q => L(10),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(11),
      Q => L(11),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(12),
      Q => L(12),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(13),
      Q => L(13),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(14),
      Q => L(14),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(1),
      Q => L(1),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \cntSCL[2]_i_1_n_0\,
      Q => L(2),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(3),
      Q => L(3),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(4),
      Q => L(4),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(5),
      Q => L(5),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(6),
      Q => L(6),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(7),
      Q => L(7),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(8),
      Q => L(8),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(9),
      Q => L(9),
      R => \i_I2C/cntSCL\
    );
\i_I2C/i_FIFO/RAM_reg_0_15_0_7\: unisim.vcomponents.RAM32M16
     port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRE(4) => '0',
      ADDRE(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRF(4) => '0',
      ADDRF(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRG(4) => '0',
      ADDRG(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRH(4) => '0',
      ADDRH(3 downto 0) => addrWr_reg(3 downto 0),
      DIA(1 downto 0) => DI(1 downto 0),
      DIB(1 downto 0) => DI(3 downto 2),
      DIC(1 downto 0) => DI(5 downto 4),
      DID(1 downto 0) => DI(7 downto 6),
      DIE(1 downto 0) => B"00",
      DIF(1 downto 0) => B"00",
      DIG(1 downto 0) => B"00",
      DIH(1 downto 0) => B"00",
      DOA(1 downto 0) => DO(1 downto 0),
      DOB(1 downto 0) => DO(3 downto 2),
      DOC(1 downto 0) => DO(5 downto 4),
      DOD(1 downto 0) => DO(7 downto 6),
      DOE(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOE_UNCONNECTED\(1 downto 0),
      DOF(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOF_UNCONNECTED\(1 downto 0),
      DOG(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOG_UNCONNECTED\(1 downto 0),
      DOH(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOH_UNCONNECTED\(1 downto 0),
      WCLK => Clk_100MHz,
      WE => DoPush
    );
\i_I2C/i_FIFO/addrRd_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(0),
      Q => \i_I2C/i_FIFO/addrRd_reg\(0),
      R => Reset
    );
\i_I2C/i_FIFO/addrRd_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(1),
      Q => \i_I2C/i_FIFO/addrRd_reg\(1),
      R => Reset
    );
\i_I2C/i_FIFO/addrRd_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(2),
      Q => \i_I2C/i_FIFO/addrRd_reg\(2),
      R => Reset
    );
\i_I2C/i_FIFO/addrRd_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(3),
      Q => \i_I2C/i_FIFO/addrRd_reg\(3),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[0]_i_1_n_0\,
      Q => addrWr_reg(0),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[1]_i_1_n_0\,
      Q => addrWr_reg(1),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[2]_i_1_n_0\,
      Q => addrWr_reg(2),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[3]_i_1_n_0\,
      Q => addrWr_reg(3),
      R => Reset
    );
\i_I2C/i_FIFO/iEmpty_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => iEmpty_i_1_n_0,
      Q => FIFO_Empty,
      R => '0'
    );
\i_I2C/i_FIFO/iFull_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => iFull_i_1_n_0,
      Q => iFull,
      R => '0'
    );
\i_I2C/rSCLin_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/SCLin\,
      Q => rSCLin,
      R => '0'
    );
\i_I2C/rSDAin_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/SDAin\,
      Q => \i_I2C/rSDAin\,
      R => '0'
    );
\i_I2C/sregIn_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => \i_I2C/rSDAin\,
      Q => sregIn(0),
      R => '0'
    );
\i_I2C/sregIn_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => sregIn(0),
      Q => sregIn(1),
      R => '0'
    );
\i_I2C/sregIn_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => sregIn(1),
      Q => sregIn(2),
      R => '0'
    );
\i_I2C/sregIn_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => sregIn(2),
      Q => sregIn(3),
      R => '0'
    );
\i_I2C/sregIn_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => sregIn(3),
      Q => sregIn(4),
      R => '0'
    );
\i_I2C/sregIn_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => sregIn(4),
      Q => sregIn(5),
      R => '0'
    );
\i_I2C/sregIn_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => sregIn(5),
      Q => sregIn(6),
      R => '0'
    );
\i_I2C/sregIn_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregIn[7]_i_1_n_0\,
      D => sregIn(6),
      Q => sregIn(7),
      R => '0'
    );
\i_I2C/sregOut[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FE0E"
    )
        port map (
      I0 => \i_I2C/sregOut[7]_i_5_n_0\,
      I1 => DO(0),
      I2 => \i_I2C/RdNotWr0\,
      I3 => Address(0),
      O => p_1_in(0)
    );
\i_I2C/sregOut[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00CA"
    )
        port map (
      I0 => DO(1),
      I1 => \i_I2C/sregOut_reg_n_0_[0]\,
      I2 => \i_I2C/sregOut[7]_i_5_n_0\,
      I3 => \i_I2C/RdNotWr0\,
      O => p_1_in(1)
    );
\i_I2C/sregOut[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[1]\,
      I2 => \i_I2C/sregOut[7]_i_5_n_0\,
      I3 => DO(2),
      O => p_1_in(2)
    );
\i_I2C/sregOut[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[2]\,
      I2 => \i_I2C/sregOut[7]_i_5_n_0\,
      I3 => DO(3),
      O => p_1_in(3)
    );
\i_I2C/sregOut[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[3]\,
      I2 => \i_I2C/sregOut[7]_i_5_n_0\,
      I3 => DO(4),
      O => p_1_in(4)
    );
\i_I2C/sregOut[5]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[4]\,
      I2 => \i_I2C/sregOut[7]_i_5_n_0\,
      I3 => DO(5),
      O => p_1_in(5)
    );
\i_I2C/sregOut[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00CA"
    )
        port map (
      I0 => DO(6),
      I1 => \i_I2C/sregOut_reg_n_0_[5]\,
      I2 => \i_I2C/sregOut[7]_i_5_n_0\,
      I3 => \i_I2C/RdNotWr0\,
      O => p_1_in(6)
    );
\i_I2C/sregOut[7]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00CA"
    )
        port map (
      I0 => DO(7),
      I1 => \i_I2C/sregOut_reg_n_0_[6]\,
      I2 => \i_I2C/sregOut[7]_i_5_n_0\,
      I3 => \i_I2C/RdNotWr0\,
      O => p_1_in(7)
    );
\i_I2C/sregOut[7]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[0]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[2]\,
      O => \i_I2C/sregOut[7]_i_5_n_0\
    );
\i_I2C/sregOut_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(0),
      Q => \i_I2C/sregOut_reg_n_0_[0]\,
      R => '0'
    );
\i_I2C/sregOut_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(1),
      Q => \i_I2C/sregOut_reg_n_0_[1]\,
      R => '0'
    );
\i_I2C/sregOut_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(2),
      Q => \i_I2C/sregOut_reg_n_0_[2]\,
      R => '0'
    );
\i_I2C/sregOut_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(3),
      Q => \i_I2C/sregOut_reg_n_0_[3]\,
      R => '0'
    );
\i_I2C/sregOut_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(4),
      Q => \i_I2C/sregOut_reg_n_0_[4]\,
      R => '0'
    );
\i_I2C/sregOut_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(5),
      Q => \i_I2C/sregOut_reg_n_0_[5]\,
      R => '0'
    );
\i_I2C/sregOut_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(6),
      Q => \i_I2C/sregOut_reg_n_0_[6]\,
      R => '0'
    );
\i_I2C/sregOut_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => p_1_in(7),
      Q => sregOut(7),
      R => '0'
    );
\sregIn[7]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => NACK_i_3_n_0,
      I1 => \i_I2C/p_1_in\,
      O => \sregIn[7]_i_1_n_0\
    );
\sregOut[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00200000"
    )
        port map (
      I0 => \i_Ctrl/state\(2),
      I1 => \i_Ctrl/state\(4),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(0),
      I4 => \i_Ctrl/state\(1),
      O => Address(0)
    );
\sregOut[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF40004F00"
    )
        port map (
      I0 => FIFO_Empty,
      I1 => \i_I2C/sclEnd\,
      I2 => \sregOut[7]_i_3_n_0\,
      I3 => \i_I2C/p_0_in\,
      I4 => \sregOut[7]_i_4_n_0\,
      I5 => \i_I2C/RdNotWr0\,
      O => \sregOut[7]_i_1_n_0\
    );
\sregOut[7]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[1]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[2]\,
      O => \sregOut[7]_i_3_n_0\
    );
\sregOut[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => \cntBits[3]_i_5_n_0\,
      I1 => \sregOut[7]_i_6_n_0\,
      I2 => \sregOut[7]_i_7_n_0\,
      I3 => L(3),
      I4 => L(7),
      I5 => L(6),
      O => \sregOut[7]_i_4_n_0\
    );
\sregOut[7]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => L(0),
      I1 => L(4),
      I2 => L(5),
      I3 => L(1),
      I4 => L(2),
      O => \sregOut[7]_i_6_n_0\
    );
\sregOut[7]_i_7\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => L(8),
      I1 => L(10),
      I2 => L(11),
      O => \sregOut[7]_i_7_n_0\
    );
end STRUCTURE;
