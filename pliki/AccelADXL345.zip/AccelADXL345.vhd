-- JS PWr Edu PL
-- --------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;

entity AccelADXL345 is
  port (
    Clk_100MHz : in STD_LOGIC;
    Reset : in STD_LOGIC;
    DataRate : in STD_LOGIC_VECTOR ( 3 downto 0 );
    I2C_NACK : out STD_LOGIC;
    X : out STD_LOGIC_VECTOR ( 15 downto 0 );
    Y : out STD_LOGIC_VECTOR ( 15 downto 0 );
    Z : out STD_LOGIC_VECTOR ( 15 downto 0 );
    NewData : out STD_LOGIC;
    Accel_SDA : inout STD_LOGIC;
    Accel_SCL : inout STD_LOGIC;
    Accel_INT1 : in STD_LOGIC
  );
  attribute INT_NUM : integer;
  attribute INT_NUM of AccelADXL345 : entity is 1;
end AccelADXL345;

architecture STRUCTURE of AccelADXL345 is
  signal DI : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal DO : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal DoPush : STD_LOGIC;
  signal FIFO_Empty : STD_LOGIC;
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[2]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_5_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[0]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[0]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_2_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_5_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_6_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_2_n_0\ : STD_LOGIC;
  signal \^i2c_nack\ : STD_LOGIC;
  signal L : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal NACK_i_1_n_0 : STD_LOGIC;
  signal NACK_i_2_n_0 : STD_LOGIC;
  signal NACK_i_3_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_10_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_11_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_12_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_13_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_14_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_15_n_0 : STD_LOGIC;
  signal RdNotWr_i_1_n_0 : STD_LOGIC;
  signal SCLout_i_1_n_0 : STD_LOGIC;
  signal SCLout_i_2_n_0 : STD_LOGIC;
  signal SCLout_i_3_n_0 : STD_LOGIC;
  signal SCLout_i_4_n_0 : STD_LOGIC;
  signal SCLout_i_5_n_0 : STD_LOGIC;
  signal SCLout_i_6_n_0 : STD_LOGIC;
  signal SCLout_i_7_n_0 : STD_LOGIC;
  signal SDAout_i_10_n_0 : STD_LOGIC;
  signal SDAout_i_1_n_0 : STD_LOGIC;
  signal SDAout_i_2_n_0 : STD_LOGIC;
  signal SDAout_i_3_n_0 : STD_LOGIC;
  signal SDAout_i_4_n_0 : STD_LOGIC;
  signal SDAout_i_5_n_0 : STD_LOGIC;
  signal SDAout_i_6_n_0 : STD_LOGIC;
  signal SDAout_i_8_n_0 : STD_LOGIC;
  signal SDAout_i_9_n_0 : STD_LOGIC;
  signal \addrRd[0]_i_3_n_0\ : STD_LOGIC;
  signal \addrRd[0]_i_4_n_0\ : STD_LOGIC;
  signal \addrWr[0]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[1]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[2]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[3]_i_1_n_0\ : STD_LOGIC;
  signal addrWr_reg : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \cntBits[0]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[1]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[2]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_2_n_0\ : STD_LOGIC;
  signal \cntBytes[0]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[0]_i_2_n_0\ : STD_LOGIC;
  signal \cntBytes[1]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[2]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[3]_i_1_n_0\ : STD_LOGIC;
  signal \cntBytes[3]_i_2_n_0\ : STD_LOGIC;
  signal \cntBytes[3]_i_3_n_0\ : STD_LOGIC;
  signal \cntSCL[0]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[0]_i_3_n_0\ : STD_LOGIC;
  signal \cntSCL[10]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[14]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[14]_i_3_n_0\ : STD_LOGIC;
  signal \cntSCL[14]_i_4_n_0\ : STD_LOGIC;
  signal \cntSCL[4]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[5]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[6]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[6]_i_3_n_0\ : STD_LOGIC;
  signal \cntSCL[6]_i_4_n_0\ : STD_LOGIC;
  signal \cntSCL[7]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[7]_i_3_n_0\ : STD_LOGIC;
  signal \cntSCL[7]_i_4_n_0\ : STD_LOGIC;
  signal \cntSCL[9]_i_2_n_0\ : STD_LOGIC;
  signal current_DataRate : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \current_DataRate[3]_i_1_n_0\ : STD_LOGIC;
  signal iEmpty_i_1_n_0 : STD_LOGIC;
  signal iEmpty_i_2_n_0 : STD_LOGIC;
  signal iEmpty_i_3_n_0 : STD_LOGIC;
  signal iEmpty_i_4_n_0 : STD_LOGIC;
  signal iEmpty_i_5_n_0 : STD_LOGIC;
  signal iEmpty_i_6_n_0 : STD_LOGIC;
  signal iFull : STD_LOGIC;
  signal iFull_i_1_n_0 : STD_LOGIC;
  signal iFull_i_2_n_0 : STD_LOGIC;
  signal iFull_i_3_n_0 : STD_LOGIC;
  signal iFull_i_4_n_0 : STD_LOGIC;
  signal iFull_i_5_n_0 : STD_LOGIC;
  signal iFull_i_6_n_0 : STD_LOGIC;
  signal iFull_i_7_n_0 : STD_LOGIC;
  signal \i_Ctrl/X_reg0\ : STD_LOGIC;
  signal \i_Ctrl/X_reg07_out\ : STD_LOGIC;
  signal \i_Ctrl/Y_reg0\ : STD_LOGIC;
  signal \i_Ctrl/Y_reg04_out\ : STD_LOGIC;
  signal \i_Ctrl/Z_reg0\ : STD_LOGIC;
  signal \i_Ctrl/Z_reg01_out\ : STD_LOGIC;
  signal \i_Ctrl/idxROM\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \i_Ctrl/next_state__0\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_Ctrl/state\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/FSM_onehot_state_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/FSM_onehot_state_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_I2C/RdNotWr\ : STD_LOGIC;
  signal \i_I2C/RdNotWr0\ : STD_LOGIC;
  signal \i_I2C/SCLin\ : STD_LOGIC;
  signal \i_I2C/SCLout_reg_n_0\ : STD_LOGIC;
  signal \i_I2C/SDAin\ : STD_LOGIC;
  signal \i_I2C/SDAout\ : STD_LOGIC;
  signal \i_I2C/T\ : STD_LOGIC;
  signal \i_I2C/cntBits\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_I2C/cntBytes\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/cntSCL\ : STD_LOGIC;
  signal \i_I2C/cntSCL__0\ : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \i_I2C/i_FIFO/addrRd_reg\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/i_FIFO/p_1_in\ : STD_LOGIC;
  signal \i_I2C/i_FIFO/plusOp0_in\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/p_0_in\ : STD_LOGIC;
  signal \i_I2C/p_1_in\ : STD_LOGIC;
  signal \i_I2C/rSDAin\ : STD_LOGIC;
  signal \i_I2C/sclEnd\ : STD_LOGIC;
  signal \i_I2C/sregIn0\ : STD_LOGIC;
  signal \i_I2C/sregOut[7]_i_4_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[6]\ : STD_LOGIC;
  signal \idxROM[2]_i_1_n_0\ : STD_LOGIC;
  signal p_1_in : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \p_1_in__0\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal rSCLin : STD_LOGIC;
  signal sregIn : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal sregOut : STD_LOGIC_VECTOR ( 7 to 7 );
  signal \sregOut[0]_i_2_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_1_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_3_n_0\ : STD_LOGIC;
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOE_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOF_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOG_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOH_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_state[0]_i_2\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \FSM_onehot_state[3]_i_1\ : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of \FSM_onehot_state[5]_i_5\ : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of \FSM_sequential_state[1]_i_5\ : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of NACK_i_3 : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_11 : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_13 : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_9 : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of SCLout_i_3 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of SCLout_i_6 : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of SCLout_i_7 : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of SDAout_i_10 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of SDAout_i_5 : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \addrRd[0]_i_2\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \addrRd[0]_i_4\ : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of \addrRd[1]_i_1\ : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of \addrRd[2]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \addrRd[3]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \addrWr[0]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \addrWr[1]_i_1\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \addrWr[2]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \addrWr[3]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \cntBits[0]_i_1\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \cntBits[2]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cntBits[3]_i_2\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cntBytes[0]_i_2\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \cntBytes[1]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \cntBytes[2]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \cntSCL[0]_i_3\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \cntSCL[12]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \cntSCL[13]_i_1\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \cntSCL[14]_i_4\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \cntSCL[1]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \cntSCL[2]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \cntSCL[4]_i_2\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \cntSCL[5]_i_2\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \cntSCL[6]_i_2\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \cntSCL[6]_i_3\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \cntSCL[7]_i_3\ : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of iEmpty_i_5 : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of iEmpty_i_6 : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of iFull_i_2 : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of iFull_i_4 : label is "soft_lutpair18";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[0]\ : label is "swaitint:0000,swraddress:0001,swaitbusy3:0100,swaitbusy1:0101,srdz0:0111,srdz1:0110,srdy1:1000,swrinit:0010,sreset:1001,srdx0:1010,srdy0:1100,sgorddata:1101,srdx1:1011,swaitbusy2:0011";
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[1]\ : label is "swaitint:0000,swraddress:0001,swaitbusy3:0100,swaitbusy1:0101,srdz0:0111,srdz1:0110,srdy1:1000,swrinit:0010,sreset:1001,srdx0:1010,srdy0:1100,sgorddata:1101,srdx1:1011,swaitbusy2:0011";
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[2]\ : label is "swaitint:0000,swraddress:0001,swaitbusy3:0100,swaitbusy1:0101,srdz0:0111,srdz1:0110,srdy1:1000,swrinit:0010,sreset:1001,srdx0:1010,srdy0:1100,sgorddata:1101,srdx1:1011,swaitbusy2:0011";
  attribute FSM_ENCODED_STATES of \i_Ctrl/FSM_sequential_state_reg[3]\ : label is "swaitint:0000,swraddress:0001,swaitbusy3:0100,swaitbusy1:0101,srdz0:0111,srdz1:0110,srdy1:1000,swrinit:0010,sreset:1001,srdx0:1010,srdy0:1100,sgorddata:1101,srdx1:1011,swaitbusy2:0011";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[0]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[1]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[2]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[3]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[4]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[5]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute box_type : string;
  attribute box_type of \i_I2C/IOBUF_SCL\ : label is "PRIMITIVE";
  attribute box_type of \i_I2C/IOBUF_SDA\ : label is "PRIMITIVE";
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 128;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "AccelADXL345/i_I2C/i_FIFO/RAM_reg";
  attribute RTL_RAM_STYLE : string;
  attribute RTL_RAM_STYLE of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "auto";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 15;
  attribute ram_offset : integer;
  attribute ram_offset of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 7;
  attribute IOB : string;
  attribute IOB of \i_I2C/rSCLin_reg\ : label is "TRUE";
  attribute IOB of \i_I2C/rSDAin_reg\ : label is "TRUE";
  attribute SOFT_HLUTNM of \i_I2C/sregOut[7]_i_4\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \idxROM[1]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \idxROM[2]_i_2\ : label is "soft_lutpair20";
begin
  I2C_NACK <= \^i2c_nack\;
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AFEEAAAA"
    )
        port map (
      I0 => \i_I2C/p_1_in\,
      I1 => FIFO_Empty,
      I2 => \FSM_onehot_state[0]_i_2_n_0\,
      I3 => \i_I2C/RdNotWr\,
      I4 => \i_I2C/p_0_in\,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state[0]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => \i_I2C/cntBytes\(2),
      I1 => \i_I2C/cntBytes\(0),
      I2 => \i_I2C/cntBytes\(1),
      I3 => \i_I2C/cntBytes\(3),
      O => \FSM_onehot_state[0]_i_2_n_0\
    );
\FSM_onehot_state[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      O => \FSM_onehot_state[1]_i_1_n_0\
    );
\FSM_onehot_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8888888888888880"
    )
        port map (
      I0 => \i_I2C/p_0_in\,
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntBytes\(3),
      I3 => \i_I2C/cntBytes\(1),
      I4 => \i_I2C/cntBytes\(0),
      I5 => \i_I2C/cntBytes\(2),
      O => \FSM_onehot_state[2]_i_1_n_0\
    );
\FSM_onehot_state[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF04"
    )
        port map (
      I0 => \i_I2C/RdNotWr\,
      I1 => \i_I2C/p_0_in\,
      I2 => FIFO_Empty,
      I3 => \i_I2C/cntBits\,
      O => \FSM_onehot_state[3]_i_1_n_0\
    );
\FSM_onehot_state[5]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FD"
    )
        port map (
      I0 => \FSM_onehot_state[5]_i_2_n_0\,
      I1 => \i_I2C/RdNotWr0\,
      I2 => \FSM_onehot_state[5]_i_4_n_0\,
      O => \FSM_onehot_state[5]_i_1_n_0\
    );
\FSM_onehot_state[5]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFDFF"
    )
        port map (
      I0 => \i_I2C/p_0_in\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[3]\,
      I4 => \i_I2C/cntBits_reg_n_0_[0]\,
      I5 => \cntSCL[4]_i_2_n_0\,
      O => \FSM_onehot_state[5]_i_2_n_0\
    );
\FSM_onehot_state[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5D55555D00000000"
    )
        port map (
      I0 => \cntBytes[0]_i_2_n_0\,
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(2),
      I5 => \i_I2C/cntSCL\,
      O => \i_I2C/RdNotWr0\
    );
\FSM_onehot_state[5]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAFFAAFEAAFEAAFE"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      I1 => \i_I2C/cntBits\,
      I2 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I3 => \cntSCL[4]_i_2_n_0\,
      I4 => \i_I2C/p_1_in\,
      I5 => \FSM_onehot_state[5]_i_5_n_0\,
      O => \FSM_onehot_state[5]_i_4_n_0\
    );
\FSM_onehot_state[5]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => \i_I2C/cntBytes\(3),
      I1 => \i_I2C/cntBytes\(1),
      I2 => \i_I2C/cntBytes\(0),
      I3 => \i_I2C/cntBytes\(2),
      I4 => NACK_i_3_n_0,
      O => \FSM_onehot_state[5]_i_5_n_0\
    );
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFAAABAAAA"
    )
        port map (
      I0 => \FSM_sequential_state[0]_i_2_n_0\,
      I1 => \i_Ctrl/state\(1),
      I2 => \i_Ctrl/state\(2),
      I3 => \i_Ctrl/state\(3),
      I4 => Accel_INT1,
      I5 => \FSM_sequential_state[0]_i_3_n_0\,
      O => \i_Ctrl/next_state__0\(0)
    );
\FSM_sequential_state[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"3F05000000050000"
    )
        port map (
      I0 => \i_I2C/cntSCL\,
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(1),
      I4 => \i_Ctrl/state\(0),
      I5 => FIFO_Empty,
      O => \FSM_sequential_state[0]_i_2_n_0\
    );
\FSM_sequential_state[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000FF000F0022"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \cntBytes[0]_i_2_n_0\,
      I2 => FIFO_Empty,
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(3),
      I5 => \i_Ctrl/state\(0),
      O => \FSM_sequential_state[0]_i_3_n_0\
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => \FSM_sequential_state[1]_i_2_n_0\,
      I1 => \FSM_sequential_state[1]_i_3_n_0\,
      I2 => \FSM_sequential_state[1]_i_4_n_0\,
      O => \i_Ctrl/next_state__0\(1)
    );
\FSM_sequential_state[1]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"C686C786C484C784"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(2),
      I3 => \i_Ctrl/state\(3),
      I4 => FIFO_Empty,
      I5 => \cntBytes[0]_i_2_n_0\,
      O => \FSM_sequential_state[1]_i_2_n_0\
    );
\FSM_sequential_state[1]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"60F0F060"
    )
        port map (
      I0 => DataRate(0),
      I1 => current_DataRate(0),
      I2 => \FSM_sequential_state[1]_i_5_n_0\,
      I3 => DataRate(1),
      I4 => current_DataRate(1),
      O => \FSM_sequential_state[1]_i_3_n_0\
    );
\FSM_sequential_state[1]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"BEAAFFAAFFAABEAA"
    )
        port map (
      I0 => \FSM_sequential_state[1]_i_6_n_0\,
      I1 => current_DataRate(2),
      I2 => DataRate(2),
      I3 => \FSM_sequential_state[1]_i_5_n_0\,
      I4 => DataRate(3),
      I5 => current_DataRate(3),
      O => \FSM_sequential_state[1]_i_4_n_0\
    );
\FSM_sequential_state[1]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0001"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(3),
      I3 => Accel_INT1,
      O => \FSM_sequential_state[1]_i_5_n_0\
    );
\FSM_sequential_state[1]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFF2000000220000"
    )
        port map (
      I0 => \i_Ctrl/state\(0),
      I1 => \i_I2C/cntSCL\,
      I2 => \i_Ctrl/state\(2),
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(1),
      I5 => FIFO_Empty,
      O => \FSM_sequential_state[1]_i_6_n_0\
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F4FFF2F0F4F0F1F0"
    )
        port map (
      I0 => \i_Ctrl/state\(0),
      I1 => FIFO_Empty,
      I2 => \FSM_sequential_state[2]_i_2_n_0\,
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(2),
      I5 => \i_Ctrl/state\(1),
      O => \i_Ctrl/next_state__0\(2)
    );
\FSM_sequential_state[2]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000EE444F44"
    )
        port map (
      I0 => \i_I2C/cntSCL\,
      I1 => \i_Ctrl/state\(2),
      I2 => \cntBytes[0]_i_2_n_0\,
      I3 => \i_Ctrl/state\(1),
      I4 => \i_Ctrl/state\(0),
      I5 => \i_Ctrl/state\(3),
      O => \FSM_sequential_state[2]_i_2_n_0\
    );
\FSM_sequential_state[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCCCCCFC08CC08"
    )
        port map (
      I0 => FIFO_Empty,
      I1 => \i_Ctrl/state\(3),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(1),
      I4 => \i_I2C/cntSCL\,
      I5 => \i_Ctrl/state\(2),
      O => \i_Ctrl/next_state__0\(3)
    );
NACK_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1010101011101010"
    )
        port map (
      I0 => Reset,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      I2 => \^i2c_nack\,
      I3 => NACK_i_2_n_0,
      I4 => \i_I2C/p_0_in\,
      I5 => NACK_i_3_n_0,
      O => NACK_i_1_n_0
    );
NACK_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000040"
    )
        port map (
      I0 => \cntSCL[6]_i_2_n_0\,
      I1 => L(1),
      I2 => \i_I2C/rSDAin\,
      I3 => L(6),
      I4 => L(2),
      I5 => \cntSCL[0]_i_2_n_0\,
      O => NACK_i_2_n_0
    );
NACK_i_3: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[1]\,
      I1 => \i_I2C/cntBits_reg_n_0_[2]\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      O => NACK_i_3_n_0
    );
NewData_INST_0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000400"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_I2C/cntSCL\,
      I4 => \i_Ctrl/state\(1),
      O => NewData
    );
RAM_reg_0_15_0_7_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0110000001105555"
    )
        port map (
      I0 => iFull,
      I1 => RAM_reg_0_15_0_7_i_10_n_0,
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(0),
      I4 => RAM_reg_0_15_0_7_i_11_n_0,
      I5 => RAM_reg_0_15_0_7_i_12_n_0,
      O => DoPush
    );
RAM_reg_0_15_0_7_i_10: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i_Ctrl/state\(2),
      I1 => \i_Ctrl/state\(3),
      O => RAM_reg_0_15_0_7_i_10_n_0
    );
RAM_reg_0_15_0_7_i_11: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \i_I2C/cntSCL\,
      I1 => \i_I2C/RdNotWr\,
      O => RAM_reg_0_15_0_7_i_11_n_0
    );
RAM_reg_0_15_0_7_i_12: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBFFFFFFF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[3]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[0]\,
      I3 => \i_I2C/cntBits_reg_n_0_[2]\,
      I4 => \i_I2C/p_1_in\,
      I5 => \cntSCL[4]_i_2_n_0\,
      O => RAM_reg_0_15_0_7_i_12_n_0
    );
RAM_reg_0_15_0_7_i_13: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(2),
      I1 => \i_Ctrl/idxROM\(1),
      I2 => \i_Ctrl/idxROM\(0),
      O => RAM_reg_0_15_0_7_i_13_n_0
    );
RAM_reg_0_15_0_7_i_14: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1000101000000000"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(2),
      I1 => \i_Ctrl/idxROM\(1),
      I2 => \i_Ctrl/idxROM\(0),
      I3 => \i_I2C/cntSCL\,
      I4 => \i_I2C/RdNotWr\,
      I5 => DataRate(3),
      O => RAM_reg_0_15_0_7_i_14_n_0
    );
RAM_reg_0_15_0_7_i_15: unisim.vcomponents.LUT6
    generic map(
      INIT => X"222222222222222E"
    )
        port map (
      I0 => sregIn(2),
      I1 => RAM_reg_0_15_0_7_i_11_n_0,
      I2 => \i_Ctrl/idxROM\(2),
      I3 => \idxROM[2]_i_1_n_0\,
      I4 => \i_Ctrl/idxROM\(1),
      I5 => \i_Ctrl/idxROM\(0),
      O => RAM_reg_0_15_0_7_i_15_n_0
    );
RAM_reg_0_15_0_7_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCAACCF0F0AAF0"
    )
        port map (
      I0 => sregIn(1),
      I1 => \idxROM[2]_i_1_n_0\,
      I2 => DataRate(1),
      I3 => \i_I2C/RdNotWr\,
      I4 => \i_I2C/cntSCL\,
      I5 => RAM_reg_0_15_0_7_i_13_n_0,
      O => DI(1)
    );
RAM_reg_0_15_0_7_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0008FFFF00080000"
    )
        port map (
      I0 => DataRate(0),
      I1 => \i_Ctrl/idxROM\(0),
      I2 => \i_Ctrl/idxROM\(1),
      I3 => \i_Ctrl/idxROM\(2),
      I4 => RAM_reg_0_15_0_7_i_11_n_0,
      I5 => sregIn(0),
      O => DI(0)
    );
RAM_reg_0_15_0_7_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAABFFFFAAABAAAA"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_14_n_0,
      I1 => \i_Ctrl/idxROM\(0),
      I2 => \idxROM[2]_i_1_n_0\,
      I3 => \i_Ctrl/idxROM\(2),
      I4 => RAM_reg_0_15_0_7_i_11_n_0,
      I5 => sregIn(3),
      O => DI(3)
    );
RAM_reg_0_15_0_7_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00000080"
    )
        port map (
      I0 => DataRate(2),
      I1 => RAM_reg_0_15_0_7_i_11_n_0,
      I2 => \i_Ctrl/idxROM\(0),
      I3 => \i_Ctrl/idxROM\(1),
      I4 => \i_Ctrl/idxROM\(2),
      I5 => RAM_reg_0_15_0_7_i_15_n_0,
      O => DI(2)
    );
RAM_reg_0_15_0_7_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CCCCAAAACC0FAAAA"
    )
        port map (
      I0 => sregIn(5),
      I1 => \idxROM[2]_i_1_n_0\,
      I2 => \i_Ctrl/idxROM\(0),
      I3 => \i_Ctrl/idxROM\(1),
      I4 => RAM_reg_0_15_0_7_i_11_n_0,
      I5 => \i_Ctrl/idxROM\(2),
      O => DI(5)
    );
RAM_reg_0_15_0_7_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAA2FFFFAAA20000"
    )
        port map (
      I0 => \idxROM[2]_i_1_n_0\,
      I1 => \i_Ctrl/idxROM\(0),
      I2 => \i_Ctrl/idxROM\(1),
      I3 => \i_Ctrl/idxROM\(2),
      I4 => RAM_reg_0_15_0_7_i_11_n_0,
      I5 => sregIn(4),
      O => DI(4)
    );
RAM_reg_0_15_0_7_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0040FFFF00400000"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(2),
      I1 => \i_Ctrl/idxROM\(1),
      I2 => \i_Ctrl/idxROM\(0),
      I3 => \idxROM[2]_i_1_n_0\,
      I4 => RAM_reg_0_15_0_7_i_11_n_0,
      I5 => sregIn(7),
      O => DI(7)
    );
RAM_reg_0_15_0_7_i_9: unisim.vcomponents.LUT3
    generic map(
      INIT => X"08"
    )
        port map (
      I0 => sregIn(6),
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      O => DI(6)
    );
RdNotWr_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0080FFFF00800000"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(0),
      I3 => \i_Ctrl/state\(1),
      I4 => \i_I2C/RdNotWr0\,
      I5 => \i_I2C/RdNotWr\,
      O => RdNotWr_i_1_n_0
    );
SCLout_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"CECEFEFFCECE0E00"
    )
        port map (
      I0 => SCLout_i_2_n_0,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I2 => SCLout_i_3_n_0,
      I3 => SCLout_i_4_n_0,
      I4 => SCLout_i_5_n_0,
      I5 => \i_I2C/SCLout_reg_n_0\,
      O => SCLout_i_1_n_0
    );
SCLout_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000800000000"
    )
        port map (
      I0 => L(3),
      I1 => L(5),
      I2 => \i_I2C/cntBits\,
      I3 => L(6),
      I4 => L(0),
      I5 => \cntSCL[5]_i_2_n_0\,
      O => SCLout_i_2_n_0
    );
SCLout_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => L(14),
      I1 => L(13),
      I2 => L(8),
      I3 => \cntSCL[7]_i_4_n_0\,
      I4 => L(7),
      O => SCLout_i_3_n_0
    );
SCLout_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000B00000000"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I1 => \i_I2C/cntBits\,
      I2 => L(6),
      I3 => L(0),
      I4 => SCLout_i_6_n_0,
      I5 => \cntSCL[5]_i_2_n_0\,
      O => SCLout_i_4_n_0
    );
SCLout_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000040400040"
    )
        port map (
      I0 => \cntSCL[6]_i_2_n_0\,
      I1 => L(1),
      I2 => SCLout_i_7_n_0,
      I3 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits\,
      I5 => \cntSCL[0]_i_2_n_0\,
      O => SCLout_i_5_n_0
    );
SCLout_i_6: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => L(3),
      I1 => L(5),
      O => SCLout_i_6_n_0
    );
SCLout_i_7: unisim.vcomponents.LUT2
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => L(2),
      I1 => L(6),
      O => SCLout_i_7_n_0
    );
SDAout_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF00FE00EF00EE00"
    )
        port map (
      I0 => SDAout_i_2_n_0,
      I1 => SDAout_i_3_n_0,
      I2 => L(2),
      I3 => SDAout_i_4_n_0,
      I4 => SDAout_i_5_n_0,
      I5 => SDAout_i_6_n_0,
      O => SDAout_i_1_n_0
    );
SDAout_i_10: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => L(5),
      I1 => L(6),
      I2 => L(0),
      I3 => L(3),
      I4 => L(2),
      O => SDAout_i_10_n_0
    );
SDAout_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFE"
    )
        port map (
      I0 => L(4),
      I1 => L(1),
      I2 => L(7),
      I3 => \cntSCL[7]_i_4_n_0\,
      I4 => \cntSCL[7]_i_3_n_0\,
      O => SDAout_i_2_n_0
    );
SDAout_i_3: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => L(0),
      I1 => L(3),
      O => SDAout_i_3_n_0
    );
SDAout_i_4: unisim.vcomponents.LUT3
    generic map(
      INIT => X"B8"
    )
        port map (
      I0 => \i_I2C/SDAout\,
      I1 => SDAout_i_8_n_0,
      I2 => \i_I2C/T\,
      O => SDAout_i_4_n_0
    );
SDAout_i_5: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => L(6),
      I1 => L(5),
      I2 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      O => SDAout_i_5_n_0
    );
SDAout_i_6: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => \i_I2C/cntBits\,
      I1 => L(6),
      I2 => L(5),
      O => SDAout_i_6_n_0
    );
SDAout_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBA9AFFDF"
    )
        port map (
      I0 => NACK_i_3_n_0,
      I1 => SDAout_i_9_n_0,
      I2 => \i_I2C/p_0_in\,
      I3 => sregOut(7),
      I4 => \FSM_onehot_state[0]_i_2_n_0\,
      I5 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      O => \i_I2C/SDAout\
    );
SDAout_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAA00003330"
    )
        port map (
      I0 => \cntSCL[7]_i_2_n_0\,
      I1 => SDAout_i_9_n_0,
      I2 => \i_I2C/p_0_in\,
      I3 => \i_I2C/p_1_in\,
      I4 => \i_I2C/cntBits\,
      I5 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      O => SDAout_i_8_n_0
    );
SDAout_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFE"
    )
        port map (
      I0 => SDAout_i_10_n_0,
      I1 => \cntSCL[7]_i_3_n_0\,
      I2 => \cntSCL[7]_i_4_n_0\,
      I3 => L(7),
      I4 => L(1),
      I5 => L(4),
      O => SDAout_i_9_n_0
    );
\X[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"02000000"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(2),
      I2 => FIFO_Empty,
      I3 => \i_Ctrl/state\(1),
      I4 => \i_Ctrl/state\(0),
      O => \i_Ctrl/X_reg07_out\
    );
\X[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000040"
    )
        port map (
      I0 => \i_Ctrl/state\(0),
      I1 => \i_Ctrl/state\(1),
      I2 => \i_Ctrl/state\(3),
      I3 => FIFO_Empty,
      I4 => \i_Ctrl/state\(2),
      O => \i_Ctrl/X_reg0\
    );
\Y[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000100"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(2),
      I2 => FIFO_Empty,
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(0),
      O => \i_Ctrl/Y_reg04_out\
    );
\Y[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000400"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(2),
      I2 => FIFO_Empty,
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(0),
      O => \i_Ctrl/Y_reg0\
    );
\Z[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00001000"
    )
        port map (
      I0 => FIFO_Empty,
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(3),
      O => \i_Ctrl/Z_reg01_out\
    );
\Z[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00004000"
    )
        port map (
      I0 => FIFO_Empty,
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(2),
      I4 => \i_Ctrl/state\(3),
      O => \i_Ctrl/Z_reg0\
    );
\addrRd[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \addrRd[0]_i_3_n_0\,
      I1 => FIFO_Empty,
      O => \i_I2C/i_FIFO/p_1_in\
    );
\addrRd[0]_i_2\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => \i_I2C/i_FIFO/plusOp0_in\(0)
    );
\addrRd[0]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A8A8A8ABA8A8A8A8"
    )
        port map (
      I0 => \addrRd[0]_i_4_n_0\,
      I1 => \i_I2C/RdNotWr\,
      I2 => \i_I2C/cntSCL\,
      I3 => \cntSCL[4]_i_2_n_0\,
      I4 => NACK_i_3_n_0,
      I5 => \i_I2C/p_0_in\,
      O => \addrRd[0]_i_3_n_0\
    );
\addrRd[0]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4878"
    )
        port map (
      I0 => \i_Ctrl/state\(2),
      I1 => \i_Ctrl/state\(1),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(0),
      O => \addrRd[0]_i_4_n_0\
    );
\addrRd[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      O => \i_I2C/i_FIFO/plusOp0_in\(1)
    );
\addrRd[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(2),
      O => \i_I2C/i_FIFO/plusOp0_in\(2)
    );
\addrRd[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(3),
      O => \i_I2C/i_FIFO/plusOp0_in\(3)
    );
\addrWr[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => addrWr_reg(0),
      O => \addrWr[0]_i_1_n_0\
    );
\addrWr[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => addrWr_reg(0),
      I1 => addrWr_reg(1),
      O => \addrWr[1]_i_1_n_0\
    );
\addrWr[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => addrWr_reg(0),
      I1 => addrWr_reg(1),
      I2 => addrWr_reg(2),
      O => \addrWr[2]_i_1_n_0\
    );
\addrWr[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => addrWr_reg(0),
      I1 => addrWr_reg(1),
      I2 => addrWr_reg(2),
      I3 => addrWr_reg(3),
      O => \addrWr[3]_i_1_n_0\
    );
\cntBits[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00EF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[1]\,
      I1 => \i_I2C/cntBits_reg_n_0_[2]\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      O => \cntBits[0]_i_1_n_0\
    );
\cntBits[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[1]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      O => \cntBits[1]_i_1_n_0\
    );
\cntBits[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      I2 => \i_I2C/cntBits_reg_n_0_[1]\,
      O => \cntBits[2]_i_1_n_0\
    );
\cntBits[3]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \cntSCL[4]_i_2_n_0\,
      O => \i_I2C/sclEnd\
    );
\cntBits[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AA8"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[3]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[0]\,
      I3 => \i_I2C/cntBits_reg_n_0_[2]\,
      O => \cntBits[3]_i_2_n_0\
    );
\cntBytes[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000DFFD5555"
    )
        port map (
      I0 => \i_I2C/cntSCL\,
      I1 => \sregOut[0]_i_2_n_0\,
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(2),
      I4 => \cntBytes[0]_i_2_n_0\,
      I5 => \i_I2C/cntBytes\(0),
      O => \cntBytes[0]_i_1_n_0\
    );
\cntBytes[0]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EF"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(1),
      I1 => \i_Ctrl/idxROM\(0),
      I2 => \i_Ctrl/idxROM\(2),
      O => \cntBytes[0]_i_2_n_0\
    );
\cntBytes[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"EB"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/cntBytes\(1),
      I2 => \i_I2C/cntBytes\(0),
      O => \cntBytes[1]_i_1_n_0\
    );
\cntBytes[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EEEB"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/cntBytes\(2),
      I2 => \i_I2C/cntBytes\(0),
      I3 => \i_I2C/cntBytes\(1),
      O => \cntBytes[2]_i_1_n_0\
    );
\cntBytes[3]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => RAM_reg_0_15_0_7_i_12_n_0,
      O => \cntBytes[3]_i_1_n_0\
    );
\cntBytes[3]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"88888882"
    )
        port map (
      I0 => \cntBytes[3]_i_3_n_0\,
      I1 => \i_I2C/cntBytes\(3),
      I2 => \i_I2C/cntBytes\(1),
      I3 => \i_I2C/cntBytes\(0),
      I4 => \i_I2C/cntBytes\(2),
      O => \cntBytes[3]_i_2_n_0\
    );
\cntBytes[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA28AAAAFFFFFFFF"
    )
        port map (
      I0 => \cntBytes[0]_i_2_n_0\,
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(1),
      I4 => \i_Ctrl/state\(0),
      I5 => \i_I2C/cntSCL\,
      O => \cntBytes[3]_i_3_n_0\
    );
\cntSCL[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000FFFF0000FFFE"
    )
        port map (
      I0 => \cntSCL[0]_i_2_n_0\,
      I1 => \cntSCL[6]_i_3_n_0\,
      I2 => \cntSCL[0]_i_3_n_0\,
      I3 => rSCLin,
      I4 => L(0),
      I5 => L(3),
      O => \i_I2C/cntSCL__0\(0)
    );
\cntSCL[0]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFF7"
    )
        port map (
      I0 => L(7),
      I1 => L(4),
      I2 => L(14),
      I3 => L(13),
      I4 => L(8),
      I5 => \cntSCL[7]_i_4_n_0\,
      O => \cntSCL[0]_i_2_n_0\
    );
\cntSCL[0]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => L(5),
      I1 => L(6),
      O => \cntSCL[0]_i_3_n_0\
    );
\cntSCL[10]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"28888888"
    )
        port map (
      I0 => \cntSCL[14]_i_2_n_0\,
      I1 => L(10),
      I2 => L(8),
      I3 => \cntSCL[10]_i_2_n_0\,
      I4 => L(9),
      O => \i_I2C/cntSCL__0\(10)
    );
\cntSCL[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4000000000000000"
    )
        port map (
      I0 => \cntSCL[6]_i_2_n_0\,
      I1 => L(6),
      I2 => L(1),
      I3 => L(2),
      I4 => L(7),
      I5 => L(4),
      O => \cntSCL[10]_i_2_n_0\
    );
\cntSCL[11]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"28"
    )
        port map (
      I0 => \cntSCL[14]_i_2_n_0\,
      I1 => L(11),
      I2 => \cntSCL[14]_i_3_n_0\,
      O => \i_I2C/cntSCL__0\(11)
    );
\cntSCL[12]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"2888"
    )
        port map (
      I0 => \cntSCL[14]_i_2_n_0\,
      I1 => L(12),
      I2 => \cntSCL[14]_i_3_n_0\,
      I3 => L(11),
      O => \i_I2C/cntSCL__0\(12)
    );
\cntSCL[13]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"28888888"
    )
        port map (
      I0 => \cntSCL[14]_i_2_n_0\,
      I1 => L(13),
      I2 => L(12),
      I3 => L(11),
      I4 => \cntSCL[14]_i_3_n_0\,
      O => \i_I2C/cntSCL__0\(13)
    );
\cntSCL[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2888888888888888"
    )
        port map (
      I0 => \cntSCL[14]_i_2_n_0\,
      I1 => L(14),
      I2 => L(11),
      I3 => L(12),
      I4 => L(13),
      I5 => \cntSCL[14]_i_3_n_0\,
      O => \i_I2C/cntSCL__0\(14)
    );
\cntSCL[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFEFEFEFFFFAFFFF"
    )
        port map (
      I0 => \cntSCL[0]_i_2_n_0\,
      I1 => \cntSCL[14]_i_4_n_0\,
      I2 => L(2),
      I3 => \cntSCL[6]_i_2_n_0\,
      I4 => L(6),
      I5 => L(1),
      O => \cntSCL[14]_i_2_n_0\
    );
\cntSCL[14]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => L(9),
      I1 => L(4),
      I2 => L(7),
      I3 => \cntSCL[9]_i_2_n_0\,
      I4 => L(8),
      I5 => L(10),
      O => \cntSCL[14]_i_3_n_0\
    );
\cntSCL[14]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => L(3),
      I1 => L(0),
      I2 => L(6),
      I3 => L(5),
      O => \cntSCL[14]_i_4_n_0\
    );
\cntSCL[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF60"
    )
        port map (
      I0 => L(0),
      I1 => L(1),
      I2 => \cntSCL[4]_i_2_n_0\,
      I3 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(1)
    );
\cntSCL[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF7800"
    )
        port map (
      I0 => L(0),
      I1 => L(1),
      I2 => L(2),
      I3 => \cntSCL[4]_i_2_n_0\,
      I4 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(2)
    );
\cntSCL[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF7F800000"
    )
        port map (
      I0 => L(1),
      I1 => L(2),
      I2 => L(0),
      I3 => L(3),
      I4 => \cntSCL[14]_i_2_n_0\,
      I5 => \cntSCL[6]_i_4_n_0\,
      O => \i_I2C/cntSCL__0\(3)
    );
\cntSCL[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFBF400000"
    )
        port map (
      I0 => \cntSCL[6]_i_3_n_0\,
      I1 => L(0),
      I2 => L(3),
      I3 => L(4),
      I4 => \cntSCL[4]_i_2_n_0\,
      I5 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(4)
    );
\cntSCL[4]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFEFFFF"
    )
        port map (
      I0 => L(1),
      I1 => \cntSCL[0]_i_2_n_0\,
      I2 => L(2),
      I3 => \cntSCL[6]_i_2_n_0\,
      I4 => L(6),
      O => \cntSCL[4]_i_2_n_0\
    );
\cntSCL[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF7F800000"
    )
        port map (
      I0 => \cntSCL[5]_i_2_n_0\,
      I1 => L(0),
      I2 => L(3),
      I3 => L(5),
      I4 => \cntSCL[14]_i_2_n_0\,
      I5 => \cntSCL[6]_i_4_n_0\,
      O => \i_I2C/cntSCL__0\(5)
    );
\cntSCL[5]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"80"
    )
        port map (
      I0 => L(4),
      I1 => L(2),
      I2 => L(1),
      O => \cntSCL[5]_i_2_n_0\
    );
\cntSCL[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFB040000"
    )
        port map (
      I0 => \cntSCL[6]_i_2_n_0\,
      I1 => L(4),
      I2 => \cntSCL[6]_i_3_n_0\,
      I3 => L(6),
      I4 => \cntSCL[14]_i_2_n_0\,
      I5 => \cntSCL[6]_i_4_n_0\,
      O => \i_I2C/cntSCL__0\(6)
    );
\cntSCL[6]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => L(5),
      I1 => L(3),
      I2 => L(0),
      O => \cntSCL[6]_i_2_n_0\
    );
\cntSCL[6]_i_3\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"7"
    )
        port map (
      I0 => L(1),
      I1 => L(2),
      O => \cntSCL[6]_i_3_n_0\
    );
\cntSCL[6]_i_4\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \cntSCL[7]_i_2_n_0\,
      I1 => rSCLin,
      O => \cntSCL[6]_i_4_n_0\
    );
\cntSCL[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFF780078007800"
    )
        port map (
      I0 => L(4),
      I1 => \cntSCL[9]_i_2_n_0\,
      I2 => L(7),
      I3 => \cntSCL[14]_i_2_n_0\,
      I4 => rSCLin,
      I5 => \cntSCL[7]_i_2_n_0\,
      O => \i_I2C/cntSCL__0\(7)
    );
\cntSCL[7]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000008"
    )
        port map (
      I0 => L(7),
      I1 => L(4),
      I2 => \cntSCL[7]_i_3_n_0\,
      I3 => \cntSCL[7]_i_4_n_0\,
      I4 => \cntSCL[6]_i_3_n_0\,
      I5 => \cntSCL[14]_i_4_n_0\,
      O => \cntSCL[7]_i_2_n_0\
    );
\cntSCL[7]_i_3\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => L(14),
      I1 => L(13),
      I2 => L(8),
      O => \cntSCL[7]_i_3_n_0\
    );
\cntSCL[7]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => L(10),
      I1 => L(9),
      I2 => L(12),
      I3 => L(11),
      O => \cntSCL[7]_i_4_n_0\
    );
\cntSCL[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"28888888"
    )
        port map (
      I0 => \cntSCL[14]_i_2_n_0\,
      I1 => L(8),
      I2 => \cntSCL[9]_i_2_n_0\,
      I3 => L(7),
      I4 => L(4),
      O => \i_I2C/cntSCL__0\(8)
    );
\cntSCL[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2888888888888888"
    )
        port map (
      I0 => \cntSCL[14]_i_2_n_0\,
      I1 => L(9),
      I2 => L(4),
      I3 => L(7),
      I4 => \cntSCL[9]_i_2_n_0\,
      I5 => L(8),
      O => \i_I2C/cntSCL__0\(9)
    );
\cntSCL[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8000000000000000"
    )
        port map (
      I0 => L(2),
      I1 => L(1),
      I2 => L(6),
      I3 => L(5),
      I4 => L(3),
      I5 => L(0),
      O => \cntSCL[9]_i_2_n_0\
    );
\current_DataRate[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"02"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(0),
      I1 => \i_Ctrl/idxROM\(1),
      I2 => \i_Ctrl/idxROM\(2),
      O => \current_DataRate[3]_i_1_n_0\
    );
iEmpty_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"55400000"
    )
        port map (
      I0 => Reset,
      I1 => \addrRd[0]_i_3_n_0\,
      I2 => iEmpty_i_2_n_0,
      I3 => FIFO_Empty,
      I4 => iEmpty_i_3_n_0,
      O => iEmpty_i_1_n_0
    );
iEmpty_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000006000900000"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I1 => addrWr_reg(1),
      I2 => iEmpty_i_4_n_0,
      I3 => FIFO_Empty,
      I4 => addrWr_reg(0),
      I5 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => iEmpty_i_2_n_0
    );
iEmpty_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFB00FB"
    )
        port map (
      I0 => \cntSCL[4]_i_2_n_0\,
      I1 => \i_I2C/p_1_in\,
      I2 => iEmpty_i_5_n_0,
      I3 => RAM_reg_0_15_0_7_i_11_n_0,
      I4 => iEmpty_i_6_n_0,
      I5 => iFull,
      O => iEmpty_i_3_n_0
    );
iEmpty_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1888844442222111"
    )
        port map (
      I0 => addrWr_reg(2),
      I1 => addrWr_reg(3),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I4 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I5 => \i_I2C/i_FIFO/addrRd_reg\(3),
      O => iEmpty_i_4_n_0
    );
iEmpty_i_5: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      I2 => \i_I2C/cntBits_reg_n_0_[1]\,
      I3 => \i_I2C/cntBits_reg_n_0_[3]\,
      O => iEmpty_i_5_n_0
    );
iEmpty_i_6: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEEF"
    )
        port map (
      I0 => \i_Ctrl/state\(3),
      I1 => \i_Ctrl/state\(2),
      I2 => \i_Ctrl/state\(1),
      I3 => \i_Ctrl/state\(0),
      O => iEmpty_i_6_n_0
    );
iFull_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00EE000000FA0000"
    )
        port map (
      I0 => FIFO_Empty,
      I1 => iFull_i_2_n_0,
      I2 => \FSM_onehot_state[5]_i_2_n_0\,
      I3 => Reset,
      I4 => iFull_i_3_n_0,
      I5 => iFull_i_4_n_0,
      O => iFull_i_1_n_0
    );
iFull_i_2: unisim.vcomponents.LUT4
    generic map(
      INIT => X"E32F"
    )
        port map (
      I0 => \i_Ctrl/state\(0),
      I1 => \i_Ctrl/state\(1),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(2),
      O => iFull_i_2_n_0
    );
iFull_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF01F10000"
    )
        port map (
      I0 => iFull_i_5_n_0,
      I1 => iEmpty_i_5_n_0,
      I2 => RAM_reg_0_15_0_7_i_11_n_0,
      I3 => iEmpty_i_6_n_0,
      I4 => iFull_i_6_n_0,
      I5 => iFull,
      O => iFull_i_3_n_0
    );
iFull_i_4: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i_I2C/RdNotWr\,
      I1 => \i_I2C/cntSCL\,
      O => iFull_i_4_n_0
    );
iFull_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFDFFFFFFFF"
    )
        port map (
      I0 => L(6),
      I1 => \cntSCL[6]_i_2_n_0\,
      I2 => L(2),
      I3 => \cntSCL[0]_i_2_n_0\,
      I4 => L(1),
      I5 => \i_I2C/p_1_in\,
      O => iFull_i_5_n_0
    );
iFull_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"2814428100000000"
    )
        port map (
      I0 => addrWr_reg(2),
      I1 => addrWr_reg(1),
      I2 => addrWr_reg(0),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I4 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I5 => iFull_i_7_n_0,
      O => iFull_i_6_n_0
    );
iFull_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00006A95AA550000"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(3),
      I1 => addrWr_reg(1),
      I2 => addrWr_reg(2),
      I3 => addrWr_reg(3),
      I4 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I5 => addrWr_reg(0),
      O => iFull_i_7_n_0
    );
\i_Ctrl/FSM_sequential_state_reg[0]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_Ctrl/next_state__0\(0),
      Q => \i_Ctrl/state\(0),
      S => Reset
    );
\i_Ctrl/FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_Ctrl/next_state__0\(1),
      Q => \i_Ctrl/state\(1),
      R => Reset
    );
\i_Ctrl/FSM_sequential_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_Ctrl/next_state__0\(2),
      Q => \i_Ctrl/state\(2),
      R => Reset
    );
\i_Ctrl/FSM_sequential_state_reg[3]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_Ctrl/next_state__0\(3),
      Q => \i_Ctrl/state\(3),
      S => Reset
    );
\i_Ctrl/X_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(0),
      Q => X(0),
      R => '0'
    );
\i_Ctrl/X_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(2),
      Q => X(10),
      R => '0'
    );
\i_Ctrl/X_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(3),
      Q => X(11),
      R => '0'
    );
\i_Ctrl/X_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(4),
      Q => X(12),
      R => '0'
    );
\i_Ctrl/X_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(5),
      Q => X(13),
      R => '0'
    );
\i_Ctrl/X_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(6),
      Q => X(14),
      R => '0'
    );
\i_Ctrl/X_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(7),
      Q => X(15),
      R => '0'
    );
\i_Ctrl/X_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(1),
      Q => X(1),
      R => '0'
    );
\i_Ctrl/X_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(2),
      Q => X(2),
      R => '0'
    );
\i_Ctrl/X_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(3),
      Q => X(3),
      R => '0'
    );
\i_Ctrl/X_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(4),
      Q => X(4),
      R => '0'
    );
\i_Ctrl/X_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(5),
      Q => X(5),
      R => '0'
    );
\i_Ctrl/X_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(6),
      Q => X(6),
      R => '0'
    );
\i_Ctrl/X_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg0\,
      D => DO(7),
      Q => X(7),
      R => '0'
    );
\i_Ctrl/X_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(0),
      Q => X(8),
      R => '0'
    );
\i_Ctrl/X_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/X_reg07_out\,
      D => DO(1),
      Q => X(9),
      R => '0'
    );
\i_Ctrl/Y_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(0),
      Q => Y(0),
      R => '0'
    );
\i_Ctrl/Y_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(2),
      Q => Y(10),
      R => '0'
    );
\i_Ctrl/Y_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(3),
      Q => Y(11),
      R => '0'
    );
\i_Ctrl/Y_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(4),
      Q => Y(12),
      R => '0'
    );
\i_Ctrl/Y_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(5),
      Q => Y(13),
      R => '0'
    );
\i_Ctrl/Y_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(6),
      Q => Y(14),
      R => '0'
    );
\i_Ctrl/Y_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(7),
      Q => Y(15),
      R => '0'
    );
\i_Ctrl/Y_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(1),
      Q => Y(1),
      R => '0'
    );
\i_Ctrl/Y_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(2),
      Q => Y(2),
      R => '0'
    );
\i_Ctrl/Y_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(3),
      Q => Y(3),
      R => '0'
    );
\i_Ctrl/Y_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(4),
      Q => Y(4),
      R => '0'
    );
\i_Ctrl/Y_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(5),
      Q => Y(5),
      R => '0'
    );
\i_Ctrl/Y_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(6),
      Q => Y(6),
      R => '0'
    );
\i_Ctrl/Y_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg0\,
      D => DO(7),
      Q => Y(7),
      R => '0'
    );
\i_Ctrl/Y_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(0),
      Q => Y(8),
      R => '0'
    );
\i_Ctrl/Y_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Y_reg04_out\,
      D => DO(1),
      Q => Y(9),
      R => '0'
    );
\i_Ctrl/Z_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(0),
      Q => Z(0),
      R => '0'
    );
\i_Ctrl/Z_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(2),
      Q => Z(10),
      R => '0'
    );
\i_Ctrl/Z_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(3),
      Q => Z(11),
      R => '0'
    );
\i_Ctrl/Z_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(4),
      Q => Z(12),
      R => '0'
    );
\i_Ctrl/Z_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(5),
      Q => Z(13),
      R => '0'
    );
\i_Ctrl/Z_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(6),
      Q => Z(14),
      R => '0'
    );
\i_Ctrl/Z_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(7),
      Q => Z(15),
      R => '0'
    );
\i_Ctrl/Z_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(1),
      Q => Z(1),
      R => '0'
    );
\i_Ctrl/Z_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(2),
      Q => Z(2),
      R => '0'
    );
\i_Ctrl/Z_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(3),
      Q => Z(3),
      R => '0'
    );
\i_Ctrl/Z_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(4),
      Q => Z(4),
      R => '0'
    );
\i_Ctrl/Z_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(5),
      Q => Z(5),
      R => '0'
    );
\i_Ctrl/Z_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(6),
      Q => Z(6),
      R => '0'
    );
\i_Ctrl/Z_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg0\,
      D => DO(7),
      Q => Z(7),
      R => '0'
    );
\i_Ctrl/Z_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(0),
      Q => Z(8),
      R => '0'
    );
\i_Ctrl/Z_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Ctrl/Z_reg01_out\,
      D => DO(1),
      Q => Z(9),
      R => '0'
    );
\i_Ctrl/current_DataRate_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \current_DataRate[3]_i_1_n_0\,
      D => DataRate(0),
      Q => current_DataRate(0),
      R => '0'
    );
\i_Ctrl/current_DataRate_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \current_DataRate[3]_i_1_n_0\,
      D => DataRate(1),
      Q => current_DataRate(1),
      R => '0'
    );
\i_Ctrl/current_DataRate_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \current_DataRate[3]_i_1_n_0\,
      D => DataRate(2),
      Q => current_DataRate(2),
      R => '0'
    );
\i_Ctrl/current_DataRate_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \current_DataRate[3]_i_1_n_0\,
      D => DataRate(3),
      Q => current_DataRate(3),
      R => '0'
    );
\i_Ctrl/idxROM_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => p_1_in(0),
      Q => \i_Ctrl/idxROM\(0),
      R => \idxROM[2]_i_1_n_0\
    );
\i_Ctrl/idxROM_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => p_1_in(1),
      Q => \i_Ctrl/idxROM\(1),
      R => \idxROM[2]_i_1_n_0\
    );
\i_Ctrl/idxROM_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => p_1_in(2),
      Q => \i_Ctrl/idxROM\(2),
      R => \idxROM[2]_i_1_n_0\
    );
\i_I2C/FSM_onehot_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[1]_i_1_n_0\,
      Q => \i_I2C/cntSCL\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[2]_i_1_n_0\,
      Q => \i_I2C/p_1_in\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[3]_i_1_n_0\,
      Q => \i_I2C/p_0_in\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \i_I2C/cntSCL\,
      Q => \i_I2C/cntBits\,
      R => Reset
    );
\i_I2C/FSM_onehot_state_reg[5]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => '0',
      Q => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      S => Reset
    );
\i_I2C/IOBUF_SCL\: unisim.vcomponents.IOBUF
    generic map(
      IOSTANDARD => "DEFAULT"
    )
        port map (
      I => '0',
      IO => Accel_SCL,
      O => \i_I2C/SCLin\,
      T => \i_I2C/SCLout_reg_n_0\
    );
\i_I2C/IOBUF_SDA\: unisim.vcomponents.IOBUF
    generic map(
      IOSTANDARD => "DEFAULT"
    )
        port map (
      I => '0',
      IO => Accel_SDA,
      O => \i_I2C/SDAin\,
      T => \i_I2C/T\
    );
\i_I2C/NACK_reg\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => NACK_i_1_n_0,
      Q => \^i2c_nack\,
      R => '0'
    );
\i_I2C/RdNotWr_reg\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => RdNotWr_i_1_n_0,
      Q => \i_I2C/RdNotWr\,
      R => '0'
    );
\i_I2C/SCLout_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => SCLout_i_1_n_0,
      Q => \i_I2C/SCLout_reg_n_0\,
      R => '0'
    );
\i_I2C/SDAout_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => SDAout_i_1_n_0,
      Q => \i_I2C/T\,
      R => '0'
    );
\i_I2C/cntBits_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[0]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[0]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[1]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[1]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[2]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[2]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[3]_i_2_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[3]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBytes_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[0]_i_1_n_0\,
      Q => \i_I2C/cntBytes\(0),
      R => '0'
    );
\i_I2C/cntBytes_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[1]_i_1_n_0\,
      Q => \i_I2C/cntBytes\(1),
      R => '0'
    );
\i_I2C/cntBytes_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[2]_i_1_n_0\,
      Q => \i_I2C/cntBytes\(2),
      R => '0'
    );
\i_I2C/cntBytes_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \cntBytes[3]_i_1_n_0\,
      D => \cntBytes[3]_i_2_n_0\,
      Q => \i_I2C/cntBytes\(3),
      R => '0'
    );
\i_I2C/cntSCL_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(0),
      Q => L(0),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(10),
      Q => L(10),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(11),
      Q => L(11),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(12),
      Q => L(12),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(13),
      Q => L(13),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(14),
      Q => L(14),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(1),
      Q => L(1),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(2),
      Q => L(2),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(3),
      Q => L(3),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(4),
      Q => L(4),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(5),
      Q => L(5),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(6),
      Q => L(6),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(7),
      Q => L(7),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(8),
      Q => L(8),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(9),
      Q => L(9),
      R => \i_I2C/cntSCL\
    );
\i_I2C/i_FIFO/RAM_reg_0_15_0_7\: unisim.vcomponents.RAM32M16
     port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRE(4) => '0',
      ADDRE(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRF(4) => '0',
      ADDRF(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRG(4) => '0',
      ADDRG(3 downto 0) => \i_I2C/i_FIFO/addrRd_reg\(3 downto 0),
      ADDRH(4) => '0',
      ADDRH(3 downto 0) => addrWr_reg(3 downto 0),
      DIA(1 downto 0) => DI(1 downto 0),
      DIB(1 downto 0) => DI(3 downto 2),
      DIC(1 downto 0) => DI(5 downto 4),
      DID(1 downto 0) => DI(7 downto 6),
      DIE(1 downto 0) => B"00",
      DIF(1 downto 0) => B"00",
      DIG(1 downto 0) => B"00",
      DIH(1 downto 0) => B"00",
      DOA(1 downto 0) => DO(1 downto 0),
      DOB(1 downto 0) => DO(3 downto 2),
      DOC(1 downto 0) => DO(5 downto 4),
      DOD(1 downto 0) => DO(7 downto 6),
      DOE(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOE_UNCONNECTED\(1 downto 0),
      DOF(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOF_UNCONNECTED\(1 downto 0),
      DOG(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOG_UNCONNECTED\(1 downto 0),
      DOH(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOH_UNCONNECTED\(1 downto 0),
      WCLK => Clk_100MHz,
      WE => DoPush
    );
\i_I2C/i_FIFO/addrRd_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(0),
      Q => \i_I2C/i_FIFO/addrRd_reg\(0),
      R => Reset
    );
\i_I2C/i_FIFO/addrRd_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(1),
      Q => \i_I2C/i_FIFO/addrRd_reg\(1),
      R => Reset
    );
\i_I2C/i_FIFO/addrRd_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(2),
      Q => \i_I2C/i_FIFO/addrRd_reg\(2),
      R => Reset
    );
\i_I2C/i_FIFO/addrRd_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/i_FIFO/p_1_in\,
      D => \i_I2C/i_FIFO/plusOp0_in\(3),
      Q => \i_I2C/i_FIFO/addrRd_reg\(3),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[0]_i_1_n_0\,
      Q => addrWr_reg(0),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[1]_i_1_n_0\,
      Q => addrWr_reg(1),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[2]_i_1_n_0\,
      Q => addrWr_reg(2),
      R => Reset
    );
\i_I2C/i_FIFO/addrWr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => DoPush,
      D => \addrWr[3]_i_1_n_0\,
      Q => addrWr_reg(3),
      R => Reset
    );
\i_I2C/i_FIFO/iEmpty_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => iEmpty_i_1_n_0,
      Q => FIFO_Empty,
      R => '0'
    );
\i_I2C/i_FIFO/iFull_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => iFull_i_1_n_0,
      Q => iFull,
      R => '0'
    );
\i_I2C/rSCLin_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/SCLin\,
      Q => rSCLin,
      R => '0'
    );
\i_I2C/rSDAin_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/SDAin\,
      Q => \i_I2C/rSDAin\,
      R => '0'
    );
\i_I2C/sregIn_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => \i_I2C/rSDAin\,
      Q => sregIn(0),
      R => '0'
    );
\i_I2C/sregIn_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => sregIn(0),
      Q => sregIn(1),
      R => '0'
    );
\i_I2C/sregIn_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => sregIn(1),
      Q => sregIn(2),
      R => '0'
    );
\i_I2C/sregIn_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => sregIn(2),
      Q => sregIn(3),
      R => '0'
    );
\i_I2C/sregIn_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => sregIn(3),
      Q => sregIn(4),
      R => '0'
    );
\i_I2C/sregIn_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => sregIn(4),
      Q => sregIn(5),
      R => '0'
    );
\i_I2C/sregIn_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => sregIn(5),
      Q => sregIn(6),
      R => '0'
    );
\i_I2C/sregIn_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sregIn0\,
      D => sregIn(6),
      Q => sregIn(7),
      R => '0'
    );
\i_I2C/sregOut[0]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0E0E0E0EFE0E0E0E"
    )
        port map (
      I0 => \i_I2C/sregOut[7]_i_4_n_0\,
      I1 => DO(0),
      I2 => \i_I2C/RdNotWr0\,
      I3 => \i_Ctrl/state\(3),
      I4 => \i_Ctrl/state\(2),
      I5 => \sregOut[0]_i_2_n_0\,
      O => \p_1_in__0\(0)
    );
\i_I2C/sregOut[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[0]\,
      I2 => \i_I2C/sregOut[7]_i_4_n_0\,
      I3 => DO(1),
      O => \p_1_in__0\(1)
    );
\i_I2C/sregOut[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[1]\,
      I2 => \i_I2C/sregOut[7]_i_4_n_0\,
      I3 => DO(2),
      O => \p_1_in__0\(2)
    );
\i_I2C/sregOut[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00CA"
    )
        port map (
      I0 => DO(3),
      I1 => \i_I2C/sregOut_reg_n_0_[2]\,
      I2 => \i_I2C/sregOut[7]_i_4_n_0\,
      I3 => \i_I2C/RdNotWr0\,
      O => \p_1_in__0\(3)
    );
\i_I2C/sregOut[4]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00CA"
    )
        port map (
      I0 => DO(4),
      I1 => \i_I2C/sregOut_reg_n_0_[3]\,
      I2 => \i_I2C/sregOut[7]_i_4_n_0\,
      I3 => \i_I2C/RdNotWr0\,
      O => \p_1_in__0\(4)
    );
\i_I2C/sregOut[5]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[4]\,
      I2 => \i_I2C/sregOut[7]_i_4_n_0\,
      I3 => DO(5),
      O => \p_1_in__0\(5)
    );
\i_I2C/sregOut[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00CA"
    )
        port map (
      I0 => DO(6),
      I1 => \i_I2C/sregOut_reg_n_0_[5]\,
      I2 => \i_I2C/sregOut[7]_i_4_n_0\,
      I3 => \i_I2C/RdNotWr0\,
      O => \p_1_in__0\(6)
    );
\i_I2C/sregOut[7]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"EFEA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \i_I2C/sregOut_reg_n_0_[6]\,
      I2 => \i_I2C/sregOut[7]_i_4_n_0\,
      I3 => DO(7),
      O => \p_1_in__0\(7)
    );
\i_I2C/sregOut[7]_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[1]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[2]\,
      O => \i_I2C/sregOut[7]_i_4_n_0\
    );
\i_I2C/sregOut_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(0),
      Q => \i_I2C/sregOut_reg_n_0_[0]\,
      R => '0'
    );
\i_I2C/sregOut_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(1),
      Q => \i_I2C/sregOut_reg_n_0_[1]\,
      R => '0'
    );
\i_I2C/sregOut_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(2),
      Q => \i_I2C/sregOut_reg_n_0_[2]\,
      R => '0'
    );
\i_I2C/sregOut_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(3),
      Q => \i_I2C/sregOut_reg_n_0_[3]\,
      R => '0'
    );
\i_I2C/sregOut_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(4),
      Q => \i_I2C/sregOut_reg_n_0_[4]\,
      R => '0'
    );
\i_I2C/sregOut_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(5),
      Q => \i_I2C/sregOut_reg_n_0_[5]\,
      R => '0'
    );
\i_I2C/sregOut_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(6),
      Q => \i_I2C/sregOut_reg_n_0_[6]\,
      R => '0'
    );
\i_I2C/sregOut_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_1_n_0\,
      D => \p_1_in__0\(7),
      Q => sregOut(7),
      R => '0'
    );
\idxROM[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(0),
      O => p_1_in(0)
    );
\idxROM[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(0),
      I1 => \i_Ctrl/idxROM\(1),
      O => p_1_in(1)
    );
\idxROM[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFD"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(0),
      I2 => \i_Ctrl/state\(3),
      I3 => \i_Ctrl/state\(2),
      O => \idxROM[2]_i_1_n_0\
    );
\idxROM[2]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \i_Ctrl/idxROM\(0),
      I1 => \i_Ctrl/idxROM\(1),
      I2 => \i_Ctrl/idxROM\(2),
      O => p_1_in(2)
    );
\sregIn[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000100000"
    )
        port map (
      I0 => \cntSCL[6]_i_2_n_0\,
      I1 => L(2),
      I2 => L(1),
      I3 => L(6),
      I4 => \i_I2C/p_1_in\,
      I5 => \cntSCL[0]_i_2_n_0\,
      O => \i_I2C/sregIn0\
    );
\sregOut[0]_i_2\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => \i_Ctrl/state\(1),
      I1 => \i_Ctrl/state\(0),
      O => \sregOut[0]_i_2_n_0\
    );
\sregOut[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAFFFFAABAAABA"
    )
        port map (
      I0 => \i_I2C/RdNotWr0\,
      I1 => \cntSCL[4]_i_2_n_0\,
      I2 => \i_I2C/p_0_in\,
      I3 => FIFO_Empty,
      I4 => \sregOut[7]_i_3_n_0\,
      I5 => NACK_i_3_n_0,
      O => \sregOut[7]_i_1_n_0\
    );
\sregOut[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFEFFFFFFFF"
    )
        port map (
      I0 => L(4),
      I1 => L(1),
      I2 => SCLout_i_3_n_0,
      I3 => \cntSCL[14]_i_4_n_0\,
      I4 => L(2),
      I5 => \i_I2C/p_0_in\,
      O => \sregOut[7]_i_3_n_0\
    );
end STRUCTURE;
