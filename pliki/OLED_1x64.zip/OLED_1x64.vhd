-- JS PWr Edu PL
-- --------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;

entity OLED_1x64 is
  port (
    Clk_100MHz : in STD_LOGIC;
    Line : in STD_LOGIC_VECTOR ( 63 downto 0 );
    DecPts : in STD_LOGIC_VECTOR ( 15 downto 0 );
    Blank : in STD_LOGIC_VECTOR ( 15 downto 0 );
    I2C_NACK : out STD_LOGIC;
    OLED_SCL : inout STD_LOGIC;
    OLED_SDA : inout STD_LOGIC
  );
end OLED_1x64;

architecture STRUCTURE of OLED_1x64 is
  signal DO : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \FSM_onehot_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_onehot_state[5]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_10_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_11_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_12_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_13_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_3_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_4_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_5_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_6_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_7_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_8_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[3]_i_9_n_0\ : STD_LOGIC;
  signal I2C_FIFO_Empty : STD_LOGIC;
  signal I2C_FIFO_Full : STD_LOGIC;
  signal \^i2c_nack\ : STD_LOGIC;
  signal L : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal NACK_i_1_n_0 : STD_LOGIC;
  signal NACK_i_2_n_0 : STD_LOGIC;
  signal NACK_i_3_n_0 : STD_LOGIC;
  signal NACK_i_4_n_0 : STD_LOGIC;
  signal NACK_i_5_n_0 : STD_LOGIC;
  signal NACK_i_6_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_10_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_11_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_12_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_14_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_15_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_16_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_17_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_18_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_19_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_1_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_20_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_21_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_24_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_25_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_26_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_27_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_28_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_29_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_30_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_31_n_0 : STD_LOGIC;
  signal RAM_reg_0_15_0_7_i_32_n_0 : STD_LOGIC;
  signal SCLout_i_1_n_0 : STD_LOGIC;
  signal SCLout_i_2_n_0 : STD_LOGIC;
  signal SCLout_i_3_n_0 : STD_LOGIC;
  signal SCLout_i_4_n_0 : STD_LOGIC;
  signal SCLout_i_5_n_0 : STD_LOGIC;
  signal SCLout_i_6_n_0 : STD_LOGIC;
  signal SCLout_i_7_n_0 : STD_LOGIC;
  signal SCLout_i_8_n_0 : STD_LOGIC;
  signal SCLout_i_9_n_0 : STD_LOGIC;
  signal SDAout_i_10_n_0 : STD_LOGIC;
  signal SDAout_i_11_n_0 : STD_LOGIC;
  signal SDAout_i_1_n_0 : STD_LOGIC;
  signal SDAout_i_2_n_0 : STD_LOGIC;
  signal SDAout_i_3_n_0 : STD_LOGIC;
  signal SDAout_i_5_n_0 : STD_LOGIC;
  signal SDAout_i_6_n_0 : STD_LOGIC;
  signal SDAout_i_7_n_0 : STD_LOGIC;
  signal SDAout_i_8_n_0 : STD_LOGIC;
  signal SDAout_i_9_n_0 : STD_LOGIC;
  signal \addrROM[2]_i_1_n_0\ : STD_LOGIC;
  signal \addrROM[5]_i_1_n_0\ : STD_LOGIC;
  signal \addrROM[5]_i_2_n_0\ : STD_LOGIC;
  signal \addrROM[5]_i_4_n_0\ : STD_LOGIC;
  signal \addrROM[5]_i_5_n_0\ : STD_LOGIC;
  signal \addrROM[5]_i_6_n_0\ : STD_LOGIC;
  signal \addrROM[5]_i_7_n_0\ : STD_LOGIC;
  signal \addrRd[0]_i_1_n_0\ : STD_LOGIC;
  signal \addrRd[1]_i_1_n_0\ : STD_LOGIC;
  signal \addrRd[2]_i_1_n_0\ : STD_LOGIC;
  signal \addrRd[3]_i_1_n_0\ : STD_LOGIC;
  signal \addrRd_rep[3]_i_1_n_0\ : STD_LOGIC;
  signal \addrRd_rep[3]_i_3_n_0\ : STD_LOGIC;
  signal \addrWr[0]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[1]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[2]_i_1_n_0\ : STD_LOGIC;
  signal \addrWr[3]_i_1_n_0\ : STD_LOGIC;
  signal addrWr_reg : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \cnt20b[0]_i_4_n_0\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_0\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_1\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_10\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_11\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_12\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_13\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_14\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_15\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_2\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_3\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_4\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_5\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_6\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_7\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_8\ : STD_LOGIC;
  signal \cnt20b_reg[0]_i_3_n_9\ : STD_LOGIC;
  signal \cnt20b_reg[16]_i_1_n_12\ : STD_LOGIC;
  signal \cnt20b_reg[16]_i_1_n_13\ : STD_LOGIC;
  signal \cnt20b_reg[16]_i_1_n_14\ : STD_LOGIC;
  signal \cnt20b_reg[16]_i_1_n_15\ : STD_LOGIC;
  signal \cnt20b_reg[16]_i_1_n_5\ : STD_LOGIC;
  signal \cnt20b_reg[16]_i_1_n_6\ : STD_LOGIC;
  signal \cnt20b_reg[16]_i_1_n_7\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_0\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_1\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_10\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_11\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_12\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_13\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_14\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_15\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_2\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_3\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_4\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_5\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_6\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_7\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_8\ : STD_LOGIC;
  signal \cnt20b_reg[8]_i_1_n_9\ : STD_LOGIC;
  signal \cntBits[0]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[1]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[2]_i_1_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_2_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_3_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_4_n_0\ : STD_LOGIC;
  signal \cntBits[3]_i_5_n_0\ : STD_LOGIC;
  signal \cntHeartbeat[6]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[10]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[12]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[14]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[5]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[6]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[9]_i_2_n_0\ : STD_LOGIC;
  signal \cntSCL[9]_i_3_n_0\ : STD_LOGIC;
  signal \cntSCL[9]_i_4_n_0\ : STD_LOGIC;
  signal \cntX[2]_i_1_n_0\ : STD_LOGIC;
  signal \cntX[6]_i_4_n_0\ : STD_LOGIC;
  signal data10 : STD_LOGIC;
  signal data2 : STD_LOGIC_VECTOR ( 7 downto 4 );
  signal \g0_b0__0_i_1_n_0\ : STD_LOGIC;
  signal \g0_b0__0_i_7_n_0\ : STD_LOGIC;
  signal \g0_b0__0_i_8_n_0\ : STD_LOGIC;
  signal \g0_b0__0_i_9_n_0\ : STD_LOGIC;
  signal \g0_b0__0_n_0\ : STD_LOGIC;
  signal g0_b0_n_0 : STD_LOGIC;
  signal \g0_b1__0_n_0\ : STD_LOGIC;
  signal g0_b1_n_0 : STD_LOGIC;
  signal \g0_b2__0_n_0\ : STD_LOGIC;
  signal g0_b2_n_0 : STD_LOGIC;
  signal \g0_b3__0_n_0\ : STD_LOGIC;
  signal g0_b3_n_0 : STD_LOGIC;
  signal \g0_b4__0_n_0\ : STD_LOGIC;
  signal g0_b4_n_0 : STD_LOGIC;
  signal \g0_b5__0_n_0\ : STD_LOGIC;
  signal g0_b5_n_0 : STD_LOGIC;
  signal \g0_b6__0_n_0\ : STD_LOGIC;
  signal g0_b6_n_0 : STD_LOGIC;
  signal g0_b7_n_0 : STD_LOGIC;
  signal g1_b0_n_0 : STD_LOGIC;
  signal g1_b1_n_0 : STD_LOGIC;
  signal g1_b2_n_0 : STD_LOGIC;
  signal g1_b3_n_0 : STD_LOGIC;
  signal g1_b6_n_0 : STD_LOGIC;
  signal iEmpty_i_1_n_0 : STD_LOGIC;
  signal iEmpty_i_2_n_0 : STD_LOGIC;
  signal iFull_i_1_n_0 : STD_LOGIC;
  signal iFull_i_2_n_0 : STD_LOGIC;
  signal \i_I2C/FSM_onehot_state_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/FSM_onehot_state_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_I2C/RdNotWr0\ : STD_LOGIC;
  signal \i_I2C/SCLin\ : STD_LOGIC;
  signal \i_I2C/SCLout_reg_n_0\ : STD_LOGIC;
  signal \i_I2C/SDAin\ : STD_LOGIC;
  signal \i_I2C/SDAout\ : STD_LOGIC;
  signal \i_I2C/T\ : STD_LOGIC;
  signal \i_I2C/cntBits\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_I2C/cntBits_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_I2C/cntSCL\ : STD_LOGIC;
  signal \i_I2C/cntSCL__0\ : STD_LOGIC_VECTOR ( 14 downto 0 );
  signal \i_I2C/i_FIFO/addrRd\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/i_FIFO/addrRd_reg\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/i_FIFO/plusOp0_in\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal \i_I2C/p_0_in\ : STD_LOGIC;
  signal \i_I2C/rSDAin\ : STD_LOGIC;
  signal \i_I2C/sclEnd\ : STD_LOGIC;
  signal \i_I2C/sregOut[0]_i_1_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut[1]_i_1_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut[2]_i_1_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut[3]_i_1_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut[4]_i_1_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut[5]_i_1_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut[6]_i_1_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut[7]_i_3_n_0\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_I2C/sregOut_reg_n_0_[6]\ : STD_LOGIC;
  signal \i_Master/addrROM_reg\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \i_Master/addrROM_reg__0\ : STD_LOGIC_VECTOR ( 4 downto 3 );
  signal \i_Master/addrROM_reg__0__0\ : STD_LOGIC_VECTOR ( 5 to 5 );
  signal \i_Master/cnt20b0\ : STD_LOGIC;
  signal \i_Master/cnt20b00_out\ : STD_LOGIC;
  signal \i_Master/cnt20b_reg\ : STD_LOGIC_VECTOR ( 19 downto 10 );
  signal \i_Master/cnt20b_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_Master/cnt20b_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_Master/cnt20b_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_Master/cnt20b_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_Master/cnt20b_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_Master/cnt20b_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_Master/cnt20b_reg_n_0_[6]\ : STD_LOGIC;
  signal \i_Master/cntHeartbeat0\ : STD_LOGIC;
  signal \i_Master/cntHeartbeat_reg\ : STD_LOGIC_VECTOR ( 6 downto 3 );
  signal \i_Master/cntHeartbeat_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_Master/cntHeartbeat_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_Master/cntHeartbeat_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_Master/cntHeartbeat_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_Master/cntX0\ : STD_LOGIC;
  signal \i_Master/cntX_reg\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \i_Master/cntX_reg__0\ : STD_LOGIC_VECTOR ( 6 downto 3 );
  signal \i_Master/next_state__0\ : STD_LOGIC_VECTOR ( 3 downto 1 );
  signal \i_Master/p_0_in\ : STD_LOGIC_VECTOR ( 2 downto 0 );
  signal \i_Master/p_0_out\ : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal \i_Master/regBlank_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[10]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[11]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[12]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[13]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[14]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[15]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[6]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[7]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[8]\ : STD_LOGIC;
  signal \i_Master/regBlank_reg_n_0_[9]\ : STD_LOGIC;
  signal \i_Master/regDI\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[10]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[11]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[12]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[13]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[14]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[15]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[16]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[17]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[18]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[19]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[20]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[21]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[22]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[23]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[24]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[25]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[26]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[27]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[28]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[29]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[30]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[31]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[32]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[33]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[34]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[35]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[36]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[37]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[38]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[39]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[40]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[41]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[42]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[43]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[44]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[45]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[46]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[47]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[48]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[49]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[50]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[51]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[52]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[53]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[54]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[55]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[56]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[57]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[58]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[59]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[60]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[61]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[62]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[63]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[6]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[7]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[8]\ : STD_LOGIC;
  signal \i_Master/regDI_reg_n_0_[9]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[0]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[10]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[11]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[12]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[13]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[14]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[1]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[2]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[3]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[4]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[5]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[6]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[7]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[8]\ : STD_LOGIC;
  signal \i_Master/regDecPts_reg_n_0_[9]\ : STD_LOGIC;
  signal \i_Master/state\ : STD_LOGIC_VECTOR ( 3 downto 0 );
  signal plusOp : STD_LOGIC_VECTOR ( 5 downto 0 );
  signal \plusOp__0\ : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal \plusOp__1\ : STD_LOGIC_VECTOR ( 6 downto 0 );
  signal rSCLin : STD_LOGIC;
  signal regBlank : STD_LOGIC_VECTOR ( 15 downto 1 );
  signal \regBlank[0]_i_1_n_0\ : STD_LOGIC;
  signal regDI : STD_LOGIC_VECTOR ( 63 downto 4 );
  signal regDecPts : STD_LOGIC_VECTOR ( 15 downto 1 );
  signal sel : STD_LOGIC_VECTOR ( 6 downto 1 );
  signal sregOut : STD_LOGIC_VECTOR ( 7 to 7 );
  signal \sregOut[7]_i_2_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_4_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_5_n_0\ : STD_LOGIC;
  signal \sregOut[7]_i_6_n_0\ : STD_LOGIC;
  signal \NLW_cnt20b_reg[16]_i_1_CO_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 3 );
  signal \NLW_cnt20b_reg[16]_i_1_O_UNCONNECTED\ : STD_LOGIC_VECTOR ( 7 downto 4 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOE_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOF_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOG_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  signal \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOH_UNCONNECTED\ : STD_LOGIC_VECTOR ( 1 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_onehot_state[0]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \FSM_onehot_state[3]_i_1\ : label is "soft_lutpair35";
  attribute SOFT_HLUTNM of \FSM_sequential_state[0]_i_1\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \FSM_sequential_state[1]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \FSM_sequential_state[2]_i_1\ : label is "soft_lutpair26";
  attribute SOFT_HLUTNM of \FSM_sequential_state[3]_i_2\ : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of \FSM_sequential_state[3]_i_7\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of NACK_i_2 : label is "soft_lutpair9";
  attribute SOFT_HLUTNM of NACK_i_3 : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of NACK_i_5 : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_11 : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_17 : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_21 : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_25 : label is "soft_lutpair23";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_28 : label is "soft_lutpair21";
  attribute SOFT_HLUTNM of RAM_reg_0_15_0_7_i_31 : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of SCLout_i_3 : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of SCLout_i_8 : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of SCLout_i_9 : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of SDAout_i_10 : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of SDAout_i_11 : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of SDAout_i_7 : label is "soft_lutpair6";
  attribute SOFT_HLUTNM of \addrROM[0]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \addrROM[1]_i_1\ : label is "soft_lutpair37";
  attribute SOFT_HLUTNM of \addrROM[2]_i_1\ : label is "soft_lutpair20";
  attribute SOFT_HLUTNM of \addrROM[3]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \addrROM[4]_i_1\ : label is "soft_lutpair16";
  attribute SOFT_HLUTNM of \addrROM[5]_i_4\ : label is "soft_lutpair33";
  attribute SOFT_HLUTNM of \addrROM[5]_i_5\ : label is "soft_lutpair22";
  attribute SOFT_HLUTNM of \addrRd[0]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \addrRd[1]_i_1\ : label is "soft_lutpair29";
  attribute SOFT_HLUTNM of \addrRd[2]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \addrRd[3]_i_1\ : label is "soft_lutpair5";
  attribute SOFT_HLUTNM of \addrRd_rep[0]_i_1\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \addrRd_rep[1]_i_1\ : label is "soft_lutpair39";
  attribute SOFT_HLUTNM of \addrRd_rep[2]_i_1\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \addrRd_rep[3]_i_2\ : label is "soft_lutpair25";
  attribute SOFT_HLUTNM of \addrRd_rep[3]_i_3\ : label is "soft_lutpair10";
  attribute SOFT_HLUTNM of \addrWr[0]_i_1\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \addrWr[1]_i_1\ : label is "soft_lutpair41";
  attribute SOFT_HLUTNM of \addrWr[2]_i_1\ : label is "soft_lutpair24";
  attribute SOFT_HLUTNM of \addrWr[3]_i_1\ : label is "soft_lutpair24";
  attribute ADDER_THRESHOLD : integer;
  attribute ADDER_THRESHOLD of \cnt20b_reg[0]_i_3\ : label is 16;
  attribute ADDER_THRESHOLD of \cnt20b_reg[16]_i_1\ : label is 16;
  attribute ADDER_THRESHOLD of \cnt20b_reg[8]_i_1\ : label is 16;
  attribute SOFT_HLUTNM of \cntBits[0]_i_1\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \cntBits[1]_i_1\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \cntBits[2]_i_1\ : label is "soft_lutpair34";
  attribute SOFT_HLUTNM of \cntBits[3]_i_2\ : label is "soft_lutpair27";
  attribute SOFT_HLUTNM of \cntBits[3]_i_4\ : label is "soft_lutpair4";
  attribute SOFT_HLUTNM of \cntBits[3]_i_5\ : label is "soft_lutpair32";
  attribute SOFT_HLUTNM of \cntHeartbeat[0]_i_1\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \cntHeartbeat[1]_i_1\ : label is "soft_lutpair40";
  attribute SOFT_HLUTNM of \cntHeartbeat[2]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \cntHeartbeat[3]_i_1\ : label is "soft_lutpair28";
  attribute SOFT_HLUTNM of \cntHeartbeat[4]_i_1\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \cntHeartbeat[6]_i_2\ : label is "soft_lutpair15";
  attribute SOFT_HLUTNM of \cntSCL[0]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \cntSCL[11]_i_1\ : label is "soft_lutpair13";
  attribute SOFT_HLUTNM of \cntSCL[13]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cntSCL[14]_i_1\ : label is "soft_lutpair12";
  attribute SOFT_HLUTNM of \cntSCL[1]_i_1\ : label is "soft_lutpair38";
  attribute SOFT_HLUTNM of \cntSCL[2]_i_1\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \cntSCL[4]_i_1\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \cntSCL[5]_i_2\ : label is "soft_lutpair14";
  attribute SOFT_HLUTNM of \cntSCL[6]_i_2\ : label is "soft_lutpair8";
  attribute SOFT_HLUTNM of \cntSCL[9]_i_4\ : label is "soft_lutpair30";
  attribute SOFT_HLUTNM of \cntX[1]_i_1\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \cntX[2]_i_1\ : label is "soft_lutpair31";
  attribute SOFT_HLUTNM of \cntX[3]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \cntX[4]_i_1\ : label is "soft_lutpair17";
  attribute SOFT_HLUTNM of \cntX[6]_i_3\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \cntX[6]_i_4\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of g0_b0 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of \g0_b0__0_i_1\ : label is "soft_lutpair36";
  attribute SOFT_HLUTNM of \g0_b0__0_i_2\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of \g0_b0__0_i_8\ : label is "soft_lutpair18";
  attribute SOFT_HLUTNM of \g0_b0__0_i_9\ : label is "soft_lutpair19";
  attribute SOFT_HLUTNM of g0_b1 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of g0_b2 : label is "soft_lutpair2";
  attribute SOFT_HLUTNM of g0_b3 : label is "soft_lutpair3";
  attribute SOFT_HLUTNM of g0_b4 : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of g0_b5 : label is "soft_lutpair7";
  attribute SOFT_HLUTNM of g0_b6 : label is "soft_lutpair11";
  attribute SOFT_HLUTNM of g0_b7 : label is "soft_lutpair11";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[0]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[1]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[3]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[4]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute FSM_ENCODED_STATES of \i_I2C/FSM_onehot_state_reg[5]\ : label is "sreset:100000,sidle:000010,sstart:010000,sbytewrite:001000,sstop:000001,sbyteread:000100";
  attribute box_type : string;
  attribute box_type of \i_I2C/IOBUF_SCL\ : label is "PRIMITIVE";
  attribute box_type of \i_I2C/IOBUF_SDA\ : label is "PRIMITIVE";
  attribute METHODOLOGY_DRC_VIOS : string;
  attribute METHODOLOGY_DRC_VIOS of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "";
  attribute RTL_RAM_BITS : integer;
  attribute RTL_RAM_BITS of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 128;
  attribute RTL_RAM_NAME : string;
  attribute RTL_RAM_NAME of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "OLED_1x64/i_I2C/i_FIFO/RAM_reg";
  attribute RTL_RAM_STYLE : string;
  attribute RTL_RAM_STYLE of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "auto";
  attribute RTL_RAM_TYPE : string;
  attribute RTL_RAM_TYPE of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is "RAM_SDP";
  attribute ram_addr_begin : integer;
  attribute ram_addr_begin of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_addr_end : integer;
  attribute ram_addr_end of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 15;
  attribute ram_offset : integer;
  attribute ram_offset of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_slice_begin : integer;
  attribute ram_slice_begin of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 0;
  attribute ram_slice_end : integer;
  attribute ram_slice_end of \i_I2C/i_FIFO/RAM_reg_0_15_0_7\ : label is 7;
  attribute IOB : string;
  attribute IOB of \i_I2C/rSCLin_reg\ : label is "TRUE";
  attribute IOB of \i_I2C/rSDAin_reg\ : label is "TRUE";
  attribute FSM_ENCODED_STATES of \i_Master/FSM_sequential_state_reg[0]\ : label is "swaitinit:0000,sgocls:0001,swaitidle:0011,spushinit:0101,spixels:0111,swaiteol:0110,sgopixels:0100,sgoinit:1000,sreset:1001,swaitconfig:1100,sgoconfig:1010,spushconfig:1011,swaitcls:1101,spushcls:0010";
  attribute FSM_ENCODED_STATES of \i_Master/FSM_sequential_state_reg[1]\ : label is "swaitinit:0000,sgocls:0001,swaitidle:0011,spushinit:0101,spixels:0111,swaiteol:0110,sgopixels:0100,sgoinit:1000,sreset:1001,swaitconfig:1100,sgoconfig:1010,spushconfig:1011,swaitcls:1101,spushcls:0010";
  attribute FSM_ENCODED_STATES of \i_Master/FSM_sequential_state_reg[2]\ : label is "swaitinit:0000,sgocls:0001,swaitidle:0011,spushinit:0101,spixels:0111,swaiteol:0110,sgopixels:0100,sgoinit:1000,sreset:1001,swaitconfig:1100,sgoconfig:1010,spushconfig:1011,swaitcls:1101,spushcls:0010";
  attribute FSM_ENCODED_STATES of \i_Master/FSM_sequential_state_reg[3]\ : label is "swaitinit:0000,sgocls:0001,swaitidle:0011,spushinit:0101,spixels:0111,swaiteol:0110,sgopixels:0100,sgoinit:1000,sreset:1001,swaitconfig:1100,sgoconfig:1010,spushconfig:1011,swaitcls:1101,spushcls:0010";
  attribute SOFT_HLUTNM of \sregOut[7]_i_5\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \sregOut[7]_i_6\ : label is "soft_lutpair9";
begin
  I2C_NACK <= \^i2c_nack\;
\FSM_onehot_state[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"8"
    )
        port map (
      I0 => \i_I2C/p_0_in\,
      I1 => I2C_FIFO_Empty,
      O => \FSM_onehot_state[0]_i_1_n_0\
    );
\FSM_onehot_state[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"E"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      O => \FSM_onehot_state[1]_i_1_n_0\
    );
\FSM_onehot_state[3]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => \i_I2C/cntBits\,
      I1 => I2C_FIFO_Empty,
      I2 => \i_I2C/p_0_in\,
      O => \FSM_onehot_state[3]_i_1_n_0\
    );
\FSM_onehot_state[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFD00"
    )
        port map (
      I0 => NACK_i_5_n_0,
      I1 => \i_I2C/cntBits\,
      I2 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I3 => \i_I2C/sclEnd\,
      I4 => \i_I2C/RdNotWr0\,
      I5 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      O => \FSM_onehot_state[5]_i_1_n_0\
    );
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"15"
    )
        port map (
      I0 => \i_Master/state\(0),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      O => \FSM_sequential_state[0]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"D924"
    )
        port map (
      I0 => \i_Master/state\(3),
      I1 => \i_Master/state\(0),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/state\(2),
      O => \i_Master/next_state__0\(1)
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6B54"
    )
        port map (
      I0 => \i_Master/state\(0),
      I1 => \i_Master/state\(2),
      I2 => \i_Master/state\(3),
      I3 => \i_Master/state\(1),
      O => \i_Master/next_state__0\(2)
    );
\FSM_sequential_state[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EFEEEFEF"
    )
        port map (
      I0 => \FSM_sequential_state[3]_i_3_n_0\,
      I1 => \FSM_sequential_state[3]_i_4_n_0\,
      I2 => \i_Master/state\(2),
      I3 => \FSM_sequential_state[3]_i_5_n_0\,
      I4 => \FSM_sequential_state[3]_i_6_n_0\,
      O => \FSM_sequential_state[3]_i_1_n_0\
    );
\FSM_sequential_state[3]_i_10\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"EFFFFFFFFFFFFFFF"
    )
        port map (
      I0 => \FSM_sequential_state[3]_i_12_n_0\,
      I1 => \FSM_sequential_state[3]_i_13_n_0\,
      I2 => \i_Master/cnt20b_reg_n_0_[4]\,
      I3 => \i_Master/cnt20b_reg_n_0_[0]\,
      I4 => \i_Master/cnt20b_reg_n_0_[2]\,
      I5 => \i_Master/p_0_in\(0),
      O => \FSM_sequential_state[3]_i_10_n_0\
    );
\FSM_sequential_state[3]_i_11\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \i_Master/cnt20b_reg\(12),
      I1 => \i_Master/cnt20b_reg\(15),
      I2 => \i_Master/cnt20b_reg\(16),
      I3 => \i_Master/cnt20b_reg\(11),
      O => \FSM_sequential_state[3]_i_11_n_0\
    );
\FSM_sequential_state[3]_i_12\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"3FBF3FFF"
    )
        port map (
      I0 => I2C_FIFO_Full,
      I1 => \i_Master/cnt20b_reg_n_0_[1]\,
      I2 => \i_Master/p_0_in\(2),
      I3 => \i_Master/state\(0),
      I4 => \i_Master/state\(1),
      O => \FSM_sequential_state[3]_i_12_n_0\
    );
\FSM_sequential_state[3]_i_13\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7FFF"
    )
        port map (
      I0 => \i_Master/cnt20b_reg_n_0_[6]\,
      I1 => \i_Master/p_0_in\(1),
      I2 => \i_Master/cnt20b_reg_n_0_[5]\,
      I3 => \i_Master/cnt20b_reg_n_0_[3]\,
      O => \FSM_sequential_state[3]_i_13_n_0\
    );
\FSM_sequential_state[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"88B8"
    )
        port map (
      I0 => \i_Master/state\(3),
      I1 => \i_Master/state\(0),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/state\(2),
      O => \i_Master/next_state__0\(3)
    );
\FSM_sequential_state[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"1100F0FF00000000"
    )
        port map (
      I0 => I2C_FIFO_Full,
      I1 => \FSM_sequential_state[3]_i_7_n_0\,
      I2 => \i_I2C/cntSCL\,
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \FSM_sequential_state[3]_i_8_n_0\,
      O => \FSM_sequential_state[3]_i_3_n_0\
    );
\FSM_sequential_state[3]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"5555015500000100"
    )
        port map (
      I0 => \i_Master/state\(1),
      I1 => \addrROM[5]_i_7_n_0\,
      I2 => I2C_FIFO_Full,
      I3 => \i_Master/state\(0),
      I4 => \i_Master/state\(3),
      I5 => \i_I2C/cntSCL\,
      O => \FSM_sequential_state[3]_i_4_n_0\
    );
\FSM_sequential_state[3]_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000055557555"
    )
        port map (
      I0 => \i_Master/state\(0),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/cnt20b_reg\(17),
      I3 => \i_Master/cnt20b_reg\(18),
      I4 => \FSM_sequential_state[3]_i_9_n_0\,
      I5 => \FSM_sequential_state[3]_i_10_n_0\,
      O => \FSM_sequential_state[3]_i_5_n_0\
    );
\FSM_sequential_state[3]_i_6\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"E0FF000F"
    )
        port map (
      I0 => I2C_FIFO_Full,
      I1 => \addrROM[5]_i_6_n_0\,
      I2 => \i_Master/state\(0),
      I3 => \i_Master/state\(3),
      I4 => \i_Master/state\(1),
      O => \FSM_sequential_state[3]_i_6_n_0\
    );
\FSM_sequential_state[3]_i_7\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"F7FFFFFF"
    )
        port map (
      I0 => \i_Master/cntX_reg__0\(5),
      I1 => \i_Master/cntX_reg__0\(3),
      I2 => \cntX[6]_i_4_n_0\,
      I3 => \i_Master/cntX_reg__0\(4),
      I4 => \i_Master/cntX_reg__0\(6),
      O => \FSM_sequential_state[3]_i_7_n_0\
    );
\FSM_sequential_state[3]_i_8\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"2"
    )
        port map (
      I0 => \i_Master/state\(2),
      I1 => \i_Master/state\(3),
      O => \FSM_sequential_state[3]_i_8_n_0\
    );
\FSM_sequential_state[3]_i_9\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFBFFF"
    )
        port map (
      I0 => \i_Master/cnt20b_reg\(19),
      I1 => \i_Master/cnt20b_reg\(14),
      I2 => \i_Master/cnt20b_reg\(10),
      I3 => \i_Master/cnt20b_reg\(13),
      I4 => \FSM_sequential_state[3]_i_11_n_0\,
      O => \FSM_sequential_state[3]_i_9_n_0\
    );
NACK_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAAAAAE"
    )
        port map (
      I0 => \^i2c_nack\,
      I1 => NACK_i_2_n_0,
      I2 => NACK_i_3_n_0,
      I3 => NACK_i_4_n_0,
      I4 => NACK_i_5_n_0,
      I5 => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      O => NACK_i_1_n_0
    );
NACK_i_2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => NACK_i_6_n_0,
      I1 => L(8),
      I2 => L(11),
      I3 => L(10),
      I4 => L(4),
      O => NACK_i_2_n_0
    );
NACK_i_3: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => L(2),
      I1 => L(1),
      I2 => L(3),
      O => NACK_i_3_n_0
    );
NACK_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"F7FFFFFFFFFFFFFF"
    )
        port map (
      I0 => L(5),
      I1 => \i_I2C/rSDAin\,
      I2 => L(0),
      I3 => L(9),
      I4 => L(7),
      I5 => L(6),
      O => NACK_i_4_n_0
    );
NACK_i_5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFBFFFF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[1]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/p_0_in\,
      O => NACK_i_5_n_0
    );
NACK_i_6: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => L(12),
      I1 => L(14),
      I2 => L(13),
      O => NACK_i_6_n_0
    );
RAM_reg_0_15_0_7_i_1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"04510014"
    )
        port map (
      I0 => I2C_FIFO_Full,
      I1 => \i_Master/state\(1),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(3),
      I4 => \i_Master/state\(0),
      O => RAM_reg_0_15_0_7_i_1_n_0
    );
RAM_reg_0_15_0_7_i_10: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7707077707770777"
    )
        port map (
      I0 => g0_b1_n_0,
      I1 => \i_Master/state\(2),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/addrROM_reg\(2),
      I4 => \i_Master/addrROM_reg\(0),
      I5 => \i_Master/addrROM_reg\(1),
      O => RAM_reg_0_15_0_7_i_10_n_0
    );
RAM_reg_0_15_0_7_i_11: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4030"
    )
        port map (
      I0 => \i_Master/state\(2),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(0),
      I3 => \i_Master/state\(1),
      O => RAM_reg_0_15_0_7_i_11_n_0
    );
RAM_reg_0_15_0_7_i_12: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF61324132"
    )
        port map (
      I0 => \i_Master/state\(2),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(0),
      I3 => \i_Master/state\(1),
      I4 => RAM_reg_0_15_0_7_i_17_n_0,
      I5 => RAM_reg_0_15_0_7_i_18_n_0,
      O => RAM_reg_0_15_0_7_i_12_n_0
    );
RAM_reg_0_15_0_7_i_13: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80888888"
    )
        port map (
      I0 => \i_Master/regDI_reg_n_0_[62]\,
      I1 => \i_Master/regDI_reg_n_0_[63]\,
      I2 => \i_Master/regDI_reg_n_0_[61]\,
      I3 => \g0_b0__0_i_7_n_0\,
      I4 => \g0_b0__0_i_8_n_0\,
      O => sel(6)
    );
RAM_reg_0_15_0_7_i_14: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7000077777777777"
    )
        port map (
      I0 => g0_b0_n_0,
      I1 => \i_Master/state\(2),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg\(1),
      I4 => \i_Master/addrROM_reg\(0),
      I5 => \i_Master/state\(1),
      O => RAM_reg_0_15_0_7_i_14_n_0
    );
RAM_reg_0_15_0_7_i_15: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000010000"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg\(3),
      I1 => \i_Master/cntHeartbeat_reg\(6),
      I2 => \i_Master/cntHeartbeat_reg\(5),
      I3 => RAM_reg_0_15_0_7_i_28_n_0,
      I4 => \i_Master/cntX_reg__0\(6),
      I5 => RAM_reg_0_15_0_7_i_29_n_0,
      O => RAM_reg_0_15_0_7_i_15_n_0
    );
RAM_reg_0_15_0_7_i_16: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000BFFFBFFFBFFF"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(2),
      I1 => \i_Master/state\(1),
      I2 => \i_Master/addrROM_reg\(1),
      I3 => \i_Master/addrROM_reg\(0),
      I4 => g0_b3_n_0,
      I5 => \i_Master/state\(2),
      O => RAM_reg_0_15_0_7_i_16_n_0
    );
RAM_reg_0_15_0_7_i_17: unisim.vcomponents.LUT3
    generic map(
      INIT => X"41"
    )
        port map (
      I0 => \i_Master/cntX_reg\(0),
      I1 => \i_Master/cntX_reg\(1),
      I2 => \i_Master/cntX_reg\(2),
      O => RAM_reg_0_15_0_7_i_17_n_0
    );
RAM_reg_0_15_0_7_i_18: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFF7FFFFFFFFFF"
    )
        port map (
      I0 => \i_Master/state\(1),
      I1 => \i_Master/state\(0),
      I2 => \i_Master/state\(3),
      I3 => \i_Master/state\(2),
      I4 => \i_Master/regBlank_reg_n_0_[15]\,
      I5 => \cntX[6]_i_4_n_0\,
      O => RAM_reg_0_15_0_7_i_18_n_0
    );
RAM_reg_0_15_0_7_i_19: unisim.vcomponents.LUT6
    generic map(
      INIT => X"44444F4444444444"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_30_n_0,
      I1 => RAM_reg_0_15_0_7_i_11_n_0,
      I2 => \i_Master/p_0_in\(2),
      I3 => \i_Master/p_0_in\(1),
      I4 => \i_Master/p_0_in\(0),
      I5 => RAM_reg_0_15_0_7_i_31_n_0,
      O => RAM_reg_0_15_0_7_i_19_n_0
    );
RAM_reg_0_15_0_7_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4F444F4F4F444444"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_10_n_0,
      I1 => RAM_reg_0_15_0_7_i_11_n_0,
      I2 => RAM_reg_0_15_0_7_i_12_n_0,
      I3 => g1_b0_n_0,
      I4 => sel(6),
      I5 => \g0_b0__0_n_0\,
      O => \i_Master/p_0_out\(1)
    );
RAM_reg_0_15_0_7_i_20: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7077700777777777"
    )
        port map (
      I0 => g0_b5_n_0,
      I1 => \i_Master/state\(2),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg\(0),
      I4 => \i_Master/addrROM_reg\(1),
      I5 => \i_Master/state\(1),
      O => RAM_reg_0_15_0_7_i_20_n_0
    );
RAM_reg_0_15_0_7_i_21: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FF7F"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/addrROM_reg\(2),
      O => RAM_reg_0_15_0_7_i_21_n_0
    );
RAM_reg_0_15_0_7_i_24: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0020000000000000"
    )
        port map (
      I0 => data10,
      I1 => \cntX[6]_i_4_n_0\,
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(3),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/state\(1),
      O => RAM_reg_0_15_0_7_i_24_n_0
    );
RAM_reg_0_15_0_7_i_25: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0400"
    )
        port map (
      I0 => \i_Master/state\(3),
      I1 => \i_Master/state\(2),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/state\(0),
      O => RAM_reg_0_15_0_7_i_25_n_0
    );
RAM_reg_0_15_0_7_i_26: unisim.vcomponents.LUT6
    generic map(
      INIT => X"10001F0C10031F0C"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_21_n_0,
      I1 => \i_Master/state\(2),
      I2 => \i_Master/state\(3),
      I3 => \i_Master/state\(0),
      I4 => \i_Master/state\(1),
      I5 => RAM_reg_0_15_0_7_i_32_n_0,
      O => RAM_reg_0_15_0_7_i_26_n_0
    );
RAM_reg_0_15_0_7_i_27: unisim.vcomponents.LUT6
    generic map(
      INIT => X"090909FFFFFF09FF"
    )
        port map (
      I0 => \i_Master/cntX_reg\(2),
      I1 => \i_Master/cntX_reg\(1),
      I2 => \i_Master/cntX_reg\(0),
      I3 => \g0_b5__0_n_0\,
      I4 => sel(6),
      I5 => g1_b1_n_0,
      O => RAM_reg_0_15_0_7_i_27_n_0
    );
RAM_reg_0_15_0_7_i_28: unisim.vcomponents.LUT4
    generic map(
      INIT => X"DFFF"
    )
        port map (
      I0 => \i_Master/state\(2),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(0),
      I3 => \i_Master/state\(1),
      O => RAM_reg_0_15_0_7_i_28_n_0
    );
RAM_reg_0_15_0_7_i_29: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => \i_Master/cntX_reg__0\(4),
      I1 => \i_Master/cntX_reg\(2),
      I2 => \i_Master/cntX_reg\(0),
      I3 => \i_Master/cntX_reg\(1),
      I4 => \i_Master/cntX_reg__0\(3),
      I5 => \i_Master/cntX_reg__0\(5),
      O => RAM_reg_0_15_0_7_i_29_n_0
    );
RAM_reg_0_15_0_7_i_3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF10000500"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_14_n_0,
      I1 => \i_Master/state\(2),
      I2 => \i_Master/state\(3),
      I3 => \i_Master/state\(0),
      I4 => \i_Master/state\(1),
      I5 => RAM_reg_0_15_0_7_i_15_n_0,
      O => \i_Master/p_0_out\(0)
    );
RAM_reg_0_15_0_7_i_30: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000BFFFBFFFBFFF"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(2),
      I1 => \i_Master/state\(1),
      I2 => \i_Master/addrROM_reg\(1),
      I3 => \i_Master/addrROM_reg\(0),
      I4 => g0_b2_n_0,
      I5 => \i_Master/state\(2),
      O => RAM_reg_0_15_0_7_i_30_n_0
    );
RAM_reg_0_15_0_7_i_31: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0010"
    )
        port map (
      I0 => \i_Master/state\(3),
      I1 => \i_Master/state\(2),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/state\(0),
      O => RAM_reg_0_15_0_7_i_31_n_0
    );
RAM_reg_0_15_0_7_i_32: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FD"
    )
        port map (
      I0 => \i_Master/p_0_in\(2),
      I1 => \i_Master/p_0_in\(1),
      I2 => \i_Master/p_0_in\(0),
      O => RAM_reg_0_15_0_7_i_32_n_0
    );
RAM_reg_0_15_0_7_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4F444F4F4F444444"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_16_n_0,
      I1 => RAM_reg_0_15_0_7_i_11_n_0,
      I2 => RAM_reg_0_15_0_7_i_12_n_0,
      I3 => g1_b2_n_0,
      I4 => sel(6),
      I5 => \g0_b2__0_n_0\,
      O => \i_Master/p_0_out\(3)
    );
RAM_reg_0_15_0_7_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFF00005404"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_17_n_0,
      I1 => \g0_b1__0_n_0\,
      I2 => sel(6),
      I3 => g1_b1_n_0,
      I4 => RAM_reg_0_15_0_7_i_18_n_0,
      I5 => RAM_reg_0_15_0_7_i_19_n_0,
      O => \i_Master/p_0_out\(2)
    );
RAM_reg_0_15_0_7_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4540FFFF45404540"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_12_n_0,
      I1 => g1_b2_n_0,
      I2 => sel(6),
      I3 => \g0_b4__0_n_0\,
      I4 => RAM_reg_0_15_0_7_i_20_n_0,
      I5 => RAM_reg_0_15_0_7_i_11_n_0,
      O => \i_Master/p_0_out\(5)
    );
RAM_reg_0_15_0_7_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"D500FFFFD500D500"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_21_n_0,
      I1 => g0_b4_n_0,
      I2 => \i_Master/state\(2),
      I3 => RAM_reg_0_15_0_7_i_11_n_0,
      I4 => RAM_reg_0_15_0_7_i_12_n_0,
      I5 => data2(4),
      O => \i_Master/p_0_out\(4)
    );
RAM_reg_0_15_0_7_i_8: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFF4F4F4"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_12_n_0,
      I1 => data2(7),
      I2 => RAM_reg_0_15_0_7_i_24_n_0,
      I3 => g0_b7_n_0,
      I4 => RAM_reg_0_15_0_7_i_25_n_0,
      O => \i_Master/p_0_out\(7)
    );
RAM_reg_0_15_0_7_i_9: unisim.vcomponents.LUT5
    generic map(
      INIT => X"D0D0D0DD"
    )
        port map (
      I0 => RAM_reg_0_15_0_7_i_25_n_0,
      I1 => g0_b6_n_0,
      I2 => RAM_reg_0_15_0_7_i_26_n_0,
      I3 => RAM_reg_0_15_0_7_i_18_n_0,
      I4 => RAM_reg_0_15_0_7_i_27_n_0,
      O => \i_Master/p_0_out\(6)
    );
SCLout_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFDFCCCF0C0ECC0F"
    )
        port map (
      I0 => SCLout_i_2_n_0,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I2 => SCLout_i_3_n_0,
      I3 => \i_I2C/cntBits\,
      I4 => SCLout_i_4_n_0,
      I5 => \i_I2C/SCLout_reg_n_0\,
      O => SCLout_i_1_n_0
    );
SCLout_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000020000"
    )
        port map (
      I0 => SCLout_i_5_n_0,
      I1 => L(13),
      I2 => L(14),
      I3 => L(12),
      I4 => L(6),
      I5 => L(9),
      O => SCLout_i_2_n_0
    );
SCLout_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFF5777"
    )
        port map (
      I0 => SCLout_i_5_n_0,
      I1 => L(8),
      I2 => L(7),
      I3 => L(6),
      I4 => SCLout_i_6_n_0,
      O => SCLout_i_3_n_0
    );
SCLout_i_4: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFBFFF"
    )
        port map (
      I0 => SCLout_i_7_n_0,
      I1 => L(2),
      I2 => L(1),
      I3 => L(3),
      I4 => SCLout_i_8_n_0,
      I5 => \cntBits[3]_i_3_n_0\,
      O => SCLout_i_4_n_0
    );
SCLout_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000020000"
    )
        port map (
      I0 => L(7),
      I1 => SDAout_i_10_n_0,
      I2 => L(2),
      I3 => L(0),
      I4 => L(1),
      I5 => SCLout_i_9_n_0,
      O => SCLout_i_5_n_0
    );
SCLout_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFF2"
    )
        port map (
      I0 => L(9),
      I1 => L(10),
      I2 => L(11),
      I3 => L(13),
      I4 => L(14),
      I5 => L(12),
      O => SCLout_i_6_n_0
    );
SCLout_i_7: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFF07FFFF"
    )
        port map (
      I0 => L(6),
      I1 => L(7),
      I2 => L(8),
      I3 => L(4),
      I4 => L(5),
      I5 => L(0),
      O => SCLout_i_7_n_0
    );
SCLout_i_8: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FEFF"
    )
        port map (
      I0 => L(10),
      I1 => L(11),
      I2 => L(8),
      I3 => L(7),
      O => SCLout_i_8_n_0
    );
SCLout_i_9: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => L(4),
      I1 => L(3),
      I2 => L(5),
      O => SCLout_i_9_n_0
    );
SDAout_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"8080808880808000"
    )
        port map (
      I0 => SDAout_i_2_n_0,
      I1 => SDAout_i_3_n_0,
      I2 => \i_I2C/SDAout\,
      I3 => SDAout_i_5_n_0,
      I4 => SDAout_i_6_n_0,
      I5 => \i_I2C/T\,
      O => SDAout_i_1_n_0
    );
SDAout_i_10: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => L(8),
      I1 => L(11),
      I2 => L(10),
      O => SDAout_i_10_n_0
    );
SDAout_i_11: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => L(3),
      I1 => L(0),
      I2 => L(2),
      I3 => L(1),
      O => SDAout_i_11_n_0
    );
SDAout_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFFFFFFFFFFFF"
    )
        port map (
      I0 => \sregOut[7]_i_6_n_0\,
      I1 => SDAout_i_7_n_0,
      I2 => L(7),
      I3 => L(5),
      I4 => \sregOut[7]_i_5_n_0\,
      I5 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      O => SDAout_i_2_n_0
    );
SDAout_i_3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FEFFFFFF"
    )
        port map (
      I0 => SDAout_i_8_n_0,
      I1 => L(11),
      I2 => L(10),
      I3 => L(7),
      I4 => \sregOut[7]_i_5_n_0\,
      O => SDAout_i_3_n_0
    );
SDAout_i_4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFEFFFFF"
    )
        port map (
      I0 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I1 => sregOut(7),
      I2 => \addrRd_rep[3]_i_3_n_0\,
      I3 => SDAout_i_9_n_0,
      I4 => NACK_i_2_n_0,
      O => \i_I2C/SDAout\
    );
SDAout_i_5: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000001"
    )
        port map (
      I0 => SDAout_i_9_n_0,
      I1 => NACK_i_6_n_0,
      I2 => SDAout_i_10_n_0,
      I3 => L(4),
      I4 => \i_I2C/cntBits\,
      I5 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      O => SDAout_i_5_n_0
    );
SDAout_i_6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000088880080"
    )
        port map (
      I0 => \cntSCL[9]_i_3_n_0\,
      I1 => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      I2 => L(6),
      I3 => L(7),
      I4 => L(8),
      I5 => \cntBits[3]_i_3_n_0\,
      O => SDAout_i_6_n_0
    );
SDAout_i_7: unisim.vcomponents.LUT3
    generic map(
      INIT => X"BA"
    )
        port map (
      I0 => L(8),
      I1 => L(7),
      I2 => L(6),
      O => SDAout_i_7_n_0
    );
SDAout_i_8: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFD5FFFFFFFFFF"
    )
        port map (
      I0 => L(8),
      I1 => L(6),
      I2 => L(7),
      I3 => \i_I2C/cntBits\,
      I4 => L(5),
      I5 => L(4),
      O => SDAout_i_8_n_0
    );
SDAout_i_9: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFEFF"
    )
        port map (
      I0 => SDAout_i_11_n_0,
      I1 => L(9),
      I2 => L(6),
      I3 => \i_I2C/p_0_in\,
      I4 => L(7),
      I5 => L(5),
      O => SDAout_i_9_n_0
    );
\addrROM[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      O => plusOp(0)
    );
\addrROM[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(1),
      I1 => \i_Master/addrROM_reg\(0),
      O => plusOp(1)
    );
\addrROM[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(2),
      I1 => \i_Master/addrROM_reg\(0),
      I2 => \i_Master/addrROM_reg\(1),
      O => \addrROM[2]_i_1_n_0\
    );
\addrROM[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      O => plusOp(3)
    );
\addrROM[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \i_Master/addrROM_reg__0\(4),
      I1 => \i_Master/addrROM_reg\(0),
      I2 => \i_Master/addrROM_reg\(1),
      I3 => \i_Master/addrROM_reg\(2),
      I4 => \i_Master/addrROM_reg__0\(3),
      O => plusOp(4)
    );
\addrROM[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAAAEFFAEAE"
    )
        port map (
      I0 => \addrROM[5]_i_4_n_0\,
      I1 => \addrROM[5]_i_5_n_0\,
      I2 => \addrROM[5]_i_6_n_0\,
      I3 => \addrROM[5]_i_7_n_0\,
      I4 => RAM_reg_0_15_0_7_i_25_n_0,
      I5 => I2C_FIFO_Full,
      O => \addrROM[5]_i_1_n_0\
    );
\addrROM[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"04100000"
    )
        port map (
      I0 => I2C_FIFO_Full,
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      O => \addrROM[5]_i_2_n_0\
    );
\addrROM[5]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \i_Master/addrROM_reg__0__0\(5),
      I1 => \i_Master/addrROM_reg\(0),
      I2 => \i_Master/addrROM_reg\(1),
      I3 => \i_Master/addrROM_reg\(2),
      I4 => \i_Master/addrROM_reg__0\(4),
      I5 => \i_Master/addrROM_reg__0\(3),
      O => plusOp(5)
    );
\addrROM[5]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"04"
    )
        port map (
      I0 => \i_Master/state\(2),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(0),
      O => \addrROM[5]_i_4_n_0\
    );
\addrROM[5]_i_5\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"4000"
    )
        port map (
      I0 => \i_Master/state\(2),
      I1 => \i_Master/state\(1),
      I2 => \i_Master/state\(3),
      I3 => \i_Master/state\(0),
      O => \addrROM[5]_i_5_n_0\
    );
\addrROM[5]_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFEFFF"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg__0__0\(5),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg\(1),
      I4 => \i_Master/addrROM_reg__0\(4),
      I5 => \i_Master/addrROM_reg__0\(3),
      O => \addrROM[5]_i_6_n_0\
    );
\addrROM[5]_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFEFFFFFFFFFFFF"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(2),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg__0__0\(5),
      I3 => \i_Master/addrROM_reg\(0),
      I4 => \i_Master/addrROM_reg__0\(3),
      I5 => \i_Master/addrROM_reg__0\(4),
      O => \addrROM[5]_i_7_n_0\
    );
\addrRd[0]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \addrRd_rep[3]_i_1_n_0\,
      O => \addrRd[0]_i_1_n_0\
    );
\addrRd[1]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"78"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \addrRd_rep[3]_i_1_n_0\,
      I2 => \i_I2C/i_FIFO/addrRd_reg\(1),
      O => \addrRd[1]_i_1_n_0\
    );
\addrRd[2]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7F80"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I2 => \addrRd_rep[3]_i_1_n_0\,
      I3 => \i_I2C/i_FIFO/addrRd_reg\(2),
      O => \addrRd[2]_i_1_n_0\
    );
\addrRd[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"7FFF8000"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I3 => \addrRd_rep[3]_i_1_n_0\,
      I4 => \i_I2C/i_FIFO/addrRd_reg\(3),
      O => \addrRd[3]_i_1_n_0\
    );
\addrRd_rep[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => \i_I2C/i_FIFO/plusOp0_in\(0)
    );
\addrRd_rep[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      O => \i_I2C/i_FIFO/plusOp0_in\(1)
    );
\addrRd_rep[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => \i_I2C/i_FIFO/plusOp0_in\(2)
    );
\addrRd_rep[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000400"
    )
        port map (
      I0 => \i_I2C/cntSCL\,
      I1 => \i_I2C/sclEnd\,
      I2 => I2C_FIFO_Empty,
      I3 => \i_I2C/p_0_in\,
      I4 => \addrRd_rep[3]_i_3_n_0\,
      O => \addrRd_rep[3]_i_1_n_0\
    );
\addrRd_rep[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => \i_I2C/i_FIFO/addrRd_reg\(3),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(2),
      O => \i_I2C/i_FIFO/plusOp0_in\(3)
    );
\addrRd_rep[3]_i_3\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFEF"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[0]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[3]\,
      I3 => \i_I2C/cntBits_reg_n_0_[2]\,
      O => \addrRd_rep[3]_i_3_n_0\
    );
\addrWr[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => addrWr_reg(0),
      O => \addrWr[0]_i_1_n_0\
    );
\addrWr[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => addrWr_reg(1),
      I1 => addrWr_reg(0),
      O => \addrWr[1]_i_1_n_0\
    );
\addrWr[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => addrWr_reg(2),
      I1 => addrWr_reg(0),
      I2 => addrWr_reg(1),
      O => \addrWr[2]_i_1_n_0\
    );
\addrWr[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => addrWr_reg(3),
      I1 => addrWr_reg(1),
      I2 => addrWr_reg(0),
      I3 => addrWr_reg(2),
      O => \addrWr[3]_i_1_n_0\
    );
\cnt20b[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0042"
    )
        port map (
      I0 => \i_Master/state\(2),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(0),
      I3 => \i_Master/state\(1),
      O => \i_Master/cnt20b0\
    );
\cnt20b[0]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"04000404"
    )
        port map (
      I0 => \i_Master/state\(3),
      I1 => \i_Master/state\(1),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(0),
      I4 => I2C_FIFO_Full,
      O => \i_Master/cnt20b00_out\
    );
\cnt20b[0]_i_4\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_Master/cnt20b_reg_n_0_[0]\,
      O => \cnt20b[0]_i_4_n_0\
    );
\cnt20b_reg[0]_i_3\: unisim.vcomponents.CARRY8
     port map (
      CI => '0',
      CI_TOP => '0',
      CO(7) => \cnt20b_reg[0]_i_3_n_0\,
      CO(6) => \cnt20b_reg[0]_i_3_n_1\,
      CO(5) => \cnt20b_reg[0]_i_3_n_2\,
      CO(4) => \cnt20b_reg[0]_i_3_n_3\,
      CO(3) => \cnt20b_reg[0]_i_3_n_4\,
      CO(2) => \cnt20b_reg[0]_i_3_n_5\,
      CO(1) => \cnt20b_reg[0]_i_3_n_6\,
      CO(0) => \cnt20b_reg[0]_i_3_n_7\,
      DI(7 downto 0) => B"00000001",
      O(7) => \cnt20b_reg[0]_i_3_n_8\,
      O(6) => \cnt20b_reg[0]_i_3_n_9\,
      O(5) => \cnt20b_reg[0]_i_3_n_10\,
      O(4) => \cnt20b_reg[0]_i_3_n_11\,
      O(3) => \cnt20b_reg[0]_i_3_n_12\,
      O(2) => \cnt20b_reg[0]_i_3_n_13\,
      O(1) => \cnt20b_reg[0]_i_3_n_14\,
      O(0) => \cnt20b_reg[0]_i_3_n_15\,
      S(7) => \i_Master/p_0_in\(0),
      S(6) => \i_Master/cnt20b_reg_n_0_[6]\,
      S(5) => \i_Master/cnt20b_reg_n_0_[5]\,
      S(4) => \i_Master/cnt20b_reg_n_0_[4]\,
      S(3) => \i_Master/cnt20b_reg_n_0_[3]\,
      S(2) => \i_Master/cnt20b_reg_n_0_[2]\,
      S(1) => \i_Master/cnt20b_reg_n_0_[1]\,
      S(0) => \cnt20b[0]_i_4_n_0\
    );
\cnt20b_reg[16]_i_1\: unisim.vcomponents.CARRY8
     port map (
      CI => \cnt20b_reg[8]_i_1_n_0\,
      CI_TOP => '0',
      CO(7 downto 3) => \NLW_cnt20b_reg[16]_i_1_CO_UNCONNECTED\(7 downto 3),
      CO(2) => \cnt20b_reg[16]_i_1_n_5\,
      CO(1) => \cnt20b_reg[16]_i_1_n_6\,
      CO(0) => \cnt20b_reg[16]_i_1_n_7\,
      DI(7 downto 0) => B"00000000",
      O(7 downto 4) => \NLW_cnt20b_reg[16]_i_1_O_UNCONNECTED\(7 downto 4),
      O(3) => \cnt20b_reg[16]_i_1_n_12\,
      O(2) => \cnt20b_reg[16]_i_1_n_13\,
      O(1) => \cnt20b_reg[16]_i_1_n_14\,
      O(0) => \cnt20b_reg[16]_i_1_n_15\,
      S(7 downto 4) => B"0000",
      S(3 downto 0) => \i_Master/cnt20b_reg\(19 downto 16)
    );
\cnt20b_reg[8]_i_1\: unisim.vcomponents.CARRY8
     port map (
      CI => \cnt20b_reg[0]_i_3_n_0\,
      CI_TOP => '0',
      CO(7) => \cnt20b_reg[8]_i_1_n_0\,
      CO(6) => \cnt20b_reg[8]_i_1_n_1\,
      CO(5) => \cnt20b_reg[8]_i_1_n_2\,
      CO(4) => \cnt20b_reg[8]_i_1_n_3\,
      CO(3) => \cnt20b_reg[8]_i_1_n_4\,
      CO(2) => \cnt20b_reg[8]_i_1_n_5\,
      CO(1) => \cnt20b_reg[8]_i_1_n_6\,
      CO(0) => \cnt20b_reg[8]_i_1_n_7\,
      DI(7 downto 0) => B"00000000",
      O(7) => \cnt20b_reg[8]_i_1_n_8\,
      O(6) => \cnt20b_reg[8]_i_1_n_9\,
      O(5) => \cnt20b_reg[8]_i_1_n_10\,
      O(4) => \cnt20b_reg[8]_i_1_n_11\,
      O(3) => \cnt20b_reg[8]_i_1_n_12\,
      O(2) => \cnt20b_reg[8]_i_1_n_13\,
      O(1) => \cnt20b_reg[8]_i_1_n_14\,
      O(0) => \cnt20b_reg[8]_i_1_n_15\,
      S(7 downto 2) => \i_Master/cnt20b_reg\(15 downto 10),
      S(1 downto 0) => \i_Master/p_0_in\(2 downto 1)
    );
\cntBits[0]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"00FB"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[1]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      O => \cntBits[0]_i_1_n_0\
    );
\cntBits[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[1]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      O => \cntBits[1]_i_1_n_0\
    );
\cntBits[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      I2 => \i_I2C/cntBits_reg_n_0_[1]\,
      O => \cntBits[2]_i_1_n_0\
    );
\cntBits[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000010000"
    )
        port map (
      I0 => \cntBits[3]_i_3_n_0\,
      I1 => \cntBits[3]_i_4_n_0\,
      I2 => \cntSCL[6]_i_2_n_0\,
      I3 => L(3),
      I4 => L(8),
      I5 => \cntBits[3]_i_5_n_0\,
      O => \i_I2C/sclEnd\
    );
\cntBits[3]_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"7E80"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[0]\,
      I2 => \i_I2C/cntBits_reg_n_0_[1]\,
      I3 => \i_I2C/cntBits_reg_n_0_[3]\,
      O => \cntBits[3]_i_2_n_0\
    );
\cntBits[3]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEFEFEFEFFFFFEFF"
    )
        port map (
      I0 => L(13),
      I1 => L(14),
      I2 => L(12),
      I3 => L(9),
      I4 => L(10),
      I5 => L(11),
      O => \cntBits[3]_i_3_n_0\
    );
\cntBits[3]_i_4\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EEFEFFFF"
    )
        port map (
      I0 => L(10),
      I1 => L(11),
      I2 => L(8),
      I3 => L(6),
      I4 => L(7),
      O => \cntBits[3]_i_4_n_0\
    );
\cntBits[3]_i_5\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"B"
    )
        port map (
      I0 => L(4),
      I1 => L(5),
      O => \cntBits[3]_i_5_n_0\
    );
\cntHeartbeat[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      O => \plusOp__1\(0)
    );
\cntHeartbeat[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg_n_0_[1]\,
      I1 => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      O => \plusOp__1\(1)
    );
\cntHeartbeat[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg_n_0_[2]\,
      I1 => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      I2 => \i_Master/cntHeartbeat_reg_n_0_[1]\,
      O => \plusOp__1\(2)
    );
\cntHeartbeat[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg\(3),
      I1 => \i_Master/cntHeartbeat_reg_n_0_[1]\,
      I2 => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      I3 => \i_Master/cntHeartbeat_reg_n_0_[2]\,
      O => \plusOp__1\(3)
    );
\cntHeartbeat[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg_n_0_[4]\,
      I1 => \i_Master/cntHeartbeat_reg_n_0_[2]\,
      I2 => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      I3 => \i_Master/cntHeartbeat_reg_n_0_[1]\,
      I4 => \i_Master/cntHeartbeat_reg\(3),
      O => \plusOp__1\(4)
    );
\cntHeartbeat[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg\(5),
      I1 => \i_Master/cntHeartbeat_reg\(3),
      I2 => \i_Master/cntHeartbeat_reg_n_0_[1]\,
      I3 => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      I4 => \i_Master/cntHeartbeat_reg_n_0_[2]\,
      I5 => \i_Master/cntHeartbeat_reg_n_0_[4]\,
      O => \plusOp__1\(5)
    );
\cntHeartbeat[6]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg\(6),
      I1 => \cntHeartbeat[6]_i_2_n_0\,
      I2 => \i_Master/cntHeartbeat_reg\(5),
      O => \plusOp__1\(6)
    );
\cntHeartbeat[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => \i_Master/cntHeartbeat_reg_n_0_[4]\,
      I1 => \i_Master/cntHeartbeat_reg_n_0_[2]\,
      I2 => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      I3 => \i_Master/cntHeartbeat_reg_n_0_[1]\,
      I4 => \i_Master/cntHeartbeat_reg\(3),
      O => \cntHeartbeat[6]_i_2_n_0\
    );
\cntSCL[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => L(0),
      O => \i_I2C/cntSCL__0\(0)
    );
\cntSCL[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"A6AAAAAAAAAAAAAA"
    )
        port map (
      I0 => L(10),
      I1 => L(8),
      I2 => \cntSCL[10]_i_2_n_0\,
      I3 => L(7),
      I4 => L(6),
      I5 => L(9),
      O => \i_I2C/cntSCL__0\(10)
    );
\cntSCL[10]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"7FFFFFFFFFFFFFFF"
    )
        port map (
      I0 => L(2),
      I1 => L(0),
      I2 => L(1),
      I3 => L(5),
      I4 => L(3),
      I5 => L(4),
      O => \cntSCL[10]_i_2_n_0\
    );
\cntSCL[11]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A6AAAAAA"
    )
        port map (
      I0 => L(11),
      I1 => L(8),
      I2 => \cntSCL[12]_i_2_n_0\,
      I3 => L(9),
      I4 => L(10),
      O => \i_I2C/cntSCL__0\(11)
    );
\cntSCL[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AA6AAAAAAAAAAAAA"
    )
        port map (
      I0 => L(12),
      I1 => L(10),
      I2 => L(9),
      I3 => \cntSCL[12]_i_2_n_0\,
      I4 => L(8),
      I5 => L(11),
      O => \i_I2C/cntSCL__0\(12)
    );
\cntSCL[12]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF7FFFFFFFFFFFFF"
    )
        port map (
      I0 => L(4),
      I1 => L(3),
      I2 => L(5),
      I3 => \cntSCL[6]_i_2_n_0\,
      I4 => L(7),
      I5 => L(6),
      O => \cntSCL[12]_i_2_n_0\
    );
\cntSCL[13]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => L(13),
      I1 => L(11),
      I2 => \cntSCL[14]_i_2_n_0\,
      I3 => L(12),
      O => \i_I2C/cntSCL__0\(13)
    );
\cntSCL[14]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => L(14),
      I1 => L(12),
      I2 => \cntSCL[14]_i_2_n_0\,
      I3 => L(11),
      I4 => L(13),
      O => \i_I2C/cntSCL__0\(14)
    );
\cntSCL[14]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000800000000000"
    )
        port map (
      I0 => L(10),
      I1 => L(9),
      I2 => L(6),
      I3 => L(7),
      I4 => \cntSCL[10]_i_2_n_0\,
      I5 => L(8),
      O => \cntSCL[14]_i_2_n_0\
    );
\cntSCL[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => L(0),
      I1 => L(1),
      O => \i_I2C/cntSCL__0\(1)
    );
\cntSCL[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"1FFFF111"
    )
        port map (
      I0 => \cntSCL[9]_i_2_n_0\,
      I1 => rSCLin,
      I2 => L(0),
      I3 => L(1),
      I4 => L(2),
      O => \i_I2C/cntSCL__0\(2)
    );
\cntSCL[3]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00AAC3AA"
    )
        port map (
      I0 => rSCLin,
      I1 => L(3),
      I2 => \cntSCL[6]_i_2_n_0\,
      I3 => \cntSCL[9]_i_2_n_0\,
      I4 => \i_I2C/sclEnd\,
      O => \i_I2C/cntSCL__0\(3)
    );
\cntSCL[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6CCCCCCC"
    )
        port map (
      I0 => L(3),
      I1 => L(4),
      I2 => L(1),
      I3 => L(0),
      I4 => L(2),
      O => \i_I2C/cntSCL__0\(4)
    );
\cntSCL[5]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00553C55"
    )
        port map (
      I0 => rSCLin,
      I1 => L(5),
      I2 => \cntSCL[5]_i_2_n_0\,
      I3 => \cntSCL[9]_i_2_n_0\,
      I4 => \i_I2C/sclEnd\,
      O => \i_I2C/cntSCL__0\(5)
    );
\cntSCL[5]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"80000000"
    )
        port map (
      I0 => L(2),
      I1 => L(0),
      I2 => L(1),
      I3 => L(4),
      I4 => L(3),
      O => \cntSCL[5]_i_2_n_0\
    );
\cntSCL[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"4555555510000000"
    )
        port map (
      I0 => \i_I2C/sclEnd\,
      I1 => \cntSCL[6]_i_2_n_0\,
      I2 => L(5),
      I3 => L(3),
      I4 => L(4),
      I5 => L(6),
      O => \i_I2C/cntSCL__0\(6)
    );
\cntSCL[6]_i_2\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => L(1),
      I1 => L(0),
      I2 => L(2),
      O => \cntSCL[6]_i_2_n_0\
    );
\cntSCL[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00005555F30C5555"
    )
        port map (
      I0 => rSCLin,
      I1 => L(6),
      I2 => \cntSCL[10]_i_2_n_0\,
      I3 => L(7),
      I4 => \cntSCL[9]_i_2_n_0\,
      I5 => \i_I2C/sclEnd\,
      O => \i_I2C/cntSCL__0\(7)
    );
\cntSCL[8]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"090009FF"
    )
        port map (
      I0 => L(8),
      I1 => \cntSCL[12]_i_2_n_0\,
      I2 => \i_I2C/sclEnd\,
      I3 => \cntSCL[9]_i_2_n_0\,
      I4 => rSCLin,
      O => \i_I2C/cntSCL__0\(8)
    );
\cntSCL[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"009AFFFF009A0000"
    )
        port map (
      I0 => L(9),
      I1 => \cntSCL[12]_i_2_n_0\,
      I2 => L(8),
      I3 => \i_I2C/sclEnd\,
      I4 => \cntSCL[9]_i_2_n_0\,
      I5 => rSCLin,
      O => \i_I2C/cntSCL__0\(9)
    );
\cntSCL[9]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFDFFFFFFFFFFFF"
    )
        port map (
      I0 => L(9),
      I1 => L(13),
      I2 => L(14),
      I3 => L(12),
      I4 => L(6),
      I5 => \cntSCL[9]_i_3_n_0\,
      O => \cntSCL[9]_i_2_n_0\
    );
\cntSCL[9]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000001000000"
    )
        port map (
      I0 => \cntSCL[9]_i_4_n_0\,
      I1 => L(5),
      I2 => L(7),
      I3 => L(4),
      I4 => L(3),
      I5 => SDAout_i_10_n_0,
      O => \cntSCL[9]_i_3_n_0\
    );
\cntSCL[9]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"FE"
    )
        port map (
      I0 => L(1),
      I1 => L(2),
      I2 => L(0),
      O => \cntSCL[9]_i_4_n_0\
    );
\cntX[0]_i_1\: unisim.vcomponents.LUT1
    generic map(
      INIT => X"1"
    )
        port map (
      I0 => \i_Master/cntX_reg\(0),
      O => \plusOp__0\(0)
    );
\cntX[1]_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"6"
    )
        port map (
      I0 => \i_Master/cntX_reg\(0),
      I1 => \i_Master/cntX_reg\(1),
      O => \plusOp__0\(1)
    );
\cntX[2]_i_1\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"6A"
    )
        port map (
      I0 => \i_Master/cntX_reg\(2),
      I1 => \i_Master/cntX_reg\(1),
      I2 => \i_Master/cntX_reg\(0),
      O => \cntX[2]_i_1_n_0\
    );
\cntX[3]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6AAA"
    )
        port map (
      I0 => \i_Master/cntX_reg__0\(3),
      I1 => \i_Master/cntX_reg\(1),
      I2 => \i_Master/cntX_reg\(0),
      I3 => \i_Master/cntX_reg\(2),
      O => \plusOp__0\(3)
    );
\cntX[4]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"6AAAAAAA"
    )
        port map (
      I0 => \i_Master/cntX_reg__0\(4),
      I1 => \i_Master/cntX_reg\(2),
      I2 => \i_Master/cntX_reg\(0),
      I3 => \i_Master/cntX_reg\(1),
      I4 => \i_Master/cntX_reg__0\(3),
      O => \plusOp__0\(4)
    );
\cntX[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6AAAAAAAAAAAAAAA"
    )
        port map (
      I0 => \i_Master/cntX_reg__0\(5),
      I1 => \i_Master/cntX_reg__0\(3),
      I2 => \i_Master/cntX_reg\(1),
      I3 => \i_Master/cntX_reg\(0),
      I4 => \i_Master/cntX_reg\(2),
      I5 => \i_Master/cntX_reg__0\(4),
      O => \plusOp__0\(5)
    );
\cntX[6]_i_1\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"0004"
    )
        port map (
      I0 => \i_Master/state\(3),
      I1 => \i_Master/state\(2),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/state\(0),
      O => \i_Master/cntHeartbeat0\
    );
\cntX[6]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00400000"
    )
        port map (
      I0 => I2C_FIFO_Full,
      I1 => \i_Master/state\(1),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(3),
      I4 => \i_Master/state\(0),
      O => \i_Master/cntX0\
    );
\cntX[6]_i_3\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"A6AAAAAA"
    )
        port map (
      I0 => \i_Master/cntX_reg__0\(6),
      I1 => \i_Master/cntX_reg__0\(4),
      I2 => \cntX[6]_i_4_n_0\,
      I3 => \i_Master/cntX_reg__0\(3),
      I4 => \i_Master/cntX_reg__0\(5),
      O => \plusOp__0\(6)
    );
\cntX[6]_i_4\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"7F"
    )
        port map (
      I0 => \i_Master/cntX_reg\(1),
      I1 => \i_Master/cntX_reg\(0),
      I2 => \i_Master/cntX_reg\(2),
      O => \cntX[6]_i_4_n_0\
    );
g0_b0: unisim.vcomponents.LUT5
    generic map(
      INIT => X"012C444C"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b0_n_0
    );
\g0_b0__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E7B9CEFB3E87388E"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => \g0_b0__0_n_0\
    );
\g0_b0__0_i_1\: unisim.vcomponents.LUT2
    generic map(
      INIT => X"9"
    )
        port map (
      I0 => \i_Master/cntX_reg\(0),
      I1 => \i_Master/regDI_reg_n_0_[60]\,
      O => \g0_b0__0_i_1_n_0\
    );
\g0_b0__0_i_2\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1EE1"
    )
        port map (
      I0 => \i_Master/regDI_reg_n_0_[60]\,
      I1 => \i_Master/cntX_reg\(0),
      I2 => \i_Master/regDI_reg_n_0_[61]\,
      I3 => \i_Master/cntX_reg\(1),
      O => sel(1)
    );
\g0_b0__0_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"6969999996666669"
    )
        port map (
      I0 => \i_Master/cntX_reg\(2),
      I1 => \i_Master/regDI_reg_n_0_[62]\,
      I2 => \i_Master/regDI_reg_n_0_[61]\,
      I3 => \i_Master/cntX_reg\(0),
      I4 => \i_Master/cntX_reg\(1),
      I5 => \i_Master/regDI_reg_n_0_[60]\,
      O => sel(2)
    );
\g0_b0__0_i_4\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"6996"
    )
        port map (
      I0 => \g0_b0__0_i_7_n_0\,
      I1 => \g0_b0__0_i_8_n_0\,
      I2 => \i_Master/regDI_reg_n_0_[61]\,
      I3 => \i_Master/regDI_reg_n_0_[63]\,
      O => sel(3)
    );
\g0_b0__0_i_5\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"22C0C0DDDD3F3F22"
    )
        port map (
      I0 => \g0_b0__0_i_9_n_0\,
      I1 => \g0_b0__0_i_8_n_0\,
      I2 => \g0_b0__0_i_7_n_0\,
      I3 => \i_Master/regDI_reg_n_0_[61]\,
      I4 => \i_Master/regDI_reg_n_0_[63]\,
      I5 => \i_Master/regDI_reg_n_0_[62]\,
      O => sel(4)
    );
\g0_b0__0_i_6\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00C03F22FFFF0000"
    )
        port map (
      I0 => \g0_b0__0_i_9_n_0\,
      I1 => \g0_b0__0_i_8_n_0\,
      I2 => \g0_b0__0_i_7_n_0\,
      I3 => \i_Master/regDI_reg_n_0_[61]\,
      I4 => \i_Master/regDI_reg_n_0_[63]\,
      I5 => \i_Master/regDI_reg_n_0_[62]\,
      O => sel(5)
    );
\g0_b0__0_i_7\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"099F0F069F9F9F0F"
    )
        port map (
      I0 => \i_Master/regDI_reg_n_0_[62]\,
      I1 => \i_Master/cntX_reg\(2),
      I2 => \i_Master/regDI_reg_n_0_[60]\,
      I3 => \i_Master/cntX_reg\(1),
      I4 => \i_Master/cntX_reg\(0),
      I5 => \i_Master/regDI_reg_n_0_[61]\,
      O => \g0_b0__0_i_7_n_0\
    );
\g0_b0__0_i_8\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"1EFF"
    )
        port map (
      I0 => \i_Master/cntX_reg\(0),
      I1 => \i_Master/cntX_reg\(1),
      I2 => \i_Master/cntX_reg\(2),
      I3 => \i_Master/regDI_reg_n_0_[62]\,
      O => \g0_b0__0_i_8_n_0\
    );
\g0_b0__0_i_9\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"80A2"
    )
        port map (
      I0 => \i_Master/regDI_reg_n_0_[60]\,
      I1 => \i_Master/cntX_reg\(1),
      I2 => \i_Master/regDI_reg_n_0_[61]\,
      I3 => \i_Master/cntX_reg\(0),
      O => \g0_b0__0_i_9_n_0\
    );
g0_b1: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0164230C"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b1_n_0
    );
\g0_b1__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"18C6318882C8C4D1"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => \g0_b1__0_n_0\
    );
g0_b2: unisim.vcomponents.LUT5
    generic map(
      INIT => X"01247004"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b2_n_0
    );
\g0_b2__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"18C631805EA84099"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => \g0_b2__0_n_0\
    );
g0_b3: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00240186"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b3_n_0
    );
\g0_b3__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"17C7CE43E0962095"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => \g0_b3__0_n_0\
    );
g0_b4: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0020430C"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b4_n_0
    );
\g0_b4__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"18FE112461F81093"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => \g0_b4__0_n_0\
    );
g0_b5: unisim.vcomponents.LUT5
    generic map(
      INIT => X"006D3046"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b5_n_0
    );
\g0_b5__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"18C5112462888891"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => \g0_b5__0_n_0\
    );
g0_b6: unisim.vcomponents.LUT5
    generic map(
      INIT => X"002049A8"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b6_n_0
    );
\g0_b6__0\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"E7C4CE239C877DCE"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => \g0_b6__0_n_0\
    );
g0_b7: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0004FDCA"
    )
        port map (
      I0 => \i_Master/addrROM_reg\(0),
      I1 => \i_Master/addrROM_reg\(1),
      I2 => \i_Master/addrROM_reg\(2),
      I3 => \i_Master/addrROM_reg__0\(3),
      I4 => \i_Master/addrROM_reg__0\(4),
      O => g0_b7_n_0
    );
g1_b0: unisim.vcomponents.LUT6
    generic map(
      INIT => X"000000000000FFCE"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => g1_b0_n_0
    );
g1_b1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000853"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => g1_b1_n_0
    );
g1_b2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000862"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => g1_b2_n_0
    );
g1_b3: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000007BE2"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => g1_b3_n_0
    );
g1_b6: unisim.vcomponents.LUT6
    generic map(
      INIT => X"0000000000000FCE"
    )
        port map (
      I0 => \g0_b0__0_i_1_n_0\,
      I1 => sel(1),
      I2 => sel(2),
      I3 => sel(3),
      I4 => sel(4),
      I5 => sel(5),
      O => g1_b6_n_0
    );
iEmpty_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AEAAAAAE"
    )
        port map (
      I0 => I2C_FIFO_Empty,
      I1 => \addrRd_rep[3]_i_1_n_0\,
      I2 => iEmpty_i_2_n_0,
      I3 => addrWr_reg(3),
      I4 => \i_I2C/i_FIFO/plusOp0_in\(3),
      I5 => RAM_reg_0_15_0_7_i_1_n_0,
      O => iEmpty_i_1_n_0
    );
iEmpty_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FEDF7FBFEFFDF7FB"
    )
        port map (
      I0 => addrWr_reg(1),
      I1 => addrWr_reg(0),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I3 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I4 => \i_I2C/i_FIFO/addrRd_reg\(0),
      I5 => addrWr_reg(2),
      O => iEmpty_i_2_n_0
    );
iFull_i_1: unisim.vcomponents.LUT6
    generic map(
      INIT => X"00000000AAAAEAAE"
    )
        port map (
      I0 => I2C_FIFO_Full,
      I1 => RAM_reg_0_15_0_7_i_1_n_0,
      I2 => \i_I2C/i_FIFO/addrRd_reg\(3),
      I3 => \addrWr[3]_i_1_n_0\,
      I4 => iFull_i_2_n_0,
      I5 => \addrRd_rep[3]_i_1_n_0\,
      O => iFull_i_1_n_0
    );
iFull_i_2: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FF6FFFF6F9FF6FFF"
    )
        port map (
      I0 => addrWr_reg(2),
      I1 => \i_I2C/i_FIFO/addrRd_reg\(2),
      I2 => \i_I2C/i_FIFO/addrRd_reg\(1),
      I3 => addrWr_reg(0),
      I4 => addrWr_reg(1),
      I5 => \i_I2C/i_FIFO/addrRd_reg\(0),
      O => iFull_i_2_n_0
    );
\i_I2C/FSM_onehot_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[0]_i_1_n_0\,
      Q => \i_I2C/FSM_onehot_state_reg_n_0_[0]\,
      R => '0'
    );
\i_I2C/FSM_onehot_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[1]_i_1_n_0\,
      Q => \i_I2C/cntSCL\,
      R => '0'
    );
\i_I2C/FSM_onehot_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \FSM_onehot_state[3]_i_1_n_0\,
      Q => \i_I2C/p_0_in\,
      R => '0'
    );
\i_I2C/FSM_onehot_state_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => \i_I2C/cntSCL\,
      Q => \i_I2C/cntBits\,
      R => '0'
    );
\i_I2C/FSM_onehot_state_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_onehot_state[5]_i_1_n_0\,
      D => '0',
      Q => \i_I2C/FSM_onehot_state_reg_n_0_[5]\,
      R => '0'
    );
\i_I2C/IOBUF_SCL\: unisim.vcomponents.IOBUF
    generic map(
      IOSTANDARD => "DEFAULT"
    )
        port map (
      I => '0',
      IO => OLED_SCL,
      O => \i_I2C/SCLin\,
      T => \i_I2C/SCLout_reg_n_0\
    );
\i_I2C/IOBUF_SDA\: unisim.vcomponents.IOBUF
    generic map(
      IOSTANDARD => "DEFAULT"
    )
        port map (
      I => '0',
      IO => OLED_SDA,
      O => \i_I2C/SDAin\,
      T => \i_I2C/T\
    );
\i_I2C/NACK_reg\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => '1',
      D => NACK_i_1_n_0,
      Q => \^i2c_nack\,
      R => '0'
    );
\i_I2C/SCLout_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => SCLout_i_1_n_0,
      Q => \i_I2C/SCLout_reg_n_0\,
      R => '0'
    );
\i_I2C/SDAout_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => SDAout_i_1_n_0,
      Q => \i_I2C/T\,
      R => '0'
    );
\i_I2C/cntBits_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[0]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[0]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[1]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[1]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[2]_i_1_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[2]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntBits_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_I2C/sclEnd\,
      D => \cntBits[3]_i_2_n_0\,
      Q => \i_I2C/cntBits_reg_n_0_[3]\,
      R => \i_I2C/cntBits\
    );
\i_I2C/cntSCL_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(0),
      Q => L(0),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(10),
      Q => L(10),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(11),
      Q => L(11),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(12),
      Q => L(12),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(13),
      Q => L(13),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(14),
      Q => L(14),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(1),
      Q => L(1),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(2),
      Q => L(2),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(3),
      Q => L(3),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(4),
      Q => L(4),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(5),
      Q => L(5),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(6),
      Q => L(6),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(7),
      Q => L(7),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(8),
      Q => L(8),
      R => \i_I2C/cntSCL\
    );
\i_I2C/cntSCL_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/cntSCL__0\(9),
      Q => L(9),
      R => \i_I2C/cntSCL\
    );
\i_I2C/i_FIFO/RAM_reg_0_15_0_7\: unisim.vcomponents.RAM32M16
     port map (
      ADDRA(4) => '0',
      ADDRA(3 downto 0) => \i_I2C/i_FIFO/addrRd\(3 downto 0),
      ADDRB(4) => '0',
      ADDRB(3 downto 0) => \i_I2C/i_FIFO/addrRd\(3 downto 0),
      ADDRC(4) => '0',
      ADDRC(3 downto 0) => \i_I2C/i_FIFO/addrRd\(3 downto 0),
      ADDRD(4) => '0',
      ADDRD(3 downto 0) => \i_I2C/i_FIFO/addrRd\(3 downto 0),
      ADDRE(4) => '0',
      ADDRE(3 downto 0) => \i_I2C/i_FIFO/addrRd\(3 downto 0),
      ADDRF(4) => '0',
      ADDRF(3 downto 0) => \i_I2C/i_FIFO/addrRd\(3 downto 0),
      ADDRG(4) => '0',
      ADDRG(3 downto 0) => \i_I2C/i_FIFO/addrRd\(3 downto 0),
      ADDRH(4) => '0',
      ADDRH(3 downto 0) => addrWr_reg(3 downto 0),
      DIA(1 downto 0) => \i_Master/p_0_out\(1 downto 0),
      DIB(1 downto 0) => \i_Master/p_0_out\(3 downto 2),
      DIC(1 downto 0) => \i_Master/p_0_out\(5 downto 4),
      DID(1 downto 0) => \i_Master/p_0_out\(7 downto 6),
      DIE(1 downto 0) => B"00",
      DIF(1 downto 0) => B"00",
      DIG(1 downto 0) => B"00",
      DIH(1 downto 0) => B"00",
      DOA(1 downto 0) => DO(1 downto 0),
      DOB(1 downto 0) => DO(3 downto 2),
      DOC(1 downto 0) => DO(5 downto 4),
      DOD(1 downto 0) => DO(7 downto 6),
      DOE(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOE_UNCONNECTED\(1 downto 0),
      DOF(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOF_UNCONNECTED\(1 downto 0),
      DOG(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOG_UNCONNECTED\(1 downto 0),
      DOH(1 downto 0) => \NLW_i_I2C/i_FIFO/RAM_reg_0_15_0_7_DOH_UNCONNECTED\(1 downto 0),
      WCLK => Clk_100MHz,
      WE => RAM_reg_0_15_0_7_i_1_n_0
    );
\i_I2C/i_FIFO/addrRd_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \addrRd[0]_i_1_n_0\,
      Q => \i_I2C/i_FIFO/addrRd_reg\(0),
      R => '0'
    );
\i_I2C/i_FIFO/addrRd_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \addrRd[1]_i_1_n_0\,
      Q => \i_I2C/i_FIFO/addrRd_reg\(1),
      R => '0'
    );
\i_I2C/i_FIFO/addrRd_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \addrRd[2]_i_1_n_0\,
      Q => \i_I2C/i_FIFO/addrRd_reg\(2),
      R => '0'
    );
\i_I2C/i_FIFO/addrRd_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \addrRd[3]_i_1_n_0\,
      Q => \i_I2C/i_FIFO/addrRd_reg\(3),
      R => '0'
    );
\i_I2C/i_FIFO/addrRd_reg_rep[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrRd_rep[3]_i_1_n_0\,
      D => \i_I2C/i_FIFO/plusOp0_in\(0),
      Q => \i_I2C/i_FIFO/addrRd\(0),
      R => '0'
    );
\i_I2C/i_FIFO/addrRd_reg_rep[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrRd_rep[3]_i_1_n_0\,
      D => \i_I2C/i_FIFO/plusOp0_in\(1),
      Q => \i_I2C/i_FIFO/addrRd\(1),
      R => '0'
    );
\i_I2C/i_FIFO/addrRd_reg_rep[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrRd_rep[3]_i_1_n_0\,
      D => \i_I2C/i_FIFO/plusOp0_in\(2),
      Q => \i_I2C/i_FIFO/addrRd\(2),
      R => '0'
    );
\i_I2C/i_FIFO/addrRd_reg_rep[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrRd_rep[3]_i_1_n_0\,
      D => \i_I2C/i_FIFO/plusOp0_in\(3),
      Q => \i_I2C/i_FIFO/addrRd\(3),
      R => '0'
    );
\i_I2C/i_FIFO/addrWr_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => RAM_reg_0_15_0_7_i_1_n_0,
      D => \addrWr[0]_i_1_n_0\,
      Q => addrWr_reg(0),
      R => '0'
    );
\i_I2C/i_FIFO/addrWr_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => RAM_reg_0_15_0_7_i_1_n_0,
      D => \addrWr[1]_i_1_n_0\,
      Q => addrWr_reg(1),
      R => '0'
    );
\i_I2C/i_FIFO/addrWr_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => RAM_reg_0_15_0_7_i_1_n_0,
      D => \addrWr[2]_i_1_n_0\,
      Q => addrWr_reg(2),
      R => '0'
    );
\i_I2C/i_FIFO/addrWr_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => RAM_reg_0_15_0_7_i_1_n_0,
      D => \addrWr[3]_i_1_n_0\,
      Q => addrWr_reg(3),
      R => '0'
    );
\i_I2C/i_FIFO/iEmpty_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => iEmpty_i_1_n_0,
      Q => I2C_FIFO_Empty,
      R => '0'
    );
\i_I2C/i_FIFO/iFull_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => iFull_i_1_n_0,
      Q => I2C_FIFO_Full,
      R => '0'
    );
\i_I2C/rSCLin_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/SCLin\,
      Q => rSCLin,
      R => '0'
    );
\i_I2C/rSDAin_reg\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => '1',
      D => \i_I2C/SDAin\,
      Q => \i_I2C/rSDAin\,
      R => '0'
    );
\i_I2C/sregOut[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"FFFFFFFD"
    )
        port map (
      I0 => \i_I2C/cntBits_reg_n_0_[3]\,
      I1 => \i_I2C/cntBits_reg_n_0_[1]\,
      I2 => \i_I2C/cntBits_reg_n_0_[0]\,
      I3 => DO(0),
      I4 => \i_I2C/cntBits_reg_n_0_[2]\,
      O => \i_I2C/sregOut[0]_i_1_n_0\
    );
\i_I2C/sregOut[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEAAAAAAA2"
    )
        port map (
      I0 => \i_I2C/sregOut_reg_n_0_[0]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => DO(1),
      O => \i_I2C/sregOut[1]_i_1_n_0\
    );
\i_I2C/sregOut[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEAAAAAAA2"
    )
        port map (
      I0 => \i_I2C/sregOut_reg_n_0_[1]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => DO(2),
      O => \i_I2C/sregOut[2]_i_1_n_0\
    );
\i_I2C/sregOut[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEAAAAAAA2"
    )
        port map (
      I0 => \i_I2C/sregOut_reg_n_0_[2]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => DO(3),
      O => \i_I2C/sregOut[3]_i_1_n_0\
    );
\i_I2C/sregOut[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEAAAAAAA2"
    )
        port map (
      I0 => \i_I2C/sregOut_reg_n_0_[3]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => DO(4),
      O => \i_I2C/sregOut[4]_i_1_n_0\
    );
\i_I2C/sregOut[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEAAAAAAA2"
    )
        port map (
      I0 => \i_I2C/sregOut_reg_n_0_[4]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => DO(5),
      O => \i_I2C/sregOut[5]_i_1_n_0\
    );
\i_I2C/sregOut[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEAAAAAAA2"
    )
        port map (
      I0 => \i_I2C/sregOut_reg_n_0_[5]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => DO(6),
      O => \i_I2C/sregOut[6]_i_1_n_0\
    );
\i_I2C/sregOut[7]_i_3\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"AAAAAAAEAAAAAAA2"
    )
        port map (
      I0 => \i_I2C/sregOut_reg_n_0_[6]\,
      I1 => \i_I2C/cntBits_reg_n_0_[3]\,
      I2 => \i_I2C/cntBits_reg_n_0_[2]\,
      I3 => \i_I2C/cntBits_reg_n_0_[0]\,
      I4 => \i_I2C/cntBits_reg_n_0_[1]\,
      I5 => DO(7),
      O => \i_I2C/sregOut[7]_i_3_n_0\
    );
\i_I2C/sregOut_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[0]_i_1_n_0\,
      Q => \i_I2C/sregOut_reg_n_0_[0]\,
      R => \i_I2C/RdNotWr0\
    );
\i_I2C/sregOut_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[1]_i_1_n_0\,
      Q => \i_I2C/sregOut_reg_n_0_[1]\,
      R => \i_I2C/RdNotWr0\
    );
\i_I2C/sregOut_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[2]_i_1_n_0\,
      Q => \i_I2C/sregOut_reg_n_0_[2]\,
      R => \i_I2C/RdNotWr0\
    );
\i_I2C/sregOut_reg[3]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[3]_i_1_n_0\,
      Q => \i_I2C/sregOut_reg_n_0_[3]\,
      S => \i_I2C/RdNotWr0\
    );
\i_I2C/sregOut_reg[4]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[4]_i_1_n_0\,
      Q => \i_I2C/sregOut_reg_n_0_[4]\,
      S => \i_I2C/RdNotWr0\
    );
\i_I2C/sregOut_reg[5]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[5]_i_1_n_0\,
      Q => \i_I2C/sregOut_reg_n_0_[5]\,
      S => \i_I2C/RdNotWr0\
    );
\i_I2C/sregOut_reg[6]\: unisim.vcomponents.FDSE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[6]_i_1_n_0\,
      Q => \i_I2C/sregOut_reg_n_0_[6]\,
      S => \i_I2C/RdNotWr0\
    );
\i_I2C/sregOut_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \sregOut[7]_i_2_n_0\,
      D => \i_I2C/sregOut[7]_i_3_n_0\,
      Q => sregOut(7),
      R => \i_I2C/RdNotWr0\
    );
\i_Master/FSM_sequential_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[3]_i_1_n_0\,
      D => \FSM_sequential_state[0]_i_1_n_0\,
      Q => \i_Master/state\(0),
      R => '0'
    );
\i_Master/FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[3]_i_1_n_0\,
      D => \i_Master/next_state__0\(1),
      Q => \i_Master/state\(1),
      R => '0'
    );
\i_Master/FSM_sequential_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[3]_i_1_n_0\,
      D => \i_Master/next_state__0\(2),
      Q => \i_Master/state\(2),
      R => '0'
    );
\i_Master/FSM_sequential_state_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => Clk_100MHz,
      CE => \FSM_sequential_state[3]_i_1_n_0\,
      D => \i_Master/next_state__0\(3),
      Q => \i_Master/state\(3),
      R => '0'
    );
\i_Master/addrROM_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrROM[5]_i_2_n_0\,
      D => plusOp(0),
      Q => \i_Master/addrROM_reg\(0),
      R => \addrROM[5]_i_1_n_0\
    );
\i_Master/addrROM_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrROM[5]_i_2_n_0\,
      D => plusOp(1),
      Q => \i_Master/addrROM_reg\(1),
      R => \addrROM[5]_i_1_n_0\
    );
\i_Master/addrROM_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrROM[5]_i_2_n_0\,
      D => \addrROM[2]_i_1_n_0\,
      Q => \i_Master/addrROM_reg\(2),
      R => \addrROM[5]_i_1_n_0\
    );
\i_Master/addrROM_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrROM[5]_i_2_n_0\,
      D => plusOp(3),
      Q => \i_Master/addrROM_reg__0\(3),
      R => \addrROM[5]_i_1_n_0\
    );
\i_Master/addrROM_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrROM[5]_i_2_n_0\,
      D => plusOp(4),
      Q => \i_Master/addrROM_reg__0\(4),
      R => \addrROM[5]_i_1_n_0\
    );
\i_Master/addrROM_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \addrROM[5]_i_2_n_0\,
      D => plusOp(5),
      Q => \i_Master/addrROM_reg__0__0\(5),
      R => \addrROM[5]_i_1_n_0\
    );
\i_Master/cnt20b_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_15\,
      Q => \i_Master/cnt20b_reg_n_0_[0]\,
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[10]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_13\,
      Q => \i_Master/cnt20b_reg\(10),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[11]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_12\,
      Q => \i_Master/cnt20b_reg\(11),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[12]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_11\,
      Q => \i_Master/cnt20b_reg\(12),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[13]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_10\,
      Q => \i_Master/cnt20b_reg\(13),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[14]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_9\,
      Q => \i_Master/cnt20b_reg\(14),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[15]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_8\,
      Q => \i_Master/cnt20b_reg\(15),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[16]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[16]_i_1_n_15\,
      Q => \i_Master/cnt20b_reg\(16),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[17]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[16]_i_1_n_14\,
      Q => \i_Master/cnt20b_reg\(17),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[18]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[16]_i_1_n_13\,
      Q => \i_Master/cnt20b_reg\(18),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[19]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[16]_i_1_n_12\,
      Q => \i_Master/cnt20b_reg\(19),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_14\,
      Q => \i_Master/cnt20b_reg_n_0_[1]\,
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_13\,
      Q => \i_Master/cnt20b_reg_n_0_[2]\,
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_12\,
      Q => \i_Master/cnt20b_reg_n_0_[3]\,
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_11\,
      Q => \i_Master/cnt20b_reg_n_0_[4]\,
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_10\,
      Q => \i_Master/cnt20b_reg_n_0_[5]\,
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_9\,
      Q => \i_Master/cnt20b_reg_n_0_[6]\,
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[7]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[0]_i_3_n_8\,
      Q => \i_Master/p_0_in\(0),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[8]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_15\,
      Q => \i_Master/p_0_in\(1),
      R => \i_Master/cnt20b0\
    );
\i_Master/cnt20b_reg[9]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cnt20b00_out\,
      D => \cnt20b_reg[8]_i_1_n_14\,
      Q => \i_Master/p_0_in\(2),
      R => \i_Master/cnt20b0\
    );
\i_Master/cntHeartbeat_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntHeartbeat0\,
      D => \plusOp__1\(0),
      Q => \i_Master/cntHeartbeat_reg_n_0_[0]\,
      R => '0'
    );
\i_Master/cntHeartbeat_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntHeartbeat0\,
      D => \plusOp__1\(1),
      Q => \i_Master/cntHeartbeat_reg_n_0_[1]\,
      R => '0'
    );
\i_Master/cntHeartbeat_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntHeartbeat0\,
      D => \plusOp__1\(2),
      Q => \i_Master/cntHeartbeat_reg_n_0_[2]\,
      R => '0'
    );
\i_Master/cntHeartbeat_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntHeartbeat0\,
      D => \plusOp__1\(3),
      Q => \i_Master/cntHeartbeat_reg\(3),
      R => '0'
    );
\i_Master/cntHeartbeat_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntHeartbeat0\,
      D => \plusOp__1\(4),
      Q => \i_Master/cntHeartbeat_reg_n_0_[4]\,
      R => '0'
    );
\i_Master/cntHeartbeat_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntHeartbeat0\,
      D => \plusOp__1\(5),
      Q => \i_Master/cntHeartbeat_reg\(5),
      R => '0'
    );
\i_Master/cntHeartbeat_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntHeartbeat0\,
      D => \plusOp__1\(6),
      Q => \i_Master/cntHeartbeat_reg\(6),
      R => '0'
    );
\i_Master/cntX_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntX0\,
      D => \plusOp__0\(0),
      Q => \i_Master/cntX_reg\(0),
      R => \i_Master/cntHeartbeat0\
    );
\i_Master/cntX_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntX0\,
      D => \plusOp__0\(1),
      Q => \i_Master/cntX_reg\(1),
      R => \i_Master/cntHeartbeat0\
    );
\i_Master/cntX_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntX0\,
      D => \cntX[2]_i_1_n_0\,
      Q => \i_Master/cntX_reg\(2),
      R => \i_Master/cntHeartbeat0\
    );
\i_Master/cntX_reg[3]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntX0\,
      D => \plusOp__0\(3),
      Q => \i_Master/cntX_reg__0\(3),
      R => \i_Master/cntHeartbeat0\
    );
\i_Master/cntX_reg[4]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntX0\,
      D => \plusOp__0\(4),
      Q => \i_Master/cntX_reg__0\(4),
      R => \i_Master/cntHeartbeat0\
    );
\i_Master/cntX_reg[5]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntX0\,
      D => \plusOp__0\(5),
      Q => \i_Master/cntX_reg__0\(5),
      R => \i_Master/cntHeartbeat0\
    );
\i_Master/cntX_reg[6]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => Clk_100MHz,
      CE => \i_Master/cntX0\,
      D => \plusOp__0\(6),
      Q => \i_Master/cntX_reg__0\(6),
      R => \i_Master/cntHeartbeat0\
    );
\i_Master/ib.iChar_ROM/RAM_reg_0_15_0_7_i_22\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b3__0_n_0\,
      I1 => g1_b3_n_0,
      O => data2(4),
      S => sel(6)
    );
\i_Master/ib.iChar_ROM/RAM_reg_0_15_0_7_i_23\: unisim.vcomponents.MUXF7
     port map (
      I0 => \g0_b6__0_n_0\,
      I1 => g1_b6_n_0,
      O => data2(7),
      S => sel(6)
    );
\i_Master/regBlank_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => Blank(0),
      Q => \i_Master/regBlank_reg_n_0_[0]\,
      R => \regBlank[0]_i_1_n_0\
    );
\i_Master/regBlank_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(10),
      Q => \i_Master/regBlank_reg_n_0_[10]\,
      R => '0'
    );
\i_Master/regBlank_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(11),
      Q => \i_Master/regBlank_reg_n_0_[11]\,
      R => '0'
    );
\i_Master/regBlank_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(12),
      Q => \i_Master/regBlank_reg_n_0_[12]\,
      R => '0'
    );
\i_Master/regBlank_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(13),
      Q => \i_Master/regBlank_reg_n_0_[13]\,
      R => '0'
    );
\i_Master/regBlank_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(14),
      Q => \i_Master/regBlank_reg_n_0_[14]\,
      R => '0'
    );
\i_Master/regBlank_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(15),
      Q => \i_Master/regBlank_reg_n_0_[15]\,
      R => '0'
    );
\i_Master/regBlank_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(1),
      Q => \i_Master/regBlank_reg_n_0_[1]\,
      R => '0'
    );
\i_Master/regBlank_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(2),
      Q => \i_Master/regBlank_reg_n_0_[2]\,
      R => '0'
    );
\i_Master/regBlank_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(3),
      Q => \i_Master/regBlank_reg_n_0_[3]\,
      R => '0'
    );
\i_Master/regBlank_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(4),
      Q => \i_Master/regBlank_reg_n_0_[4]\,
      R => '0'
    );
\i_Master/regBlank_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(5),
      Q => \i_Master/regBlank_reg_n_0_[5]\,
      R => '0'
    );
\i_Master/regBlank_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(6),
      Q => \i_Master/regBlank_reg_n_0_[6]\,
      R => '0'
    );
\i_Master/regBlank_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(7),
      Q => \i_Master/regBlank_reg_n_0_[7]\,
      R => '0'
    );
\i_Master/regBlank_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(8),
      Q => \i_Master/regBlank_reg_n_0_[8]\,
      R => '0'
    );
\i_Master/regBlank_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regBlank(9),
      Q => \i_Master/regBlank_reg_n_0_[9]\,
      R => '0'
    );
\i_Master/regDI_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => Line(0),
      Q => \i_Master/regDI_reg_n_0_[0]\,
      R => \regBlank[0]_i_1_n_0\
    );
\i_Master/regDI_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(10),
      Q => \i_Master/regDI_reg_n_0_[10]\,
      R => '0'
    );
\i_Master/regDI_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(11),
      Q => \i_Master/regDI_reg_n_0_[11]\,
      R => '0'
    );
\i_Master/regDI_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(12),
      Q => \i_Master/regDI_reg_n_0_[12]\,
      R => '0'
    );
\i_Master/regDI_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(13),
      Q => \i_Master/regDI_reg_n_0_[13]\,
      R => '0'
    );
\i_Master/regDI_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(14),
      Q => \i_Master/regDI_reg_n_0_[14]\,
      R => '0'
    );
\i_Master/regDI_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(15),
      Q => \i_Master/regDI_reg_n_0_[15]\,
      R => '0'
    );
\i_Master/regDI_reg[16]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(16),
      Q => \i_Master/regDI_reg_n_0_[16]\,
      R => '0'
    );
\i_Master/regDI_reg[17]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(17),
      Q => \i_Master/regDI_reg_n_0_[17]\,
      R => '0'
    );
\i_Master/regDI_reg[18]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(18),
      Q => \i_Master/regDI_reg_n_0_[18]\,
      R => '0'
    );
\i_Master/regDI_reg[19]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(19),
      Q => \i_Master/regDI_reg_n_0_[19]\,
      R => '0'
    );
\i_Master/regDI_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => Line(1),
      Q => \i_Master/regDI_reg_n_0_[1]\,
      R => \regBlank[0]_i_1_n_0\
    );
\i_Master/regDI_reg[20]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(20),
      Q => \i_Master/regDI_reg_n_0_[20]\,
      R => '0'
    );
\i_Master/regDI_reg[21]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(21),
      Q => \i_Master/regDI_reg_n_0_[21]\,
      R => '0'
    );
\i_Master/regDI_reg[22]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(22),
      Q => \i_Master/regDI_reg_n_0_[22]\,
      R => '0'
    );
\i_Master/regDI_reg[23]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(23),
      Q => \i_Master/regDI_reg_n_0_[23]\,
      R => '0'
    );
\i_Master/regDI_reg[24]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(24),
      Q => \i_Master/regDI_reg_n_0_[24]\,
      R => '0'
    );
\i_Master/regDI_reg[25]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(25),
      Q => \i_Master/regDI_reg_n_0_[25]\,
      R => '0'
    );
\i_Master/regDI_reg[26]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(26),
      Q => \i_Master/regDI_reg_n_0_[26]\,
      R => '0'
    );
\i_Master/regDI_reg[27]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(27),
      Q => \i_Master/regDI_reg_n_0_[27]\,
      R => '0'
    );
\i_Master/regDI_reg[28]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(28),
      Q => \i_Master/regDI_reg_n_0_[28]\,
      R => '0'
    );
\i_Master/regDI_reg[29]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(29),
      Q => \i_Master/regDI_reg_n_0_[29]\,
      R => '0'
    );
\i_Master/regDI_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => Line(2),
      Q => \i_Master/regDI_reg_n_0_[2]\,
      R => \regBlank[0]_i_1_n_0\
    );
\i_Master/regDI_reg[30]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(30),
      Q => \i_Master/regDI_reg_n_0_[30]\,
      R => '0'
    );
\i_Master/regDI_reg[31]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(31),
      Q => \i_Master/regDI_reg_n_0_[31]\,
      R => '0'
    );
\i_Master/regDI_reg[32]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(32),
      Q => \i_Master/regDI_reg_n_0_[32]\,
      R => '0'
    );
\i_Master/regDI_reg[33]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(33),
      Q => \i_Master/regDI_reg_n_0_[33]\,
      R => '0'
    );
\i_Master/regDI_reg[34]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(34),
      Q => \i_Master/regDI_reg_n_0_[34]\,
      R => '0'
    );
\i_Master/regDI_reg[35]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(35),
      Q => \i_Master/regDI_reg_n_0_[35]\,
      R => '0'
    );
\i_Master/regDI_reg[36]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(36),
      Q => \i_Master/regDI_reg_n_0_[36]\,
      R => '0'
    );
\i_Master/regDI_reg[37]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(37),
      Q => \i_Master/regDI_reg_n_0_[37]\,
      R => '0'
    );
\i_Master/regDI_reg[38]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(38),
      Q => \i_Master/regDI_reg_n_0_[38]\,
      R => '0'
    );
\i_Master/regDI_reg[39]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(39),
      Q => \i_Master/regDI_reg_n_0_[39]\,
      R => '0'
    );
\i_Master/regDI_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => Line(3),
      Q => \i_Master/regDI_reg_n_0_[3]\,
      R => \regBlank[0]_i_1_n_0\
    );
\i_Master/regDI_reg[40]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(40),
      Q => \i_Master/regDI_reg_n_0_[40]\,
      R => '0'
    );
\i_Master/regDI_reg[41]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(41),
      Q => \i_Master/regDI_reg_n_0_[41]\,
      R => '0'
    );
\i_Master/regDI_reg[42]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(42),
      Q => \i_Master/regDI_reg_n_0_[42]\,
      R => '0'
    );
\i_Master/regDI_reg[43]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(43),
      Q => \i_Master/regDI_reg_n_0_[43]\,
      R => '0'
    );
\i_Master/regDI_reg[44]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(44),
      Q => \i_Master/regDI_reg_n_0_[44]\,
      R => '0'
    );
\i_Master/regDI_reg[45]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(45),
      Q => \i_Master/regDI_reg_n_0_[45]\,
      R => '0'
    );
\i_Master/regDI_reg[46]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(46),
      Q => \i_Master/regDI_reg_n_0_[46]\,
      R => '0'
    );
\i_Master/regDI_reg[47]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(47),
      Q => \i_Master/regDI_reg_n_0_[47]\,
      R => '0'
    );
\i_Master/regDI_reg[48]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(48),
      Q => \i_Master/regDI_reg_n_0_[48]\,
      R => '0'
    );
\i_Master/regDI_reg[49]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(49),
      Q => \i_Master/regDI_reg_n_0_[49]\,
      R => '0'
    );
\i_Master/regDI_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(4),
      Q => \i_Master/regDI_reg_n_0_[4]\,
      R => '0'
    );
\i_Master/regDI_reg[50]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(50),
      Q => \i_Master/regDI_reg_n_0_[50]\,
      R => '0'
    );
\i_Master/regDI_reg[51]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(51),
      Q => \i_Master/regDI_reg_n_0_[51]\,
      R => '0'
    );
\i_Master/regDI_reg[52]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(52),
      Q => \i_Master/regDI_reg_n_0_[52]\,
      R => '0'
    );
\i_Master/regDI_reg[53]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(53),
      Q => \i_Master/regDI_reg_n_0_[53]\,
      R => '0'
    );
\i_Master/regDI_reg[54]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(54),
      Q => \i_Master/regDI_reg_n_0_[54]\,
      R => '0'
    );
\i_Master/regDI_reg[55]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(55),
      Q => \i_Master/regDI_reg_n_0_[55]\,
      R => '0'
    );
\i_Master/regDI_reg[56]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(56),
      Q => \i_Master/regDI_reg_n_0_[56]\,
      R => '0'
    );
\i_Master/regDI_reg[57]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(57),
      Q => \i_Master/regDI_reg_n_0_[57]\,
      R => '0'
    );
\i_Master/regDI_reg[58]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(58),
      Q => \i_Master/regDI_reg_n_0_[58]\,
      R => '0'
    );
\i_Master/regDI_reg[59]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(59),
      Q => \i_Master/regDI_reg_n_0_[59]\,
      R => '0'
    );
\i_Master/regDI_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(5),
      Q => \i_Master/regDI_reg_n_0_[5]\,
      R => '0'
    );
\i_Master/regDI_reg[60]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(60),
      Q => \i_Master/regDI_reg_n_0_[60]\,
      R => '0'
    );
\i_Master/regDI_reg[61]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(61),
      Q => \i_Master/regDI_reg_n_0_[61]\,
      R => '0'
    );
\i_Master/regDI_reg[62]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(62),
      Q => \i_Master/regDI_reg_n_0_[62]\,
      R => '0'
    );
\i_Master/regDI_reg[63]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(63),
      Q => \i_Master/regDI_reg_n_0_[63]\,
      R => '0'
    );
\i_Master/regDI_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(6),
      Q => \i_Master/regDI_reg_n_0_[6]\,
      R => '0'
    );
\i_Master/regDI_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(7),
      Q => \i_Master/regDI_reg_n_0_[7]\,
      R => '0'
    );
\i_Master/regDI_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(8),
      Q => \i_Master/regDI_reg_n_0_[8]\,
      R => '0'
    );
\i_Master/regDI_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDI(9),
      Q => \i_Master/regDI_reg_n_0_[9]\,
      R => '0'
    );
\i_Master/regDecPts_reg[0]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => DecPts(0),
      Q => \i_Master/regDecPts_reg_n_0_[0]\,
      R => \regBlank[0]_i_1_n_0\
    );
\i_Master/regDecPts_reg[10]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(10),
      Q => \i_Master/regDecPts_reg_n_0_[10]\,
      R => '0'
    );
\i_Master/regDecPts_reg[11]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(11),
      Q => \i_Master/regDecPts_reg_n_0_[11]\,
      R => '0'
    );
\i_Master/regDecPts_reg[12]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(12),
      Q => \i_Master/regDecPts_reg_n_0_[12]\,
      R => '0'
    );
\i_Master/regDecPts_reg[13]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(13),
      Q => \i_Master/regDecPts_reg_n_0_[13]\,
      R => '0'
    );
\i_Master/regDecPts_reg[14]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(14),
      Q => \i_Master/regDecPts_reg_n_0_[14]\,
      R => '0'
    );
\i_Master/regDecPts_reg[15]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(15),
      Q => data10,
      R => '0'
    );
\i_Master/regDecPts_reg[1]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(1),
      Q => \i_Master/regDecPts_reg_n_0_[1]\,
      R => '0'
    );
\i_Master/regDecPts_reg[2]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(2),
      Q => \i_Master/regDecPts_reg_n_0_[2]\,
      R => '0'
    );
\i_Master/regDecPts_reg[3]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(3),
      Q => \i_Master/regDecPts_reg_n_0_[3]\,
      R => '0'
    );
\i_Master/regDecPts_reg[4]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(4),
      Q => \i_Master/regDecPts_reg_n_0_[4]\,
      R => '0'
    );
\i_Master/regDecPts_reg[5]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(5),
      Q => \i_Master/regDecPts_reg_n_0_[5]\,
      R => '0'
    );
\i_Master/regDecPts_reg[6]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(6),
      Q => \i_Master/regDecPts_reg_n_0_[6]\,
      R => '0'
    );
\i_Master/regDecPts_reg[7]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(7),
      Q => \i_Master/regDecPts_reg_n_0_[7]\,
      R => '0'
    );
\i_Master/regDecPts_reg[8]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(8),
      Q => \i_Master/regDecPts_reg_n_0_[8]\,
      R => '0'
    );
\i_Master/regDecPts_reg[9]\: unisim.vcomponents.FDRE
     port map (
      C => Clk_100MHz,
      CE => \i_Master/regDI\,
      D => regDecPts(9),
      Q => \i_Master/regDecPts_reg_n_0_[9]\,
      R => '0'
    );
\regBlank[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"AAAAA8AA"
    )
        port map (
      I0 => \i_Master/regDI\,
      I1 => \i_Master/state\(0),
      I2 => \i_Master/state\(1),
      I3 => \i_Master/state\(2),
      I4 => \i_Master/state\(3),
      O => \regBlank[0]_i_1_n_0\
    );
\regBlank[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(10),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[9]\,
      O => regBlank(10)
    );
\regBlank[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(11),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[10]\,
      O => regBlank(11)
    );
\regBlank[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(12),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[11]\,
      O => regBlank(12)
    );
\regBlank[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(13),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[12]\,
      O => regBlank(13)
    );
\regBlank[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(14),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[13]\,
      O => regBlank(14)
    );
\regBlank[15]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"EAAAAAAA"
    )
        port map (
      I0 => \i_Master/cntHeartbeat0\,
      I1 => \i_Master/cntX_reg\(1),
      I2 => \i_Master/cntX_reg\(0),
      I3 => \i_Master/cntX_reg\(2),
      I4 => \i_Master/cntX0\,
      O => \i_Master/regDI\
    );
\regBlank[15]_i_2\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(15),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[14]\,
      O => regBlank(15)
    );
\regBlank[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(1),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[0]\,
      O => regBlank(1)
    );
\regBlank[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(2),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[1]\,
      O => regBlank(2)
    );
\regBlank[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(3),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[2]\,
      O => regBlank(3)
    );
\regBlank[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(4),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[3]\,
      O => regBlank(4)
    );
\regBlank[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(5),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[4]\,
      O => regBlank(5)
    );
\regBlank[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(6),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[5]\,
      O => regBlank(6)
    );
\regBlank[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(7),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[6]\,
      O => regBlank(7)
    );
\regBlank[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(8),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[7]\,
      O => regBlank(8)
    );
\regBlank[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Blank(9),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regBlank_reg_n_0_[8]\,
      O => regBlank(9)
    );
\regDI[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(10),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[6]\,
      O => regDI(10)
    );
\regDI[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(11),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[7]\,
      O => regDI(11)
    );
\regDI[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(12),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[8]\,
      O => regDI(12)
    );
\regDI[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(13),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[9]\,
      O => regDI(13)
    );
\regDI[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(14),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[10]\,
      O => regDI(14)
    );
\regDI[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(15),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[11]\,
      O => regDI(15)
    );
\regDI[16]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(16),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[12]\,
      O => regDI(16)
    );
\regDI[17]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(17),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[13]\,
      O => regDI(17)
    );
\regDI[18]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(18),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[14]\,
      O => regDI(18)
    );
\regDI[19]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(19),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[15]\,
      O => regDI(19)
    );
\regDI[20]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(20),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[16]\,
      O => regDI(20)
    );
\regDI[21]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(21),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[17]\,
      O => regDI(21)
    );
\regDI[22]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(22),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[18]\,
      O => regDI(22)
    );
\regDI[23]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(23),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[19]\,
      O => regDI(23)
    );
\regDI[24]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(24),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[20]\,
      O => regDI(24)
    );
\regDI[25]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(25),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[21]\,
      O => regDI(25)
    );
\regDI[26]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(26),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[22]\,
      O => regDI(26)
    );
\regDI[27]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(27),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[23]\,
      O => regDI(27)
    );
\regDI[28]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(28),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[24]\,
      O => regDI(28)
    );
\regDI[29]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(29),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[25]\,
      O => regDI(29)
    );
\regDI[30]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(30),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[26]\,
      O => regDI(30)
    );
\regDI[31]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(31),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[27]\,
      O => regDI(31)
    );
\regDI[32]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(32),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[28]\,
      O => regDI(32)
    );
\regDI[33]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(33),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[29]\,
      O => regDI(33)
    );
\regDI[34]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(34),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[30]\,
      O => regDI(34)
    );
\regDI[35]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(35),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[31]\,
      O => regDI(35)
    );
\regDI[36]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(36),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[32]\,
      O => regDI(36)
    );
\regDI[37]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(37),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[33]\,
      O => regDI(37)
    );
\regDI[38]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(38),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[34]\,
      O => regDI(38)
    );
\regDI[39]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(39),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[35]\,
      O => regDI(39)
    );
\regDI[40]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(40),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[36]\,
      O => regDI(40)
    );
\regDI[41]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(41),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[37]\,
      O => regDI(41)
    );
\regDI[42]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(42),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[38]\,
      O => regDI(42)
    );
\regDI[43]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(43),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[39]\,
      O => regDI(43)
    );
\regDI[44]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(44),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[40]\,
      O => regDI(44)
    );
\regDI[45]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(45),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[41]\,
      O => regDI(45)
    );
\regDI[46]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(46),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[42]\,
      O => regDI(46)
    );
\regDI[47]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(47),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[43]\,
      O => regDI(47)
    );
\regDI[48]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(48),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[44]\,
      O => regDI(48)
    );
\regDI[49]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(49),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[45]\,
      O => regDI(49)
    );
\regDI[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(4),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[0]\,
      O => regDI(4)
    );
\regDI[50]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(50),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[46]\,
      O => regDI(50)
    );
\regDI[51]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(51),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[47]\,
      O => regDI(51)
    );
\regDI[52]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(52),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[48]\,
      O => regDI(52)
    );
\regDI[53]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(53),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[49]\,
      O => regDI(53)
    );
\regDI[54]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(54),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[50]\,
      O => regDI(54)
    );
\regDI[55]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(55),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[51]\,
      O => regDI(55)
    );
\regDI[56]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(56),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[52]\,
      O => regDI(56)
    );
\regDI[57]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(57),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[53]\,
      O => regDI(57)
    );
\regDI[58]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(58),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[54]\,
      O => regDI(58)
    );
\regDI[59]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(59),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[55]\,
      O => regDI(59)
    );
\regDI[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(5),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[1]\,
      O => regDI(5)
    );
\regDI[60]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(60),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[56]\,
      O => regDI(60)
    );
\regDI[61]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(61),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[57]\,
      O => regDI(61)
    );
\regDI[62]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(62),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[58]\,
      O => regDI(62)
    );
\regDI[63]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(63),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[59]\,
      O => regDI(63)
    );
\regDI[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(6),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[2]\,
      O => regDI(6)
    );
\regDI[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(7),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[3]\,
      O => regDI(7)
    );
\regDI[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(8),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[4]\,
      O => regDI(8)
    );
\regDI[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => Line(9),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDI_reg_n_0_[5]\,
      O => regDI(9)
    );
\regDecPts[10]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(10),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[9]\,
      O => regDecPts(10)
    );
\regDecPts[11]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(11),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[10]\,
      O => regDecPts(11)
    );
\regDecPts[12]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(12),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[11]\,
      O => regDecPts(12)
    );
\regDecPts[13]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(13),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[12]\,
      O => regDecPts(13)
    );
\regDecPts[14]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(14),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[13]\,
      O => regDecPts(14)
    );
\regDecPts[15]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(15),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[14]\,
      O => regDecPts(15)
    );
\regDecPts[1]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(1),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[0]\,
      O => regDecPts(1)
    );
\regDecPts[2]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(2),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[1]\,
      O => regDecPts(2)
    );
\regDecPts[3]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(3),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[2]\,
      O => regDecPts(3)
    );
\regDecPts[4]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(4),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[3]\,
      O => regDecPts(4)
    );
\regDecPts[5]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(5),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[4]\,
      O => regDecPts(5)
    );
\regDecPts[6]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(6),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[5]\,
      O => regDecPts(6)
    );
\regDecPts[7]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(7),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[6]\,
      O => regDecPts(7)
    );
\regDecPts[8]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(8),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[7]\,
      O => regDecPts(8)
    );
\regDecPts[9]_i_1\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFEF00000020"
    )
        port map (
      I0 => DecPts(9),
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      I5 => \i_Master/regDecPts_reg_n_0_[8]\,
      O => regDecPts(9)
    );
\sregOut[7]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00020828"
    )
        port map (
      I0 => \i_I2C/cntSCL\,
      I1 => \i_Master/state\(3),
      I2 => \i_Master/state\(2),
      I3 => \i_Master/state\(1),
      I4 => \i_Master/state\(0),
      O => \i_I2C/RdNotWr0\
    );
\sregOut[7]_i_2\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"0020F020"
    )
        port map (
      I0 => \i_I2C/sclEnd\,
      I1 => I2C_FIFO_Empty,
      I2 => \i_I2C/p_0_in\,
      I3 => \addrRd_rep[3]_i_3_n_0\,
      I4 => \sregOut[7]_i_4_n_0\,
      O => \sregOut[7]_i_2_n_0\
    );
\sregOut[7]_i_4\: unisim.vcomponents.LUT6
    generic map(
      INIT => X"FFFFFFFFFFFFFFFD"
    )
        port map (
      I0 => \sregOut[7]_i_5_n_0\,
      I1 => L(5),
      I2 => L(6),
      I3 => L(7),
      I4 => L(8),
      I5 => \sregOut[7]_i_6_n_0\,
      O => \sregOut[7]_i_4_n_0\
    );
\sregOut[7]_i_5\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"00000001"
    )
        port map (
      I0 => L(1),
      I1 => L(2),
      I2 => L(0),
      I3 => L(3),
      I4 => SCLout_i_6_n_0,
      O => \sregOut[7]_i_5_n_0\
    );
\sregOut[7]_i_6\: unisim.vcomponents.LUT4
    generic map(
      INIT => X"FFFE"
    )
        port map (
      I0 => L(4),
      I1 => L(10),
      I2 => L(11),
      I3 => L(8),
      O => \sregOut[7]_i_6_n_0\
    );
end STRUCTURE;
